// ============================================
//  𝑀𝐴𝐷𝐴𝑅𝐴 𝐵🌀𝑇
//  كود أصلي بالكامل — تطوير: 𝑴𝑨𝑹𝑶
//  مبني مباشرة على @whiskeysockets/baileys الرسمية
// ============================================

import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  Browsers,
} from '@whiskeysockets/baileys';
import fs from 'fs';
import { Boom } from '@hapi/boom';
import pino from 'pino';

import { config } from './config.js';
import { serialize } from './lib/serialize.js';
import { commands, loadAllCommands, watchPlugins, getAllPlugins } from './lib/pluginLoader.js';
import { getGroupSettings, isBlocked, getGlobalSetting } from './lib/db.js';
import { getRankName, getRankLevel, RANKS, bootstrapOwner } from './lib/ranks.js';

const logger = pino({ level: 'silent' });
let pairingCodeSent = false; // يمنع طلب كود جديد مع كل إعادة اتصال أثناء عملية الربط

// حماية عامة: أي خطأ غير متوقع يتسجّل بالكونسول بدل ما يقتل العملية كاملة
process.on('unhandledRejection', (err) => console.log('⚠️ خطأ غير متوقع (unhandledRejection):', err));
process.on('uncaughtException', (err) => console.log('⚠️ خطأ غير متوقع (uncaughtException):', err));

// هل التشغيل بكود اقتران (Pairing Code) بدل QR؟ — من config.js مباشرة، بدون تعديل أمر التشغيل
const usePairingCode = config.usePairingCode === true;

function isOwner(jid) {
  return getRankName(jid) === 'مالك';
}

// حماية: يحذف أي ملف "تفريغ ذاكرة" (core dump) ضخم يتكوّن تلقائيًا لو صار انهيار غريب،
// عشان ما يعبي مساحة القرص ويسبب مشاكل متتالية بالسيرفر
function cleanupCoreDumps() {
  try {
    const corePath = './core';
    if (fs.existsSync(corePath) && fs.statSync(corePath).isFile()) {
      const sizeMB = (fs.statSync(corePath).size / 1024 / 1024).toFixed(1);
      fs.unlinkSync(corePath);
      console.log(`🧹 تم حذف ملف core قديم (${sizeMB} MB) كان يعبّي المساحة.`);
    }
  } catch (e) { /* تجاهل أي خطأ بعملية التنظيف */ }
}
cleanupCoreDumps();

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState(`./session/${config.sessionName}`);
  let version;
  try {
    version = (await fetchLatestBaileysVersion()).version;
  } catch {
    version = [2, 3000, 1033959288]; // نسخة احتياطية لو فشل جلب أحدث نسخة تلقائيًا
  }

  const sock = makeWASocket({
    version,
    logger,
    printQRInTerminal: !usePairingCode,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger),
    },
    browser: usePairingCode ? Browsers.windows('Chrome') : Browsers.macOS(config.botName),
  });

  // كل رسالة يرسلها البوت تطلع عليها وسم "معاد توجيهها" تلقائيًا (زي بوتات كثيرة)
  const originalSendMessage = sock.sendMessage.bind(sock);
  sock.sendMessage = (jid, content, options = {}) => {
    if (content && typeof content === 'object' && !content.delete && !content.react) {
      const forwardInfo = { isForwarded: true, forwardingScore: 999 };
      if (config.channelJid) {
        forwardInfo.forwardedNewsletterMessageInfo = {
          newsletterJid: config.channelJid,
          newsletterName: config.channelName || config.botName,
          serverMessageId: 1,
        };
      }
      content = {
        ...content,
        contextInfo: { ...(content.contextInfo || {}), ...forwardInfo },
      };
    }
    return originalSendMessage(jid, content, options);
  };


  await loadAllCommands();
  console.log(`✅ ${config.botName} — تم تحميل ${getAllPlugins().length} أمر بنجاح`);
  watchPlugins(); // مراقبة تلقائية: أي أمر جديد أو معدّل ينحمّل فورًا بدون Restart

  sock.ev.on('creds.update', saveCreds);

  // تسجيل دخول بكود اقتران (الطريقة الافتراضية والوحيدة المضمونة حاليًا) — مرة وحدة بس
  if (usePairingCode && !sock.authState.creds.registered && !pairingCodeSent) {
    const phone = config.phoneNumber.replace(/[^0-9]/g, '');
    if (!phone || phone.length < 8 || config.phoneNumber.includes('XXXXXXXXX')) {
      console.log('\n❌ حط رقمك الحقيقي بخانة phoneNumber بملف config.js (لسا حاطط الرقم الافتراضي).\n');
    } else {
      pairingCodeSent = true;
      console.log(`\n⏳ جاري طلب كود الاقتران لرقم: ${phone}\n`);
      await new Promise((r) => setTimeout(r, 5000)); // ننتظر استقرار الاتصال قبل طلب الكود
      const code = await sock.requestPairingCode(phone);
      const formatted = code?.match(/.{1,4}/g)?.join('-') || code;
      console.log('\n================================');
      console.log('   كود الاقتران (دخّله بواتساب):');
      console.log('   ' + formatted);
      console.log('================================\n');
      console.log('(البوت راح ينقطع وبيتصل تلقائي بعد إدخاله، هذا طبيعي، لا تعيد أي شي)\n');
    }
  }

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (connection === 'close') {
      const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
      console.log('⚠️ انقطع الاتصال.', shouldReconnect ? 'إعادة المحاولة...' : 'تم تسجيل الخروج.');
      if (shouldReconnect) setTimeout(() => startBot(), 2000);
    } else if (connection === 'open') {
      console.log(`🚀 ${config.botName} متصل الآن بنجاح!`);
      bootstrapOwner(config.linkedNumber.replace(/[^0-9]/g, ''));
    }
  });

  // ============ استقبال الرسائل وتوزيع الأوامر ============
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;

    for (const msg of messages) {
      if (!msg.message) continue;

      const m = serialize(sock, msg);

      // ===== فحص حماية الوسائط (قبل شرط النص، لأن الصور/الملصقات غالبًا بدون نص) =====
      if (m.isGroup && !msg.key.fromMe) {
        try {
          const settings = getGroupSettings(m.chat);
          if (!isOwner(m.sender)) {
            const mtype = Object.keys(msg.message)[0];
            let violated = null;
            if (settings.anticontact && (mtype === 'contactMessage' || mtype === 'contactsArrayMessage')) violated = 'جهة اتصال';
            else if (settings.antisticker && mtype === 'stickerMessage') violated = 'ملصق';
            else if (settings.antiimage && mtype === 'imageMessage') violated = 'صورة';
            else if (settings.antivideo && mtype === 'videoMessage') violated = 'فيديو';
            if (violated) {
              await sock.sendMessage(m.chat, { delete: m.key });
              await sock.sendMessage(m.chat, {
                text: `🚫 تم حذف ${violated} من @${m.sender.split('@')[0]} (ممنوع بهذا الجروب).`,
                mentions: [m.sender],
              });
              continue;
            }
          }
        } catch (e) { /* تجاهل أي خطأ بفحص الوسائط */ }
      }

      if (!m.text) continue;

      // لو الرسالة من نفس رقم البوت (سيلف بوت): نتجاهلها إلا لو فيها بادئة أمر صحيحة
      // (عشان نفرّق بين أمر كتبته انت، ورد تلقائي أرسله البوت نفسه)
      if (msg.key.fromMe) {
        const activePrefixesCheck = getGlobalSetting('prefixes', config.prefixes);
        const hasValidPrefix = activePrefixesCheck.some((p) => m.text.startsWith(p));
        if (!hasValidPrefix) continue;
      }

      // ===== فحص منع الروابط (لو مفعّل بالجروب) =====
      if (m.isGroup && !m.fromMe) {
        try {
          const settings = getGroupSettings(m.chat);
          if (settings.antilink && /chat\.whatsapp\.com\/[A-Za-z0-9]+/.test(m.text)) {
            const senderIsOwnerCheck = isOwner(m.sender);
            if (!senderIsOwnerCheck) {
              await sock.sendMessage(m.chat, { delete: m.key });
              await sock.sendMessage(m.chat, {
                text: `🚫 تم حذف رسالة @${m.sender.split('@')[0]} لأنها فيها رابط جروب.`,
                mentions: [m.sender],
              });
              continue;
            }
          }
        } catch (e) { /* تجاهل أي خطأ بفحص الروابط */ }

        // ===== فحص منع الشتم (لو مفعّل بالجروب) =====
        try {
          const settings2 = getGroupSettings(m.chat);
          if (settings2.antibadword && config.bannedWords.length > 0) {
            const lower = m.text.toLowerCase();
            const found = config.bannedWords.some((w) => lower.includes(w.toLowerCase()));
            if (found && !isOwner(m.sender)) {
              await sock.sendMessage(m.chat, { delete: m.key });
              continue;
            }
          }
        } catch (e) { /* تجاهل أي خطأ بفحص الشتم */ }
      }

      // فحص البادئة
      const activePrefixes = getGlobalSetting('prefixes', config.prefixes);
      const usedPrefix = activePrefixes.find((p) => m.text.startsWith(p));
      if (!usedPrefix) continue;

      const withoutPrefix = m.text.slice(usedPrefix.length).trim();
      const [cmdName, ...args] = withoutPrefix.split(/\s+/);
      if (!cmdName) continue;

      const plugin = commands.get(cmdName.toLowerCase());
      if (!plugin) continue;

      if (isBlocked(m.sender)) continue;

      const args_text = args.join(' ');
      const senderIsOwner = isOwner(m.sender);
      const senderRank = getRankName(m.sender);
      const senderRankLevel = getRankLevel(m.sender);

      // فحص الرتبة (لو الأمر محدد له رتبة أدنى مطلوبة)
      if (plugin.minRank && senderRankLevel < (RANKS[plugin.minRank] || 1)) {
        await m.reply(`🚫 هذا الأمر يحتاج رتبة "${plugin.minRank}" أو أعلى.\nرتبتك الحالية: ${senderRank}`);
        continue;
      }

      // فحص الصلاحيات
      if (plugin.ownerOnly && !senderIsOwner) {
        await m.reply('🚫 هذا الأمر مخصص لمالك البوت فقط.');
        continue;
      }
      if (plugin.groupOnly && !m.isGroup) {
        await m.reply('🚫 هذا الأمر يشتغل بالجروبات بس.');
        continue;
      }
      if (plugin.adminOnly && m.isGroup) {
        try {
          const meta = await sock.groupMetadata(m.chat);
          const participant = meta.participants.find((p) => p.id === m.sender);
          const isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
          if (!isAdmin && !senderIsOwner) {
            await m.reply('🚫 هذا الأمر مخصص لأدمنية الجروب فقط.');
            continue;
          }
        } catch (e) { /* تجاهل فشل فحص الأدمن */ }
      }

      try {
        await plugin.execute(sock, m, args, { args_text, config, isOwner: senderIsOwner, senderRank, senderRankLevel, commandMap: commands, allPlugins: getAllPlugins() });
      } catch (err) {
        console.error(`❌ خطأ بتنفيذ أمر "${cmdName}":`, err);
        await m.reply(`⚠️ صار خطأ أثناء تنفيذ الأمر.\n${err.message}`);
      }
    }
  });

  // ============ ترحيب/وداع تلقائي بالأعضاء ============
  sock.ev.on('group-participants.update', async ({ id, participants, action }) => {
    try {
      const settings = getGroupSettings(id);
      if (!settings.welcome) return;

      const meta = await sock.groupMetadata(id);
      for (const jid of participants) {
        const name = jid.split('@')[0];
        if (action === 'add') {
          const welcomeText = settings.welcomeText
            ? settings.welcomeText.replace('@user', `@${name}`)
            : `👋 حياك الله @${name} بجروب *${meta.subject}*!`;
          await sock.sendMessage(id, { text: welcomeText, mentions: [jid] });
        } else if (action === 'remove') {
          await sock.sendMessage(id, { text: `👋 ودّعنا @${name}.`, mentions: [jid] });
        }
      }
    } catch (e) { /* تجاهل أي خطأ بحدث الترحيب */ }
  });

  return sock;
}

startBot().catch((err) => {
  console.error('❌ فشل تشغيل البوت:', err);
  process.exit(1);
});

// يمنع العملية من الإغلاق التلقائي لو صار أي فراغ لحظي بمنتصف إعادة الاتصال
setInterval(() => {}, 60000);
