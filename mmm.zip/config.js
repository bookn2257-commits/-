// ============================================
//  𝑀𝐴𝐷𝐴𝑅𝐴 𝐵🌀𝑇 — ملف الإعدادات
//  تطوير: 𝑴𝑨𝑹𝑶
// ============================================

export const config = {
  botName: '𝑀𝐴𝐷𝐴𝑅𝐴 𝐵🌀𝑇',
  developer: '𝑴𝑨𝑹𝑶',

  linkedNumber: '963998009642',
  prefixes: ['.', '!', '/'],
  welcomeEnabled: true,
  sessionName: 'madara_session',

  // ⚙️ إعدادات الذكاء الاصطناعي (Pollinations AI)
  aiModel: 'openai/gpt-4o', // النموذج الموحد الجديد

  bannedWords: [],
  usePairingCode: true,
  phoneNumber: '963965331607',

  // ⚙️ قناتك اللي تبي كل رسائل البوت تظهر "معاد توجيهها منها" — اتركها فاضية لو ما تبي هالميزة
  channelJid: '120363403640740499@newsletter',   // مثال: 120363012345678901@newsletter (احصل عليه بأمر .قناة_معلومات)
  channelName: '𝑴𝑨𝑹𝑶',  // اسم قناتك اللي يطلع بالرسالة
};

export default config;
