import { askAI } from '../../lib/ai.js';

export default {
  command: ['تلخيص'],
  category: 'ذكاء اصطناعي',
  description: 'يلخّص نص طويل (يحتاج مفتاح API بملف config.js)',
  execute: async (sock, m, args, { args_text }) => {
    const text = args_text || (await m.downloadMedia() ? null : null);
    const source = args_text || m.quoted?.message?.conversation || m.quoted?.message?.extendedTextMessage?.text;
    if (!source) return m.reply('❌ اكتب النص بعد الأمر أو رد على رسالة نصية.');
    await m.reply('📝 جاري التلخيص...');
    try {
      const summary = await askAI(`لخّص هذا النص بالعربي باختصار:\n\n${source}`);
      await m.reply(`📝 التلخيص:\n${summary}`);
    } catch (err) {
      await m.reply(`⚠️ ${err.message}`);
    }
  },
};
