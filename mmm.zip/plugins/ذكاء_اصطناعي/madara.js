import fs from 'fs';
import path from 'path';
import { sendButtons } from '../../lib/menus.js';

const GEMINI_API_KEY = 'AIzaSyBFIy5Fq_w1hp_U2vqKGQO9Nj0Czixm8Ro';
const stateFile = path.join(process.cwd(), 'madara_state.json');

function getStatus() {
  try {
    return fs.existsSync(stateFile) ? JSON.parse(fs.readFileSync(stateFile, 'utf-8')).active : false;
  } catch {
    return false;
  }
}

function setStatus(status) {
  try {
    fs.writeFileSync(stateFile, JSON.stringify({ active: status }), 'utf-8');
  } catch (e) {
    console.error(e);
  }
}

// دالة Gemini المباشرة
async function askGemini(prompt, systemInstruction = '') {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`;
  const fullPrompt = systemInstruction ? `${systemInstruction}\n\n${prompt}` : prompt;

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: fullPrompt }] }]
    })
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `خطأ في الاتصال: ${response.status}`);
  }

  const data = await response.json();
  const answer = data.candidates?.[0]?.content?.parts?.[0]?.text;

  if (!answer) throw new Error('لم يتم استلام رد من Gemini.');
  return answer;
}

export default {
  command: ['مادارا', 'madara', 'سؤال', 'توليد', 'تخيل', 'صورة', 'تلخيص', 'كود', 'برمجة', 'شرح', 'اشرح'],
  category: 'ذكاء اصطناعي',
  description: 'نظام 𝑀𝐴𝐷𝐴𝑅𝐴 الشامل بالذكاء الاصطناعي',
  withoutPrefix: true,

  execute: async (sock, m, args) => {
    const rawText = (m.text || '').trim();
    const cleanText = rawText.replace(/^[.!/#]/, '');
    const firstWord = cleanText.split(' ')[0].toLowerCase();
    const inputText = cleanText.split(' ').slice(1).join(' ');

    // جلب النص المقتبس في حال كان المستخدم يرد على رسالة
    const quotedText = m.quoted ? (m.quoted.text || m.quoted.caption || '') : '';

    const isActive = getStatus();

    // 1. القائمة الرئيسية والأزرار
    if (firstWord === 'مادارا' || firstWord === 'madara') {
      const action = args[0]?.toLowerCase() || cleanText.split(' ')[1]?.toLowerCase();

      if (action === 'on') {
        setStatus(true);
        return sock.sendMessage(m.chat, { text: '✅ تم تشغيل 𝑀𝐴𝐷𝐴𝑅𝐴 بنجاح!' }, { quoted: m.raw });
      }

      if (action === 'off') {
        setStatus(false);
        return sock.sendMessage(m.chat, { text: '❌ تم إيقاف 𝑀𝐴𝐷𝐴𝑅𝐴.' }, { quoted: m.raw });
      }

      return await sendButtons(sock, m.chat, {
        text: `🌀 *نظام الذكاء الاصطناعي 𝑀𝐴𝐷𝐴𝑅𝐴*\n\nالحالة الحالية: *${isActive ? 'مُفعل 🟢' : 'معطل 🔴'}*\n\nالخدمات المتاحة:\n• *سؤال [سؤالك]*\n• *توليد [وصف الصورة]*\n• *تلخيص [الرد على رسالة]*\n• *شرح [الرد على رسالة أو نص]*\n• *كود [المطلوب]*`,
        footer: '𝑀𝐴𝐷𝐴𝑅𝐴 𝐵🌀𝑇',
        buttons: [
          { id: '.مادارا on', text: '.مادارا on' },
          { id: '.مادارا off', text: '.مادارا off' },
        ],
        quoted: m.raw,
      });
    }

    if (!isActive) {
      if (['سؤال', 'توليد', 'تخيل', 'صورة', 'تلخيص', 'كود', 'برمجة', 'شرح', 'اشرح'].includes(firstWord)) {
        return sock.sendMessage(m.chat, { text: '⚠️ النظام معطل! اكتب *.مادارا* واضغط تشغيل.' }, { quoted: m.raw });
      }
      return;
    }

    // 2. أمر إنشاء صورة
    if (['توليد', 'تخيل', 'صورة'].includes(firstWord)) {
      if (!inputText) {
        return sock.sendMessage(m.chat, { text: '❌ اكتب وصف الصورة بعد الكلمة.\nمثال: *توليد سيارة رياضية*' }, { quoted: m.raw });
      }

      try {
        await sock.sendMessage(m.chat, { react: { text: '🎨', key: m.raw.key } });
        const imageUrl = `https://pollinations.ai/p/${encodeURIComponent(inputText)}?width=1024&height=1024&seed=${Math.floor(Math.random() * 1000)}`;

        await sock.sendMessage(m.chat, {
          image: { url: imageUrl },
          caption: `🎨 *[ 𝑀𝐴𝐷𝐴𝑅𝐴 𝐼𝑀𝐴𝐺𝐸 ]*\n\nالطلب: ${inputText}`
        }, { quoted: m.raw });
      } catch (err) {
        await sock.sendMessage(m.chat, { text: `⚠️ تعذر إنشاء الصورة: ${err.message}` }, { quoted: m.raw });
      }
      return;
    }

    // 3. أمر التلخيص (يدعم الرد على الرسائل مباشرة)
    if (firstWord === 'تلخيص') {
      const targetText = quotedText || inputText;

      if (!targetText) {
        return sock.sendMessage(m.chat, { 
          text: '❌ للتلخيص قم بـ **الرد على الرسالة المراد تلخيصها** وكتابة كلمة *تلخيص*\nأو اكتب: *تلخيص 3 اسطر [النص]*' 
        }, { quoted: m.raw });
      }

      const lineMatch = rawText.match(/(\d+)\s*(اسطر|أسطر|سطر)/i);
      let lines = 3;
      if (lineMatch) lines = lineMatch[1];

      try {
        await sock.sendMessage(m.chat, { react: { text: '📝', key: m.raw.key } });
        const systemPrompt = `أنت مساعد ذكي. قم بتلخيص النص التالي بأسلوب دقيق ومباشر في **${lines} أسطر فقط** باللغة العربية:`;
        const summary = await askGemini(targetText, systemPrompt);

        await sock.sendMessage(m.chat, { text: `📝 *[ 𝑀𝐴𝐷𝐴𝑅𝐴 𝑆𝑈𝑀𝑀𝐴𝑅𝑌 - ${lines} أسطر ]*\n\n${summary}` }, { quoted: m.raw });
      } catch (err) {
        await sock.sendMessage(m.chat, { text: `⚠️ خطأ: ${err.message}` }, { quoted: m.raw });
      }
      return;
    }

    // 4. أمر الشرح (يدعم النص المباشر والرد على الرسائل)
    if (['شرح', 'اشرح'].includes(firstWord)) {
      const targetText = quotedText ? `${inputText ? inputText + ':\n' : ''}${quotedText}` : inputText;

      if (!targetText) {
        return sock.sendMessage(m.chat, { 
          text: '❌ قم بـ **الرد على الرسالة المراد شرحها** وكتابة كلمة *شرح*\nأو اكتب: *شرح [المفهوم أو النص]*' 
        }, { quoted: m.raw });
      }

      try {
        await sock.sendMessage(m.chat, { react: { text: '💡', key: m.raw.key } });
        const systemPrompt = 'أنت معلم وخبير ذكي. قم بشرح النص أو المفهوم التالي بطريقة مبسطة وواضحة جداً مع أمثلة إن أمكن:';
        const explanation = await askGemini(targetText, systemPrompt);

        await sock.sendMessage(m.chat, { text: `💡 *[ 𝑀𝐴𝐷𝐴𝑅𝐴 𝐸𝑋𝑃𝐿𝐴𝑁𝐴𝑇𝐼𝑂𝑁 ]*\n\n${explanation}` }, { quoted: m.raw });
      } catch (err) {
        await sock.sendMessage(m.chat, { text: `⚠️ خطأ: ${err.message}` }, { quoted: m.raw });
      }
      return;
    }

    // 5. أمر كتابة كود JavaScript
    if (['كود', 'برمجة'].includes(firstWord)) {
      if (!inputText) {
        return sock.sendMessage(m.chat, { text: '❌ اكتب المطلوب برمجته بالجافاسكريبت.\nمثال: *كود دالة لحساب العمر*' }, { quoted: m.raw });
      }

      try {
        await sock.sendMessage(m.chat, { react: { text: '💻', key: m.raw.key } });
        const systemPrompt = 'أنت خبير برمجة بلغة JavaScript. اكتب كود جافاسكريبت نظيف ومباشر وموضح بتعليقات للشرح بناءً على الطلب التالي:';
        const codeResponse = await askGemini(inputText, systemPrompt);

        await sock.sendMessage(m.chat, { text: `💻 *[ 𝑀𝐴𝐷𝐴𝑅𝐴 𝐽𝐴𝑉𝐴𝑆𝐶𝑅𝐼𝑃𝑇 ]*\n\n${codeResponse}` }, { quoted: m.raw });
      } catch (err) {
        await sock.sendMessage(m.chat, { text: `⚠️ خطأ: ${err.message}` }, { quoted: m.raw });
      }
      return;
    }

    // 6. أمر السؤال العادي
    if (firstWord === 'سؤال') {
      if (!inputText) {
        return sock.sendMessage(m.chat, { text: '❌ اكتب سؤالك بعد الكلمة.\nمثال: *سؤال ما هي عاصمة فرنسا؟*' }, { quoted: m.raw });
      }

      try {
        await sock.sendMessage(m.chat, { react: { text: '🌀', key: m.raw.key } });
        const answer = await askGemini(inputText, 'أنت الذكاء الاصطناعي 𝑀𝐴𝐷𝐴𝑅𝐴. أجب بقوة وذكاء على:');

        await sock.sendMessage(m.chat, { text: `🌀 *[ 𝑀𝐴𝐷𝐴𝑅𝐴 𝐴I ]*\n\n${answer}` }, { quoted: m.raw });
      } catch (err) {
        await sock.sendMessage(m.chat, { text: `⚠️ خطأ: ${err.message}` }, { quoted: m.raw });
      }
    }
  },
};
