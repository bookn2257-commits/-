import util from 'util';

export default {
  command: ['تنفيذ'],
  category: 'المالك',
  description: 'ينفّذ كود جافاسكربت مباشر (لمالك البوت فقط، للتجربة والصيانة)',
  ownerOnly: true,
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب كود بعد الأمر.');
    try {
      let result = await eval(`(async () => { ${args_text} })()`);
      if (typeof result !== 'string') result = util.inspect(result);
      await m.reply(`✅ النتيجة:\n${result}`);
    } catch (err) {
      await m.reply(`❌ خطأ:\n${err.message}`);
    }
  },
};
