import { exec } from 'child_process';
import util from 'util';

const execPromise = util.promisify(exec);

export default {
  command: ['تنفيذ_شل', '$'],
  category: 'المالك',
  description: 'ينفّذ أمر Shell على السيرفر (لمالك البوت فقط، للصيانة)',
  ownerOnly: true,
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب أمر بعد الأمر.');
    try {
      const { stdout, stderr } = await execPromise(args_text, { timeout: 30000 });
      await m.reply(`✅ النتيجة:\n${stdout || stderr || '(بدون خرج)'}`);
    } catch (err) {
      await m.reply(`❌ خطأ:\n${err.message}`);
    }
  },
};
