import { setRank, getRankName, RANKS, RANK_ORDER } from '../../lib/ranks.js';

export default {
  command: ['رتبة', 'تعيين_رتبة'],
  category: 'المالك',
  description: 'يعيّن رتبة لشخص (رد على رسالته أو منشن). مثال: .رتبة نخبة',
  minRank: 'نخبة', // بس من رتبة نخبة فما فوق يقدر يستخدمه
  execute: async (sock, m, args, { args_text, senderRank }) => {
    const target = m.mentionedJid[0] || m.quoted?.sender;
    if (!target) return m.reply('❌ رد على رسالة الشخص أو اعمله منشن.');

    const newRank = args_text.trim();
    if (!RANKS[newRank] || newRank === 'مالك') {
      return m.reply(`❌ رتبة غير معروفة. الرتب المتاحة:\n${RANK_ORDER.filter((r) => r !== 'مالك').join('، ')}`);
    }

    const myLevel = RANKS[senderRank];
    // ما تقدر تعيّن رتبة أعلى أو تساوي رتبتك
    if (RANKS[newRank] >= myLevel) {
      return m.reply('❌ ما تقدر تعيّن رتبة أعلى من رتبتك أو تساويها.');
    }

    const targetNum = target.split('@')[0];
    setRank(targetNum, newRank);
    await sock.sendMessage(m.chat, { text: `✅ تم تعيين @${targetNum} برتبة "${newRank}".`, mentions: [target] });
  },
};
