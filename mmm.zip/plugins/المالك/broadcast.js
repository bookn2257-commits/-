export default {
  command: ['بث'],
  category: 'المالك',
  description: 'يبث رسالة لكل الجروبات اللي البوت فيها (مالك البوت فقط)',
  ownerOnly: true,
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب الرسالة بعد الأمر.');
    const groups = await sock.groupFetchAllParticipating();
    const ids = Object.keys(groups);
    let sent = 0;
    for (const id of ids) {
      try {
        await sock.sendMessage(id, { text: `📢 بث من المالك:\n\n${args_text}` });
        sent++;
      } catch (e) { /* تجاهل الفشل بجروب معيّن */ }
    }
    await m.reply(`✅ تم الإرسال لـ ${sent} من ${ids.length} جروب.`);
  },
};
