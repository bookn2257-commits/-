import { setGlobalSetting } from '../../lib/db.js';

export default {
  command: ['تغيير_البادئة'],
  category: 'المالك',
  description: 'يغيّر بادئة الأوامر (مالك البوت فقط). مثال: .تغيير_البادئة # . !',
  ownerOnly: true,
  execute: async (sock, m, args, { args_text }) => {
    const prefixes = args_text.trim().split(/\s+/).filter(Boolean);
    if (prefixes.length === 0) return m.reply('❌ اكتب بادئة واحدة أو أكثر مفصولة بمسافة. مثال: .تغيير_البادئة # .');
    setGlobalSetting('prefixes', prefixes);
    await m.reply(`✅ تم تغيير البادئة إلى: ${prefixes.join(' ')}`);
  },
};
