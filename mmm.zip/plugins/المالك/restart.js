export default {
  command: ['اعادة_تشغيل'],
  category: 'المالك',
  description: 'يعيد تشغيل عملية البوت (تحتاج مدير عمليات زي pm2 أو استضافة تعيد التشغيل تلقائيًا)',
  ownerOnly: true,
  execute: async (sock, m) => {
    await m.reply('🔄 جاري إعادة التشغيل...');
    process.exit(0);
  },
};
