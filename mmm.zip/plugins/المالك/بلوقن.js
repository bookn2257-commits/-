import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { downloadContentFromMessage } from "@whiskeysockets/baileys";
import { sendButtons } from "../../lib/menus.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// مجلد البلوقنات الرئيسي (الوصول للمجلد الأساسي بشكل مطلق وتجنب مشاكل ../)
const PLUGINS_DIR = path.resolve(__dirname, "../");

// دالة جلب كافة الملفات داخل المجلد والمجلدات الفرعية (الأقسام)
const getAllPlugins = (dirPath = PLUGINS_DIR, arrayOfFiles = []) => {
  const files = fs.readdirSync(dirPath);

  files.forEach((file) => {
    const fullPath = path.join(dirPath, file);
    if (fs.statSync(fullPath).isDirectory()) {
      arrayOfFiles = getAllPlugins(fullPath, arrayOfFiles);
    } else {
      if (file.endsWith(".js")) {
        const relativePath = path.relative(PLUGINS_DIR, fullPath);
        const category = path.dirname(relativePath) === "." ? "عام" : path.dirname(relativePath);
        arrayOfFiles.push({
          name: file,
          relativePath,
          fullPath,
          category
        });
      }
    }
  });

  return arrayOfFiles;
};

// دالة البحث عن ملف معين في كل الأقسام
const findPlugin = (name) => {
  const searchName = name.replace(/\.js$/i, "").trim().toLowerCase().replace(/\s+/g, "-");
  const allFiles = getAllPlugins();

  let found = allFiles.find(f => f.name.toLowerCase() === searchName + ".js");
  if (found) return found;

  found = allFiles.find(f => f.name.replace(/-/g, "_").toLowerCase() === searchName.replace(/-/g, "_") + ".js");
  if (found) return found;

  found = allFiles.find(f => f.name.toLowerCase().includes(searchName));
  if (found) return found;

  return null;
};

export default {
  command: ["بلوقن", "البلوقنات", "plugin", "plugins"],
  category: "إدارة البوت",
  description: "إدارة البلوقنات والملفات داخل الأقسام المختلفة",
  withoutPrefix: true,
  ownerOnly: true,

  execute: async (sock, m, args) => {
    const action = args[0]?.toLowerCase() || "";
    const nameArg = args.slice(1).join(" ").trim();

    // 1. القائمة الرئيسية
    if (!action) {
      const plugins = getAllPlugins();
      return await sendButtons(sock, m.chat, {
        text: `📦 *[ 𝑀𝐴𝐷𝐴𝑅𝐴 𝑃𝐿𝑈𝐺𝐼𝑁 𝑀𝐴𝑁𝐴𝐺𝐸𝑅 ]*\n\nنظام إدارة وتعديل الملفات البرمجية للبوت.\n\n📊 مجموع البلوقنات الكلي: *${plugins.length}*\n\nالأوامر المتاحة:\n• *بلوقن لست* - عرض كل الملفات مقسمة\n• *بلوقن عرض [اسم]* - عرض سورس كود\n• *بلوقن اضف [بالرد]* - حفظ ملف جديد\n• *بلوقن حذف [اسم]* - مسح ملف`,
        footer: "𝑀𝐴𝐷𝐴𝑅𝐴 𝐵🌀𝑇",
        buttons: [
          { id: ".بلوقن لست", text: "📋 قائمة البلوقنات" },
          { id: ".بلوقن", text: "🌀 القائمة الرئيسية" },
          { id: ".بلوقن حذف", text: "❌ حذف بلوقن" }
        ],
        quoted: m.raw,
      });
    }

    // 2. عرض القائمة مقسمة حسب الفولديرات / الأقسام
    if (["لست", "list"].includes(action)) {
      const plugins = getAllPlugins();
      if (!plugins.length) {
        return sock.sendMessage(m.chat, { text: "📦 لا توجد أي ملفات بلوقن حالياً." }, { quoted: m.raw });
      }

      const categories = {};
      plugins.forEach(plugin => {
        const cat = plugin.category;
        if (!categories[cat]) categories[cat] = [];
        categories[cat].push(plugin.name);
      });

      let text = `📦 *[ قائمة بلوقنات 𝑀𝐴𝐷𝐴𝑅𝐴 ]*\n\n`;
      let count = 1;

      for (const [catName, fileList] of Object.entries(categories)) {
        text += `📂 *قسم: [ ${catName.toUpperCase()} ]*\n`;
        fileList.forEach(file => {
          text += `  *${count}.* \`${file}\`\n`;
          count++;
        });
        text += `\n`;
      }

      text += `📊 المجموع الكلي: *${plugins.length}* بلوقن`;
      return sock.sendMessage(m.chat, { text }, { quoted: m.raw });
    }

    // 3. عرض كود الملف من أي قسم
    if (["عرض", "show", "get"].includes(action)) {
      if (!nameArg) {
        return sock.sendMessage(m.chat, { text: "❌ حدد اسم البلوقن المراد عرضه.\nمثال: *بلوقن عرض madara*" }, { quoted: m.raw });
      }

      const foundFile = findPlugin(nameArg);
      if (!foundFile) {
        return sock.sendMessage(m.chat, { text: `❌ الملف "*${nameArg}*" غير موجود.` }, { quoted: m.raw });
      }

      const code = fs.readFileSync(foundFile.fullPath, "utf-8");
      const fileSize = (code.length / 1024).toFixed(2);
      const totalLines = code.split("\n").length;

      await sock.sendMessage(m.chat, { react: { text: "📄", key: m.raw.key } });

      const caption = `📄 *[ 𝑀𝐴𝐷𝐴𝑅𝐴 𝐹𝐼𝐿𝐸 ]*\n\n📁 **اسم الملف:** \`${foundFile.name}\`\n📂 **القسم:** \`${foundFile.category}\`\n📦 **الحجم:** ${fileSize} KB\n📝 **الأسطر:** ${totalLines} سطر\n\n\`\`\`javascript\n${code}\n\`\`\``;

      return sock.sendMessage(m.chat, { text: caption }, { quoted: m.raw });
    }

    // 4. إضافة ملف جديد أو تعديله بالرد
    if (["اضف", "اضافه", "اضافة", "add"].includes(action)) {
      const quoted = m.quoted;
      if (!quoted) {
        return sock.sendMessage(m.chat, { text: "❌ قم بالرد على الكود أو الملف المراد إضافته مع كتابة *بلوقن اضف*" }, { quoted: m.raw });
      }

      let code = "";
      let fileName = nameArg ? `${nameArg.replace(/\.js$/i, "")}.js` : "";

      const rawQuotedMsg = m.raw?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const docMsg = rawQuotedMsg?.documentMessage || rawQuotedMsg?.documentWithCaptionMessage?.message?.documentMessage;

      if (docMsg) {
        try {
          const stream = await downloadContentFromMessage(docMsg, "document");
          const chunks = [];
          for await (const chunk of stream) chunks.push(chunk);
          code = Buffer.concat(chunks).toString("utf-8");

          if (!fileName) {
            const baseName = (docMsg.fileName || `plugin_${Date.now()}`).replace(/\.js$/i, "");
            fileName = `${baseName}.js`;
          }
        } catch (err) {
          return sock.sendMessage(m.chat, { text: `❌ فشل تحميل الملف: ${err.message}` }, { quoted: m.raw });
        }
      } else {
        code = m.quoted.text || "";
        if (!code.trim()) {
          return sock.sendMessage(m.chat, { text: "❌ الرسالة المحددة لا تحتوي على نص أو كود برمجي." }, { quoted: m.raw });
        }

        if (!fileName) {
          const matchCmd = code.match(/command:\s*\[?['"`]([^'"`]+)['"`]/);
          if (matchCmd) {
            fileName = `${matchCmd[1]}.js`;
          } else {
            fileName = `plugin_${Date.now().toString(36)}.js`;
          }
        }
      }

      const foundFile = findPlugin(fileName.replace(/\.js$/i, ""));
      const savePath = foundFile ? foundFile.fullPath : path.join(PLUGINS_DIR, fileName);
      const isEdit = fs.existsSync(savePath);

      fs.writeFileSync(savePath, code, "utf-8");

      const fileSize = (code.length / 1024).toFixed(2);
      const lineCount = code.split("\n").length;

      await sock.sendMessage(m.chat, { react: { text: "✅", key: m.raw.key } });

      return sock.sendMessage(m.chat, {
        text: `${isEdit ? "✏️ *[ تم تعديل البلوقن ]*" : "✅ *[ تم إضافة البلوقن ]*"}\n\n📄 **الملف:** \`${fileName}\`\n📦 **الحجم:** ${fileSize} KB\n📝 **الأسطر:** ${lineCount} سطر`
      }, { quoted: m.raw });
    }

    // 5. حذف ملف
    if (["حذف", "delete", "del", "remove"].includes(action)) {
      if (!nameArg) {
        return sock.sendMessage(m.chat, { text: "❌ اكتب اسم البلوقن المراد حذفه.\nمثال: *بلوقن حذف test*" }, { quoted: m.raw });
      }

      const foundFile = findPlugin(nameArg);
      if (!foundFile) {
        return sock.sendMessage(m.chat, { text: `❌ الملف "*${nameArg}*" غير موجود.` }, { quoted: m.raw });
      }

      fs.unlinkSync(foundFile.fullPath);

      await sock.sendMessage(m.chat, { react: { text: "🗑️", key: m.raw.key } });

      return sock.sendMessage(m.chat, {
        text: `🗑️ *[ تم حذف البلوقن بنجاح ]*\n\n📄 **الملف:** \`${foundFile.name}\`\n📂 **القسم:** \`${foundFile.category}\``
      }, { quoted: m.raw });
    }
  }
};
