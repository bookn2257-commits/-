import fs from 'fs';
import path from 'path';

export default {
  command: ['نسخة_احتياطية'],
  category: 'المالك',
  description: 'يرسل نسخة من ملف قاعدة البيانات (الإعدادات والتحذيرات) لمالك البوت',
  ownerOnly: true,
  execute: async (sock, m) => {
    const dbPath = path.join(process.cwd(), 'database.json');
    if (!fs.existsSync(dbPath)) return m.reply('❌ ما فيه بيانات محفوظة بعد.');
    const buffer = fs.readFileSync(dbPath);
    await sock.sendMessage(m.chat, {
      document: buffer,
      fileName: 'database.json',
      mimetype: 'application/json',
    }, { quoted: m.raw });
  },
};
