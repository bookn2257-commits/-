import { unblockUser } from '../../lib/db.js';

export default {
  command: ['فك_حظر_مستخدم'],
  category: 'المالك',
  description: 'يفك الحظر عن رقم (مالك البوت فقط). رد على رسالته أو منشن',
  ownerOnly: true,
  execute: async (sock, m, args, { args_text }) => {
    const target = m.mentionedJid[0] || m.quoted?.sender || (args_text ? `${args_text.replace(/[^0-9]/g, '')}@s.whatsapp.net` : null);
    if (!target) return m.reply('❌ رد على رسالته، أو اعمله منشن، أو اكتب رقمه بعد الأمر.');
    unblockUser(target);
    await m.reply('✅ تم فك الحظر.');
  },
};
