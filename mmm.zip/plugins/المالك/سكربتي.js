import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';

export default {
  command: ['نسخة', 'نسخة_احتياطية', 'backup', 'سكربتي'],
  category: 'المالك',
  description: 'ضغط ملفات البوت وإرسالها كملف zip بدون المكاتب أو المجلدات المؤقتة',
  ownerOnly: true,
  execute: async (sock, m) => {
    await m.reply('📦 جاري ضغط السكربت... انتظر لحظة.');

    const fileName = `Bot_Backup_${Date.now()}.zip`;
    const outputPath = path.resolve(`./${fileName}`);

    // قائمة الاستبعادات الصارمة لمنع ضغط المكاتب، الجلسة، والملفات المؤقتة الضخمة
    const excludes = [
      'node_modules',
      'session',
      '.git',
      '.npm',
      '.cache',
      '.config',
      '*.zip',
      '*.tar.gz',
      '*.log'
    ];

    // بناء أمر الاستبعاد مع أداة zip
    const excludeFlags = excludes.map((item) => `-x "${item}/*" "${item}"`).join(' ');
    const zipCommand = `zip -r "${fileName}" . ${excludeFlags}`;

    exec(zipCommand, async (err) => {
      if (err) {
        // في حال عدم وجود zip، نستخدم tar مع تجاهل التحذيرات اللحظية
        const tarFileName = `𝑀𝐴𝐷𝐴𝑅𝐴 𝐵🌀𝑇${Date.now()}.tar.gz`;
        const tarPath = path.resolve(`./${tarFileName}`);
        
        const tarExcludes = excludes.map((item) => `--exclude='${item}'`).join(' ');
        // إضافة --warning=no-file-changed لمنع توقف التصدير عند تعديل الملفات المؤقتة
        const tarCommand = `tar ${tarExcludes} --warning=no-file-changed -czvf "${tarFileName}" .`;

        return exec(tarCommand, async (tarErr) => {
          if (tarErr && !fs.existsSync(tarPath)) {
            return await m.reply(`❌ فشل الضغط حتى بعد الاستبعاد!\n${tarErr.message}`);
          }

          await sendFileAndCleanup(sock, m, tarPath, tarFileName, 'application/gzip');
        });
      }

      await sendFileAndCleanup(sock, m, outputPath, fileName, 'application/zip');
    });
  },
};

async function sendFileAndCleanup(sock, m, filePath, fileName, mimetype) {
  try {
    await sock.sendMessage(
      m.chat,
      {
        document: fs.readFileSync(filePath),
        mimetype: mimetype,
        fileName: fileName,
        caption: '✅ تم ضغط السكربت بنجاح وتصفية المجلدات غير الضرورية (.npm, node_modules, session)!',
      },
      { quoted: m.raw }
    );
  } catch (e) {
    await m.reply(`❌ حدث خطأ أثناء إرسال الملف: ${e.message}`);
  } finally {
    // إزالة الملف المضغوط من السيرفر فوراً بعد الانتهاء
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  }
}
