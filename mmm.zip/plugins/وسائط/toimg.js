import sharp from 'sharp';

export default {
  command: ['لصورة'],
  category: 'وسائط',
  description: 'يحوّل ستيكر (غير متحرك) إلى صورة. رد على الستيكر بالأمر',
  execute: async (sock, m) => {
    const buffer = await m.downloadMedia();
    if (!buffer) return m.reply('❌ رد على ستيكر بهذا الأمر.');

    try {
      const imgBuffer = await sharp(buffer).png().toBuffer();
      await sock.sendMessage(m.chat, { image: imgBuffer }, { quoted: m.raw });
    } catch (err) {
      await m.reply('⚠️ ما قدرت أحوّلها (تأكد إنها ستيكر ثابت مو متحرك).');
    }
  },
};
