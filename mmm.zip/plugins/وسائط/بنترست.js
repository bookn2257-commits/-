// plugins/pinterest.js
// 𝑀𝐴𝐷𝐴𝑅𝐴 𝐵🌀𝑇 - Pinterest 📌

import axios from 'axios';
import { exec } from 'child_process';
import { promisify } from 'util';
import { unlinkSync, existsSync, statSync } from 'fs';
import { join } from 'path';
import { tmpdir } from 'os';
import {
  proto,
  generateWAMessageFromContent,
  generateWAMessageContent,
} from '@whiskeysockets/baileys';
import { config } from '../../config.js';

const execAsync = promisify(exec);
const YTDLP_PATH = '/home/container/yt-dlp';
const COOKIES_PATH = '/home/container/cookies/pinterest.txt';

// ═══════════════════════════════════════
// سكرابر Pinterest الرسمي
// ═══════════════════════════════════════
const PINTEREST_BASE = 'https://www.pinterest.com';
const PINTEREST_SEARCH_PATH = '/resource/BaseSearchResource/get/';
const PINTEREST_HEADERS = {
  accept: 'application/json, text/javascript, */*, q=0.01',
  referer: 'https://www.pinterest.com/',
  'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
  'x-app-version': 'a9522f',
  'x-pinterest-appstate': 'active',
  'x-pinterest-pws-handler': 'www/[username]/[slug].js',
  'x-requested-with': 'XMLHttpRequest',
};

async function getPinterestCookies() {
  try {
    const res = await axios.get(PINTEREST_BASE, { timeout: 15000 });
    const setCookies = res.headers['set-cookie'];
    if (!setCookies) return null;
    return setCookies.map((c) => c.split(';')[0].trim()).join('; ');
  } catch {
    return null;
  }
}

async function searchPinterest(query, needed = 30) {
  const images = [];
  const cookies = await getPinterestCookies();
  if (!cookies) return images;

  let bookmarks = [''];
  let attempts = 0;
  const maxAttempts = 10;

  while (images.length < needed && bookmarks.length && attempts < maxAttempts) {
    attempts++;
    try {
      const params = {
        source_url: `/search/pins/?q=${encodeURIComponent(query)}`,
        data: JSON.stringify({
          options: { isPrefetch: false, query, scope: 'pins', bookmarks, page_size: 50 },
          context: {},
        }),
        _: Date.now(),
      };

      const { data } = await axios.get(`${PINTEREST_BASE}${PINTEREST_SEARCH_PATH}`, {
        headers: { ...PINTEREST_HEADERS, cookie: cookies },
        params,
        timeout: 15000,
      });

      const results = data?.resource_response?.data?.results?.filter((v) => v?.images?.orig?.url) || [];
      if (!results.length) break;

      for (const r of results) {
        images.push(r.images.orig.url);
        if (images.length >= needed) break;
      }

      const nextBookmark = data?.resource_response?.bookmark;
      if (!nextBookmark || nextBookmark === '-end-') break;
      bookmarks = [nextBookmark];
    } catch {
      break;
    }
  }

  return [...new Set(images)].slice(0, needed);
}

// ═══════════════════════════════════════
// الأمر بنمط بوتك (madara-bot-original)
// ═══════════════════════════════════════
export default {
  command: ['بنترست', 'بينترست', 'بينتر', 'pinterest'],
  category: 'وسائط',
  description: 'يبحث عن صور بنترست أو يحمّل فيديو من رابط بنترست',
  execute: async (sock, m, args, { args_text }) => {
    const react = async (emoji) => {
      try {
        await sock.sendMessage(m.chat, { react: { text: emoji, key: m.raw.key } });
      } catch {}
    };

    if (!args_text) {
      return m.reply(
        `📌 *Pinterest — ${config.botName}*\n\n` +
        `🔍 بحث صور: .بنترست <كلمة>\n` +
        `📌 تحميل فيديو: .بنترست <رابط>`
      );
    }

    // تحميل فيديو من الرابط
    if (args_text.includes('pin.it') || args_text.includes('pinterest.com/pin/')) {
      await react('⏳');
      await m.reply('⏳ جاري تحميل الفيديو...');

      try {
        const outputPath = join(tmpdir(), `pin_${Date.now()}.mp4`);
        const cmd = `export PATH=$HOME/.deno/bin:$PATH && ${YTDLP_PATH} -o ${outputPath} ${args_text} --cookies ${COOKIES_PATH} --no-playlist --force-overwrites --no-cookies --sleep-interval 5 --user-agent "Mozilla/5.0"`;
        await execAsync(cmd, { timeout: 180000 });

        if (!existsSync(outputPath)) throw new Error('فشل');
        const sizeMB = (statSync(outputPath).size / 1048576).toFixed(2);

        await sock.sendMessage(
          m.chat,
          { video: { url: outputPath }, caption: `✅ تم التحميل بواسطة ${config.botName} | ${sizeMB} MB` },
          { quoted: m.raw }
        );
        await react('✅');
        try { unlinkSync(outputPath); } catch {}
      } catch (e) {
        await react('❌');
        m.reply('❌ فشل التحميل');
      }
      return;
    }

    // بحث صور
    await react('🔍');
    await m.reply(`🔍 ${config.botName} تبحث عن الصور...`);

    try {
      const images = await searchPinterest(args_text, 30);

      if (!images || images.length === 0) {
        await react('❌');
        return m.reply('❌ لا توجد نتائج');
      }

      let cards = [];

      for (let i = 0; i < images.length; i++) {
        try {
          const imgRes = await axios.get(images[i], {
            responseType: 'arraybuffer',
            headers: { 'User-Agent': 'Mozilla/5.0' },
            timeout: 15000,
          });

          const buffer = Buffer.from(imgRes.data);
          if (buffer.length < 1000) continue;

          const { imageMessage } = await generateWAMessageContent(
            { image: buffer },
            { upload: sock.waUploadToServer }
          );

          if (!imageMessage) continue;

          cards.push({
            body: proto.Message.InteractiveMessage.Body.fromObject({
              text: `📸 صورة ${i + 1} | 🔎 ${args_text}`,
            }),
            header: proto.Message.InteractiveMessage.Header.fromObject({
              hasMediaAttachment: true,
              imageMessage,
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
              buttons: [
                {
                  name: 'cta_url',
                  buttonParamsJson: JSON.stringify({
                    display_text: '📌 فتح في Pinterest',
                    url: 'https://www.pinterest.com/search/pins/?q=' + encodeURIComponent(args_text),
                  }),
                },
              ],
            }),
          });
        } catch {
          continue;
        }
      }

      if (cards.length === 0) {
        await react('❌');
        return m.reply('❌ فشل تحميل الصور');
      }

      const finalMessage = generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.create({
                  text: `🔍 نتائج: ${args_text}\n📸 ${cards.length} صورة\n⚡ ${config.botName}`,
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({ text: config.botName }),
                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards }),
              }),
            },
          },
        },
        { quoted: m.raw }
      );

      const isGroup = m.chat.endsWith('@g.us');
const additionalNodes = [
  {
    tag: 'biz',
    attrs: {},
    content: [
      {
        tag: 'interactive',
        attrs: { type: 'native_flow', v: '1' },
        content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
      },
    ],
  },
];
if (!isGroup) additionalNodes.push({ tag: 'bot', attrs: { biz_bot: '1' } });

await sock.relayMessage(m.chat, finalMessage.message, {
  messageId: finalMessage.key.id,
  additionalNodes,
});
await react('✅');
    } catch (e) {
      console.error(e);
      await react('❌');
      m.reply('❌ خطأ في البحث');
    }
  },
};