import { Sticker, StickerTypes } from 'wa-sticker-formatter';
import { config } from '../../config.js';

export default {
  command: ['ستيكر'],
  category: 'وسائط',
  description: 'يحوّل صورة أو فيديو قصير لستيكر (أرسل الوسائط أو رد عليها بالأمر)',
  execute: async (sock, m) => {
    const buffer = await m.downloadMedia();
    if (!buffer) return m.reply('❌ أرسل صورة/فيديو قصير مع الأمر أو رد على وحدة منهم.');

    try {
      const sticker = new Sticker(buffer, {
        pack: config.botName,
        author: config.developer,
        type: StickerTypes.FULL,
        quality: 70,
      });
      const stickerBuffer = await sticker.toBuffer();
      await sock.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m.raw });
    } catch (err) {
      await m.reply('⚠️ ما قدرت أحوّلها لستيكر. تأكد إنها صورة أو فيديو قصير (أقل من 10 ثواني).');
    }
  },
};
