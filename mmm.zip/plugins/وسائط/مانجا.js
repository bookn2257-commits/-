import { searchManga } from '../../lib/manga.js';
import { createSession, sendGalleryItem } from '../../lib/gallery.js';

export default {
  command: ['مانجا'],
  category: 'وسائط',
  description: 'يبحث عن مانجا ويعرض معلوماتها وغلافها. مثال: .مانجا ناروتو',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب اسم المانجا بعد الأمر. مثال: .مانجا ناروتو');
    await m.reply('⏳ جاري البحث...');
    try {
      const manga = await searchManga(args_text.trim(), 'ja');
      if (!manga) return m.reply('❌ ما لقيت هذي المانجا.');

      const caption =
        `📖 ${manga.title}\n` +
        `📌 الحالة: ${manga.status || 'غير معروف'}${manga.year ? ` | 📅 ${manga.year}` : ''}\n` +
        `🏷️ ${manga.tags.join('، ') || '-'}\n\n` +
        `${manga.description}`;

      const items = [{ url: manga.coverUrl || 'https://mangadex.org/img/brand/mascot.png', caption, link: manga.link }];
      const sessionId = createSession(items, manga.title);
      await sendGalleryItem(sock, m.chat, sessionId, m.raw);
    } catch (err) {
      await m.reply(`⚠️ ${err.message}`);
    }
  },
};
