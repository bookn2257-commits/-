import { searchManga } from '../../lib/manga.js';
import { createSession, sendGalleryItem } from '../../lib/gallery.js';

export default {
  command: ['مانهوا'],
  category: 'وسائط',
  description: 'يبحث عن مانهوا كورية ويعرض معلوماتها وغلافها. مثال: .مانهوا سولو ليفلنق',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب اسم المانهوا بعد الأمر. مثال: .مانهوا Solo Leveling');
    await m.reply('⏳ جاري البحث...');
    try {
      const manga = await searchManga(args_text.trim(), 'ko');
      if (!manga) return m.reply('❌ ما لقيت هذي المانهوا.');

      const caption =
        `📖 ${manga.title}\n` +
        `📌 الحالة: ${manga.status || 'غير معروف'}${manga.year ? ` | 📅 ${manga.year}` : ''}\n` +
        `🏷️ ${manga.tags.join('، ') || '-'}\n\n` +
        `${manga.description}`;

      const items = [{ url: manga.coverUrl || 'https://mangadex.org/img/brand/mascot.png', caption, link: manga.link }];
      const sessionId = createSession(items, manga.title);
      await sendGalleryItem(sock, m.chat, sessionId, m.raw);
    } catch (err) {
      await m.reply(`⚠️ ${err.message}`);
    }
  },
};
