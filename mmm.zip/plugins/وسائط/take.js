import { Sticker, StickerTypes } from 'wa-sticker-formatter';
import { config } from '../../config.js';

export default {
  command: ['خذ'],
  category: 'وسائط',
  description: 'يأخذ ستيكر ويعيد تسميته باسم بوتك. رد على الستيكر بالأمر',
  execute: async (sock, m, args, { args_text }) => {
    const buffer = await m.downloadMedia();
    if (!buffer) return m.reply('❌ رد على ستيكر بهذا الأمر.');

    try {
      const [pack, author] = args_text.includes('|')
        ? args_text.split('|').map((s) => s.trim())
        : [config.botName, config.developer];

      const sticker = new Sticker(buffer, {
        pack: pack || config.botName,
        author: author || config.developer,
        type: StickerTypes.FULL,
        quality: 70,
      });
      const stickerBuffer = await sticker.toBuffer();
      await sock.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m.raw });
    } catch (err) {
      await m.reply('⚠️ ما قدرت أعيد تسميته.');
    }
  },
};
