import { createSession, sendGalleryItem } from '../../lib/gallery.js';

export default {
  command: ['ايديت'],
  category: 'وسائط',
  description: 'رابط تيك توك = فيديو مباشر بدون علامة مائية. اسم بس = بحث صور/GIFs متعلقة (معرض تفاعلي)',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ حط رابط تيك توك أو اكتب اسم للبحث. مثال: .ايديت ناروتو');

    // حالة 1: رابط تيك توك مباشر — فيديو حقيقي بدون علامة مائية
    if (args_text.includes('tiktok.com')) {
      await m.reply('⏳ جاري الجلب...');
      try {
        const { ttdl } = await import('btch-downloader');
        const result = await ttdl(args_text.trim());
        const videoUrl = result?.video?.[0] || result?.video_hd || result?.video;
        if (!videoUrl) return m.reply('❌ ما قدرت أجيب الفيديو من هذا الرابط.');
        await sock.sendMessage(m.chat, { video: { url: videoUrl }, caption: `✅ ${result?.title || ''}` }, { quoted: m.raw });
      } catch (err) {
        await m.reply(`⚠️ صار خطأ: ${err.message}`);
      }
      return;
    }

    // حالة 2: بحث بالاسم — ما فيه API حقيقي يبحث فيديوهات "إيديت" بالاسم من كل المواقع
    // (هذا غير متوفر مجانًا لأي مطور)، فنعرض بدل هذا صور/GIFs متعلقة كمعرض تفاعلي
    await m.reply('ℹ️ ما فيه بحث فيديوهات حقيقي بالاسم متاح مجانًا حاليًا، بجيب لك صور/GIFs متعلقة بدلها...');
    try {
      const { pinterest } = await import('btch-downloader');
      const result = await pinterest(`${args_text.trim()} edit`);

      let raw = [];
      if (Array.isArray(result)) raw = result;
      else if (result?.data && Array.isArray(result.data)) raw = result.data;
      else if (result?.url) raw = [result];

      const items = raw
        .map((r) => {
          const url = typeof r === 'string' ? r : r.url || r.image || r.download_url;
          return url ? { url } : null;
        })
        .filter(Boolean)
        .slice(0, 30);

      if (items.length === 0) return m.reply('❌ ما لقيت نتائج.');

      const sessionId = createSession(items, `إيديت: ${args_text}`);
      await sendGalleryItem(sock, m.chat, sessionId, m.raw);
    } catch (err) {
      await m.reply(`⚠️ صار خطأ: ${err.message}`);
    }
  },
};
