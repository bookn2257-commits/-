export default {
  command: ['منشن_الكل'],
  category: 'إدارة الجروب',
  description: 'يعمل منشن لكل أعضاء الجروب مع رسالة',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m, args, { args_text }) => {
    const meta = await sock.groupMetadata(m.chat);
    const mentions = meta.participants.map((p) => p.id);
    let text = `📢 ${args_text || 'تنبيه للجميع'}\n\n`;
    for (const p of meta.participants) {
      text += `• @${p.id.split('@')[0]}\n`;
    }
    await sock.sendMessage(m.chat, { text, mentions }, { quoted: m.raw });
  },
};
