export default {
  command: ['اسم_الجروب'],
  category: 'إدارة الجروب',
  description: 'يغيّر اسم الجروب. الاستخدام: .setname الاسم الجديد',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب الاسم الجديد بعد الأمر.');
    await sock.groupUpdateSubject(m.chat, args_text);
    await m.reply('✅ تم تغيير اسم الجروب.');
  },
};
