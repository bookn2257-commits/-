import { getWarnings } from '../../lib/db.js';

export default {
  command: ['عدد_التحذيرات'],
  category: 'إدارة الجروب',
  description: 'يعرض عدد تحذيرات عضو (رد على رسالته أو منشن)',
  groupOnly: true,
  execute: async (sock, m) => {
    const target = m.mentionedJid[0] || m.quoted?.sender || m.sender;
    const count = getWarnings(m.chat, target);
    await sock.sendMessage(m.chat, { text: `⚠️ عدد تحذيرات @${target.split('@')[0]}: ${count}/3`, mentions: [target] });
  },
};
