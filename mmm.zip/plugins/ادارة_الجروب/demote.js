export default {
  command: ['تنزيل'],
  category: 'إدارة الجروب',
  description: 'ينزّل أدمن لعضو عادي (رد على رسالته أو منشن)',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m) => {
    const target = m.mentionedJid[0] || m.quoted?.sender;
    if (!target) return m.reply('❌ رد على رسالة الشخص أو اعمله منشن.');
    await sock.groupParticipantsUpdate(m.chat, [target], 'demote');
    await m.reply('✅ تم تنزيله من الأدمنية.');
  },
};
