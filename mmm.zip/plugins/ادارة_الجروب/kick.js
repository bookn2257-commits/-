export default {
  command: ['طرد'],
  category: 'إدارة الجروب',
  description: 'يطرد عضو من الجروب (رد على رسالته أو منشن)',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m) => {
    const target = m.mentionedJid[0] || m.quoted?.sender;
    if (!target) return m.reply('❌ رد على رسالة الشخص أو اعمله منشن.');
    await sock.groupParticipantsUpdate(m.chat, [target], 'remove');
    await m.reply('✅ تم الطرد.');
  },
};
