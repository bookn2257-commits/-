import { setGroupSetting } from '../../lib/db.js';

export default {
  command: ['منع_الشتم'],
  category: 'إدارة الجروب',
  description: 'يحذف تلقائي أي رسالة فيها كلام بذيء. مثال: .منع_الشتم on',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m, args, { args_text }) => {
    const val = args_text.trim().toLowerCase();
    if (!['on', 'off'].includes(val)) return m.reply('❌ اكتب: .منع_الشتم on  أو  .منع_الشتم off');
    setGroupSetting(m.chat, 'antibadword', val === 'on');
    await m.reply(`✅ تم ${val === 'on' ? 'تفعيل' : 'تعطيل'} منع الشتم.`);
  },
};
