import { getGroupSettings, setGroupSetting } from '../../lib/db.js';
import { sendButtons } from '../../lib/menus.js';

const PROTECTIONS = {
  antilink: '🔗 مضاد الروابط',
  anticontact: '👤 مضاد جهات الاتصال',
  antisticker: '🖼️ مضاد الملصقات',
  antiimage: '📷 مضاد الصور',
  antivideo: '🎥 مضاد الفيديوهات',
};

export default {
  command: ['الحماية', 'مضاد', 'toggle_protect'],
  category: 'إدارة الجروب',
  description: 'إدارة ونظام حماية الجروب بالكامل',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m, args) => {
    const key = args[0];

    // إذا تم الضغط على زر التبديل وكان المفتاح موجوداً في القائمة
    if (key && PROTECTIONS[key]) {
      const settings = getGroupSettings(m.chat);
      const newValue = !settings[key];
      setGroupSetting(m.chat, key, newValue);
    }

    // بناء واجهة العرض والأزرار الحالية
    const updated = getGroupSettings(m.chat);
    let text = `╭━━〔 🛡️ نظام الحماية 〕━━⬣\n`;
    for (const [k, label] of Object.entries(PROTECTIONS)) {
      text += `│ ${label}: ${updated[k] ? '✅ مفعّل' : '❌ معطّل'}\n`;
    }
    text += `╰━━━━━━━━━━━━━━⬣\n\nاضغط الأزرار بالأسفل لتبديل حالة الحماية 👇`;

    const buttons = Object.entries(PROTECTIONS).map(([k, label]) => ({
      id: `.toggle_protect ${k}`,
      text: `${updated[k] ? '🔴 إيقاف' : '🟢 تفعيل'} ${label}`,
    }));

    await sendButtons(sock, m.chat, { text, buttons, quoted: m.raw });
  },
};
