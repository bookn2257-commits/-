import { setGroupSetting } from '../../lib/db.js';

export default {
  command: ['نص_الترحيب'],
  category: 'إدارة الجروب',
  description: 'يخصّص نص الترحيب. استخدم @user بالنص عشان يستبدل باسم العضو. مثال: .نص_الترحيب حياك @user بجروبنا',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب نص الترحيب بعد الأمر (استخدم @user لموقع اسم العضو).');
    setGroupSetting(m.chat, 'welcomeText', args_text);
    await m.reply('✅ تم حفظ نص الترحيب الجديد.');
  },
};
