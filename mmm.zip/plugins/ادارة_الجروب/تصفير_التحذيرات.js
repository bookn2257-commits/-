import { resetWarnings } from '../../lib/db.js';

export default {
  command: ['تصفير_التحذيرات'],
  category: 'إدارة الجروب',
  description: 'يصفّر تحذيرات عضو (رد على رسالته أو منشن)',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m) => {
    const target = m.mentionedJid[0] || m.quoted?.sender;
    if (!target) return m.reply('❌ رد على رسالة الشخص أو اعمله منشن.');
    resetWarnings(m.chat, target);
    await m.reply('✅ تم تصفير التحذيرات.');
  },
};
