export default {
  command: ['قائمة_الأدمنية'],
  category: 'إدارة الجروب',
  description: 'يعرض قائمة أدمنية الجروب',
  groupOnly: true,
  execute: async (sock, m) => {
    const meta = await sock.groupMetadata(m.chat);
    const admins = meta.participants.filter((p) => p.admin);
    if (admins.length === 0) return m.reply('❌ ما فيه أدمنية بهذا الجروب.');

    let text = `👑 أدمنية الجروب (${admins.length}):\n\n`;
    for (const a of admins) text += `• @${a.id.split('@')[0]}\n`;
    await sock.sendMessage(m.chat, { text, mentions: admins.map((a) => a.id) }, { quoted: m.raw });
  },
};
