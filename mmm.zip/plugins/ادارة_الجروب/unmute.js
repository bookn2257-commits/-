export default {
  command: ['فك_الكتم'],
  category: 'إدارة الجروب',
  description: 'يخلي كل الأعضاء يقدرون يرسلون بالجروب',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m) => {
    await sock.groupSettingUpdate(m.chat, 'not_announcement');
    await m.reply('🔊 تم فك الكتم — كل الأعضاء يقدرون يرسلون.');
  },
};
