export default {
  command: ['منشن_مخفي'],
  category: 'إدارة الجروب',
  description: 'يرسل رسالة توصل لكل الأعضاء بدون ما تظهر أسماءهم بالنص',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m, args, { args_text }) => {
    const meta = await sock.groupMetadata(m.chat);
    const mentions = meta.participants.map((p) => p.id);
    await sock.sendMessage(m.chat, { text: args_text || '📢', mentions }, { quoted: m.raw });
  },
};
