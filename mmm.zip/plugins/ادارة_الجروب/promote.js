export default {
  command: ['رفع'],
  category: 'إدارة الجروب',
  description: 'يرفع عضو لأدمن (رد على رسالته أو منشن)',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m) => {
    const target = m.mentionedJid[0] || m.quoted?.sender;
    if (!target) return m.reply('❌ رد على رسالة الشخص أو اعمله منشن.');
    await sock.groupParticipantsUpdate(m.chat, [target], 'promote');
    await m.reply('✅ تم الترقية لأدمن.');
  },
};
