export default {
  command: ['وصف_الجروب'],
  category: 'إدارة الجروب',
  description: 'يغيّر وصف الجروب. الاستخدام: .setdesc الوصف الجديد',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب الوصف الجديد بعد الأمر.');
    await sock.groupUpdateDescription(m.chat, args_text);
    await m.reply('✅ تم تغيير وصف الجروب.');
  },
};
