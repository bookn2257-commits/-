export default {
  command: ['تجديد_الرابط'],
  category: 'إدارة الجروب',
  description: 'يلغي رابط الجروب القديم ويسوي رابط جديد',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m) => {
    await sock.groupRevokeInvite(m.chat);
    const code = await sock.groupInviteCode(m.chat);
    await m.reply(`✅ تم إلغاء الرابط القديم. الرابط الجديد:\nhttps://chat.whatsapp.com/${code}`);
  },
};
