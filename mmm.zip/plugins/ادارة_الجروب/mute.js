export default {
  command: ['كتم_الجروب'],
  category: 'إدارة الجروب',
  description: 'يخلي الأدمنية بس يقدرون يرسلون بالجروب',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m) => {
    await sock.groupSettingUpdate(m.chat, 'announcement');
    await m.reply('🔇 تم كتم الجروب — الأدمنية بس يقدرون يرسلون.');
  },
};
