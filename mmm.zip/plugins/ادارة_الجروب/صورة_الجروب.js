export default {
  command: ['صورة_الجروب'],
  category: 'إدارة الجروب',
  description: 'يغيّر صورة الجروب. رد على صورة بالأمر',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m) => {
    const buffer = await m.downloadMedia();
    if (!buffer) return m.reply('❌ رد على صورة بهذا الأمر.');
    try {
      await sock.updateProfilePicture(m.chat, buffer);
      await m.reply('✅ تم تغيير صورة الجروب.');
    } catch {
      await m.reply('⚠️ ما قدرت أغيّر الصورة. تأكد إن البوت أدمن.');
    }
  },
};
