import { addWarning, getWarnings } from '../../lib/db.js';

export default {
  command: ['تحذير'],
  category: 'إدارة الجروب',
  description: 'يحذّر عضو، وبعد 3 تحذيرات ينطرد تلقائيًا (رد على رسالته أو منشن)',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m) => {
    const target = m.mentionedJid[0] || m.quoted?.sender;
    if (!target) return m.reply('❌ رد على رسالة الشخص أو اعمله منشن.');

    const count = addWarning(m.chat, target);
    if (count >= 3) {
      await sock.groupParticipantsUpdate(m.chat, [target], 'remove');
      await sock.sendMessage(m.chat, { text: `🚫 تم طرد @${target.split('@')[0]} بعد وصوله لـ3 تحذيرات.`, mentions: [target] });
    } else {
      await sock.sendMessage(m.chat, { text: `⚠️ تحذير لـ @${target.split('@')[0]} (${count}/3)`, mentions: [target] });
    }
  },
};
