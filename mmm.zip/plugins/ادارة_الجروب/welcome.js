import { getGroupSettings, setGroupSetting } from '../../lib/db.js';

export default {
  command: ['ترحيب'],
  category: 'إدارة الجروب',
  description: 'يفعّل/يعطّل رسالة الترحيب بالأعضاء الجدد. مثال: .welcome on / .welcome off',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m, args, { args_text }) => {
    const val = args_text.trim().toLowerCase();
    if (!['on', 'off'].includes(val)) return m.reply('❌ اكتب: .welcome on  أو  .welcome off');
    setGroupSetting(m.chat, 'welcome', val === 'on');
    await m.reply(`✅ تم ${val === 'on' ? 'تفعيل' : 'تعطيل'} الترحيب.`);
  },
};
