export default {
  command: ['اضافة'],
  category: 'إدارة الجروب',
  description: 'يضيف رقم للجروب. الاستخدام: .add 9639xxxxxxxx',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m, args, { args_text }) => {
    const num = args_text.replace(/[^0-9]/g, '');
    if (!num) return m.reply('❌ اكتب الرقم بالصيغة الدولية بدون + مثال: .add 9639xxxxxxxx');
    const jid = `${num}@s.whatsapp.net`;
    try {
      await sock.groupParticipantsUpdate(m.chat, [jid], 'add');
      await m.reply('✅ تم إرسال الإضافة.');
    } catch (e) {
      await m.reply('⚠️ ما قدرت أضيفه (ممكن يكون خصوصيته ما تسمح بالإضافة المباشرة).');
    }
  },
};
