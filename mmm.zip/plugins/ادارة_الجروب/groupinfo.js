export default {
  command: ['معلومات_الجروب'],
  category: 'إدارة الجروب',
  description: 'يعرض معلومات عن الجروب الحالي',
  groupOnly: true,
  execute: async (sock, m) => {
    const meta = await sock.groupMetadata(m.chat);
    const admins = meta.participants.filter((p) => p.admin).length;
    await m.reply(
      `╭━━〔 📋 معلومات الجروب 〕━━⬣\n` +
      `│ الاسم: ${meta.subject}\n` +
      `│ عدد الأعضاء: ${meta.participants.length}\n` +
      `│ عدد الأدمنية: ${admins}\n` +
      `│ الوصف: ${meta.desc || 'لا يوجد'}\n` +
      `╰━━━━━━━━━━━━━━⬣`
    );
  },
};
