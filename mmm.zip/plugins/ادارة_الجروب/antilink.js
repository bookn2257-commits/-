import { getGroupSettings, setGroupSetting } from '../../lib/db.js';

export default {
  command: ['منع_الروابط'],
  category: 'إدارة الجروب',
  description: 'يحذف تلقائي أي رسالة فيها رابط جروب واتساب. مثال: .antilink on',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m, args, { args_text }) => {
    const val = args_text.trim().toLowerCase();
    if (!['on', 'off'].includes(val)) return m.reply('❌ اكتب: .antilink on  أو  .antilink off');
    setGroupSetting(m.chat, 'antilink', val === 'on');
    await m.reply(`✅ تم ${val === 'on' ? 'تفعيل' : 'تعطيل'} منع الروابط.`);
  },
};
