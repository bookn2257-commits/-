export default {
  command: ['رابط_الجروب'],
  category: 'إدارة الجروب',
  description: 'يجيب رابط دعوة الجروب',
  groupOnly: true,
  adminOnly: true,
  execute: async (sock, m) => {
    const code = await sock.groupInviteCode(m.chat);
    await m.reply(`🔗 رابط الجروب:\nhttps://chat.whatsapp.com/${code}`);
  },
};
