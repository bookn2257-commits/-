export default {
  command: ['بنق'],
  category: 'عام',
  description: 'يفحص سرعة استجابة البوت',
  execute: async (sock, m) => {
    const start = Date.now();
    await m.reply('🏓 جاري القياس...');
    const speed = Date.now() - start;
    await m.reply(`🏓 السرعة: ${speed}ms`);
  },
};
