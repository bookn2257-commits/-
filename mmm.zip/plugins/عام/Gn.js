import { moveSession, sendGalleryItem } from '../../lib/gallery.js';

export default {
  command: ['gn'],
  category: 'نظام',
  description: 'زر التالي بالمعرض (داخلي)',
  execute: async (sock, m, args) => {
    const sessionId = args[0];
    if (!moveSession(sessionId, 'next')) return m.reply('❌ انتهت صلاحية هذا العرض.');
    await sendGalleryItem(sock, m.chat, sessionId, m.raw);
  },
};
