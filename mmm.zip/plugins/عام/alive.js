import { config } from '../../config.js';

function formatUptime(seconds) {
  const h = Math.floor(seconds / 3600);
  const min = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h} ساعة ${min} دقيقة ${s} ثانية`;
}

export default {
  command: ['شغال', 'حالة'],
  category: 'عام',
  description: 'يعرض حالة تشغيل البوت',
  execute: async (sock, m) => {
    const mem = process.memoryUsage().heapUsed / 1024 / 1024;
    await m.reply(
      `╭━━〔 ${config.botName} 〕━━⬣\n` +
      `│ ✅ البوت شغّال\n` +
      `│ ⏱️ مدة التشغيل: ${formatUptime(process.uptime())}\n` +
      `│ 💾 استهلاك الذاكرة: ${mem.toFixed(2)} MB\n` +
      `╰━━━━━━━━━━━━━━⬣`
    );
  },
};
