export default {
  command: ['رتبتي'],
  category: 'عام',
  description: 'يعرض رتبتك الحالية بالبوت',
  execute: async (sock, m, args, { senderRank }) => {
    await m.reply(`🏅 رتبتك: ${senderRank}`);
  },
};
