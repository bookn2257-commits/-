import { sendList } from '../../lib/menus.js';

const getSyrianDateTime = () => {
  const options = {
    timeZone: 'Asia/Damascus',
    hour12: true,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  };
  const timeStr = new Intl.DateTimeFormat('ar-SY', options).format(new Date());

  const dateOptions = {
    timeZone: 'Asia/Damascus',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  };
  const dateStr = new Intl.DateTimeFormat('ar-SY', dateOptions).format(new Date());

  return { timeStr, dateStr };
};

export default {
  command: ['menu', 'قائمة', 'اوامر', 'الاوامر'],
  category: 'عام',
  description: 'يعرض قائمة الأقسام والخيارات بالأزرار المباشرة',
  execute: async (sock, m, args, { allPlugins }) => {
    const categories = {};
    for (const p of allPlugins) {
      const cat = p.category ? p.category.trim() : 'عام';
      if (!categories[cat]) categories[cat] = [];
      const name = Array.isArray(p.command) ? p.command[0] : p.command;
      categories[cat].push({ name, description: p.description || '' });
    }

    const { timeStr, dateStr } = getSyrianDateTime();
    const rawInput = args.join(' ').trim();

    // 1. القائمة الرئيسية
    if (!rawInput) {
      const categoryRows = Object.keys(categories).map((catName) => ({
        title: `⚡│ قسم ${catName.toUpperCase()}`,
        description: `📂 يحتوي على [ ${categories[catName].length} ] أمر • اضغط للعرض`,
        id: `.menu ${catName}`,
      }));

      // القائمة المنسدلة تحتفظ فقط بالأقسام البرمجية
      const sections = [
        {
          title: '◈───〔 📂 الأقسام البرمجية المتاحة 〕───◈',
          rows: categoryRows,
        },
      ];

      const decoratedText =
        `╭━━━〔 🏛️ *𝑀𝐴𝐷𝐴𝑅𝐴 𝐵🌀𝑇* 🏛️ 〕━━━⬣\n` +
        `│\n` +
        `│ 👤 *المالك والمطور* : 𝑴𝑨𝑹𝑶\n` +
        `│ ⚡ *الحالة* : نشط 🟢\n` +
        `│ ⚙️ *البادئة [Prefix]* : [ . ]\n` +
        `│ 📦 *إجمالي الأوامر* : [ ${allPlugins.length} ] أمر\n` +
        `│ 📁 *عدد الأقسام* : [ ${Object.keys(categories).length} ] أقسام\n` +
        `│\n` +
        `├━━━〔 🕰️ *توقيت دمشق / سوريا* 〕━━━⬣\n` +
        `│ ⏰ *الوقت* : ${timeStr}\n` +
        `│ 📅 *التاريخ* : ${dateStr}\n` +
        `│\n` +
        `╰━━━━━━━━━━━━━━━━━━━━━━⬣\n\n` +
        `✨ *اختر القسم المطلوب من القائمة المنسدلة، أو استخدم الأزرار بالأسفل 👇*`;

      // الأزرار التفاعلية المباشرة تحت القائمة المنسدلة
      const buttons = [
        { id: '.owner', text: '👑│ مطوّر البوت' },
        { id: '.rate_menu', text: '⭐│ تقييم البوت' },
      ];

      return await sendList(sock, m.chat, {
        text: decoratedText,
        footer: `🇸🇾 𝑀𝐴𝐷𝐴𝑅𝐴 𝐵🌀𝑇 • System Online | Damascus Time`,
        title: `👑 𝑀𝐴𝐷𝐴𝑅𝐴 𝐵🌀𝑇 MENU 👑`,
        buttonText: '📜 عرض الأقسام',
        sections,
        buttons,
        quoted: m.raw,
      });
    }

    // 2. تنظيف المدخلات
    let cleanInput = rawInput
      .replace(/^.*قسم\s*/i, '')
      .replace(/\s*يحتوي.*$/i, '')
      .replace(/[⚡|]/g, '')
      .trim()
      .toLowerCase();

    const targetCategory = Object.keys(categories).find((cat) => {
      const c = cat.toLowerCase();
      return c === cleanInput || c.includes(cleanInput) || cleanInput.includes(c);
    });

    if (!targetCategory) {
      return await sock.sendMessage(
        m.chat,
        { text: '⚠️ *عذراً، هذا القسم غير مسجّل ضمن النظام!*' },
        { quoted: m.raw }
      );
    }

    // 3. عرض أوامر القسم
    const commandRows = categories[targetCategory].map((cmd, idx) => ({
      title: `${idx + 1}. .${cmd.name}`,
      description: cmd.description ? cmd.description.slice(0, 60) : 'اضغط للتشغيل',
      id: `.${cmd.name}`,
    }));

    const categorySections = [
      {
        title: `🎯 أجهزة وأوامر [ قسم ${targetCategory} ]`,
        rows: commandRows,
      },
    ];

    const categoryText =
      `╭━━━〔 🎯 *قسم: ${targetCategory.toUpperCase()}* 〕━━━⬣\n` +
      `│\n` +
      `│ 📊 *عدد الأوامر:* [ ${categories[targetCategory].length} ]\n` +
      `│ 🕰️ *التوقيت:* ${timeStr}\n` +
      `│\n` +
      `╰━━━━━━━━━━━━━━━━━━━━━━⬣\n\n` +
      `👇 *اختر الأمر المراد تشغيله من القائمة، أو استخدم الأزرار بالأسفل:*`;

    const buttons = [
      { id: '.menu', text: '🏠 القائمة الرئيسية' },
      { id: '.owner', text: '👑 المطور 𝑴𝑨𝑹𝑶' },
    ];

    return await sendList(sock, m.chat, {
      text: categoryText,
      footer: `⚡ 𝑀𝐴𝐷𝐴𝑅𝐴 𝐵🌀𝑇 • ${targetCategory}`,
      title: `💠 أوامر قسم ${targetCategory}`,
      buttonText: '🎮 قائمة الأوامر',
      sections: categorySections,
      buttons,
      quoted: m.raw,
    });
  },
};
