import { sendGalleryDownload } from '../../lib/gallery.js';

export default {
  command: ['gd'],
  category: 'وسائط',
  description: 'يحمّل العنصر الحالي من معرض الصور',
  execute: async (sock, m, args) => {
    const sessionId = args[0];
    if (!sessionId) return m.reply('❌ لا يوجد جلسة محددة.');
    await sendGalleryDownload(sock, m.chat, sessionId, m.raw);
  },
};