import { RANK_ORDER, listRanked } from '../../lib/ranks.js';

export default {
  command: ['قائمة_الرتب', 'الرتب'],
  category: 'عام',
  description: 'يعرض التسلسل الهرمي لكل الرتب ومن لديه كل رتبة',
  execute: async (sock, m) => {
    const data = listRanked();
    let text = `╭━━〔 🏅 نظام الرتب 〕━━⬣\n`;
    for (const rank of RANK_ORDER) {
      const members = Object.entries(data).filter(([, r]) => r === rank).map(([num]) => num);
      const icon = rank === 'مالك' ? '👑' : '•';
      text += `│ ${icon} ${rank}: ${members.length > 0 ? members.join('، ') : '(لا يوجد)'}\n`;
    }
    text += `╰━━━━━━━━━━━━━━⬣`;
    await m.reply(text);
  },
};
