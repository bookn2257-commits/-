export default {
  command: ['owner', 'المطور', 'المالك', 'مطور'],
  category: 'عام',
  description: 'يعرض بطاقة معلومات المطور والمالك الرسمي للبوت',
  execute: async (sock, m) => {
    const developerNumber = '963998009642';
    const developerJid = `${developerNumber}@s.whatsapp.net`;

    // 1. إرسال جهة اتصال الواتساب (vCard) لسهولة الحفظ
    const vcard =
      'BEGIN:VCARD\n' +
      'VERSION:3.0\n' +
      'FN:𝑴𝑨𝑹𝑶 👑\n' +
      'ORG:𝑀𝐴𝐷𝐴𝑅𝐴 𝐵🌀𝑇 Developer;\n' +
      `TEL;type=CELL;type=VOICE;waid=${developerNumber}:+${developerNumber}\n` +
      'END:VCARD';

    await sock.sendMessage(m.chat, {
      contacts: {
        displayName: '𝑴𝑨𝑹𝑶',
        contacts: [{ vcard }],
      },
    }, { quoted: m.raw });

    // 2. إرسال بطاقة الترحيب الملكية
    const text =
      `╭━━━〔 👑 *DEVELOPER PROFILE* 👑 〕━━━⬣\n` +
      `│\n` +
      `│ 👤 *لقب المطور* : 𝑴𝑨𝑹𝑶\n` +
      `│ 🤖 *اسم البوت* : 𝑀𝐴𝐷𝐴𝑅𝐴 𝐵🌀𝑇\n` +
      `│ 📞 *الرقم المباشر* : +963 998 009 642\n` +
      `│ 🌐 *الدولة* : سوريا 🇸🇾\n` +
      `│ ⚡ *الصفة* : المالك والمنشئ الرسمي\n` +
      `│\n` +
      `╰━━━━━━━━━━━━━━━━━━━━━━━━⬣\n\n` +
      `💬 *لأي استفسار، اقتراح، أو بلاغ عن مشكلة، يمكنك التواصل مباشرة عبر الرقم أعلاه.*`;

    await sock.sendMessage(m.chat, { text }, { quoted: m.raw });
  },
};
