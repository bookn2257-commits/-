import { config } from '../../config.js';

export default {
  command: ['مساعدة', 'شرح'],
  category: 'عام',
  description: 'يشرح طريقة استخدام أمر معيّن',
  execute: async (sock, m, args, { args_text, commandMap }) => {
    if (!args_text) {
      return m.reply(`✏️ اكتب: .help اسم_الأمر\nمثال: .help سكرين`);
    }
    const plugin = commandMap.get(args_text.toLowerCase());
    if (!plugin) return m.reply('❌ ما لقيت هذا الأمر.');

    const names = Array.isArray(plugin.command) ? plugin.command.join(' | ') : plugin.command;
    await m.reply(
      `╭━━〔 📖 شرح أمر 〕━━⬣\n` +
      `│ الاسم: ${names}\n` +
      `│ القسم: ${plugin.category || 'عام'}\n` +
      `│ الوصف: ${plugin.description || 'لا يوجد'}\n` +
      `│ صلاحية المالك فقط: ${plugin.ownerOnly ? 'نعم' : 'لا'}\n` +
      `│ صلاحية أدمن فقط: ${plugin.adminOnly ? 'نعم' : 'لا'}\n` +
      `│ داخل الجروب فقط: ${plugin.groupOnly ? 'نعم' : 'لا'}\n` +
      `╰━━━━━━━━━━━━━━⬣\n${config.botName}`
    );
  },
};
