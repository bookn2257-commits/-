import { moveSession, sendGalleryItem } from '../../lib/gallery.js';

export default {
  command: ['gp'],
  category: 'نظام',
  description: 'زر السابق بالمعرض (داخلي)',
  execute: async (sock, m, args) => {
    const sessionId = args[0];
    if (!moveSession(sessionId, 'prev')) return m.reply('❌ انتهت صلاحية هذا العرض.');
    await sendGalleryItem(sock, m.chat, sessionId, m.raw);
  },
};
