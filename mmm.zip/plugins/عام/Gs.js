import { getSessionItem } from '../../lib/gallery.js';
import { Sticker, StickerTypes } from 'wa-sticker-formatter';
import { config } from '../../config.js';

export default {
  command: ['gs'],
  category: 'نظام',
  description: 'زر تحويل صورة المعرض الحالية لستيكر (داخلي)',
  execute: async (sock, m, args) => {
    const sessionId = args[0];
    const item = getSessionItem(sessionId);
    if (!item) return m.reply('❌ انتهت صلاحية هذا العرض.');

    try {
      const res = await fetch(item.url);
      const buffer = Buffer.from(await res.arrayBuffer());
      const sticker = new Sticker(buffer, {
        pack: config.botName,
        author: config.developer,
        type: StickerTypes.FULL,
        quality: 90,
      });
      const stickerBuffer = await sticker.toBuffer();
      await sock.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m.raw });
    } catch (err) {
      await m.reply('⚠️ ما قدرت أحوّلها لستيكر.');
    }
  },
};
