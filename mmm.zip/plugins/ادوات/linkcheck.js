export default {
  command: ['تحقق_من_رابط'],
  category: 'أدوات',
  description: 'يتحقق هل رابط شغّال ولا لا. مثال: .تحقق_من_رابط https://example.com',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text || !args_text.startsWith('http')) return m.reply('❌ اكتب رابط صحيح يبدأ بـ http.');
    try {
      const res = await fetch(args_text, { method: 'HEAD' });
      await m.reply(res.ok ? `✅ الرابط شغّال (${res.status})` : `⚠️ الرابط يرجع خطأ (${res.status})`);
    } catch {
      await m.reply('❌ الرابط مو شغّال أو ما قدرت أوصله.');
    }
  },
};
