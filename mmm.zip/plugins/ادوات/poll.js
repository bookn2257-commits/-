export default {
  command: ['استفتاء'],
  category: 'أدوات',
  description: 'يسوي استفتاء. مثال: .poll السؤال؟ | خيار1 | خيار2 | خيار3',
  execute: async (sock, m, args, { args_text }) => {
    const parts = args_text.split('|').map((p) => p.trim()).filter(Boolean);
    if (parts.length < 3) return m.reply('❌ الصيغة: .poll السؤال؟ | خيار1 | خيار2');
    const [question, ...options] = parts;
    await sock.sendMessage(m.chat, {
      poll: { name: question, values: options.slice(0, 12), selectableCount: 1 },
    });
  },
};
