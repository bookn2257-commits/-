export default {
  command: ['فك_ترميز'],
  category: 'أدوات',
  description: 'يفك تشفير نص Base64',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب النص المشفّر بعد الأمر.');
    try {
      const decoded = Buffer.from(args_text, 'base64').toString('utf-8');
      await m.reply(`🔓 النتيجة:\n${decoded}`);
    } catch (err) {
      await m.reply('❌ نص Base64 غير صالح.');
    }
  },
};
