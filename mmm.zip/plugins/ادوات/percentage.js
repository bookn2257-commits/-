export default {
  command: ['نسبة_مئوية'],
  category: 'أدوات',
  description: 'يحسب نسبة مئوية. مثال: .نسبة_مئوية 25 من 200',
  execute: async (sock, m, args, { args_text }) => {
    const match = args_text.match(/^([\d.]+)\s+من\s+([\d.]+)$/);
    if (!match) return m.reply('❌ الصيغة: .نسبة_مئوية الرقم من العدد_الكلي\nمثال: .نسبة_مئوية 25 من 200');
    const percent = (parseFloat(match[1]) / parseFloat(match[2])) * 100;
    await m.reply(`📊 النسبة: ${percent.toFixed(2)}%`);
  },
};
