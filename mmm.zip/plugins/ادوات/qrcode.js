import QRCode from 'qrcode';

export default {
  command: ['كيوآر'],
  category: 'أدوات',
  description: 'يولّد رمز QR من نص أو رابط. مثال: .qr https://example.com',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب النص أو الرابط بعد الأمر.');
    try {
      const buffer = await QRCode.toBuffer(args_text, { width: 512 });
      await sock.sendMessage(m.chat, { image: buffer, caption: '✅ تم التوليد' }, { quoted: m.raw });
    } catch (err) {
      await m.reply('⚠️ صار خطأ أثناء التوليد.');
    }
  },
};
