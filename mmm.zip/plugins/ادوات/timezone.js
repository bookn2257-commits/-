const zones = {
  'الرياض': 'Asia/Riyadh',
  'القاهرة': 'Africa/Cairo',
  'دبي': 'Asia/Dubai',
  'لندن': 'Europe/London',
  'نيويورك': 'America/New_York',
  'طوكيو': 'Asia/Tokyo',
  'باريس': 'Europe/Paris',
  'مكة': 'Asia/Riyadh',
};

export default {
  command: ['الوقت_في'],
  category: 'أدوات',
  description: 'يعرض الوقت الحالي بمدينة معيّنة. مثال: .الوقت_في طوكيو',
  execute: async (sock, m, args, { args_text }) => {
    const city = args_text.trim();
    const zone = zones[city];
    if (!zone) {
      return m.reply(`❌ المدن المتاحة حاليًا:\n${Object.keys(zones).join('، ')}`);
    }
    const time = new Date().toLocaleString('ar-EG', { timeZone: zone, dateStyle: 'medium', timeStyle: 'short' });
    await m.reply(`🕐 الوقت الحالي بـ ${city}:\n${time}`);
  },
};
