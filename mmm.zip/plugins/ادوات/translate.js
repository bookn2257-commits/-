export default {
  command: ['ترجمة'],
  category: 'أدوات',
  description: 'يترجم نص للغة معيّنة. مثال: .ترجمة en مرحبا كيف حالك',
  execute: async (sock, m, args, { args_text }) => {
    const match = args_text.match(/^([a-z]{2})\s+([\s\S]+)$/i);
    if (!match) return m.reply('❌ الصيغة: .ترجمة رمز_اللغة النص\nمثال: .ترجمة en مرحبا');
    const [, targetLang, text] = match;

    try {
      const res = await fetch('https://libretranslate.com/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ q: text, source: 'auto', target: targetLang, format: 'text' }),
      });
      if (!res.ok) throw new Error();
      const data = await res.json();
      await m.reply(`🌐 الترجمة:\n${data.translatedText}`);
    } catch {
      await m.reply('⚠️ خدمة الترجمة مو متاحة حاليًا، حاول بعد شوي.');
    }
  },
};
