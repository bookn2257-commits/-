export default {
  command: ['الطقس'],
  category: 'أدوات',
  description: 'يعرض حالة الطقس الحالية بمدينة معيّنة. مثال: .الطقس الرياض',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب اسم المدينة بعد الأمر. مثال: .الطقس الرياض');
    try {
      const geoRes = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(args_text)}&count=1&language=ar`);
      const geoData = await geoRes.json();
      const place = geoData.results?.[0];
      if (!place) return m.reply('❌ ما لقيت هذي المدينة.');

      const wRes = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${place.latitude}&longitude=${place.longitude}&current_weather=true`);
      const wData = await wRes.json();
      const cw = wData.current_weather;

      await m.reply(
        `🌤️ الطقس بـ ${place.name}${place.country ? '، ' + place.country : ''}\n` +
        `🌡️ الحرارة: ${cw.temperature}°C\n` +
        `💨 سرعة الرياح: ${cw.windspeed} كم/س`
      );
    } catch {
      await m.reply('⚠️ ما قدرت أجيب بيانات الطقس حاليًا، حاول بعد شوي.');
    }
  },
};
