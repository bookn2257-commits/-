export default {
  command: ['عملة'],
  category: 'أدوات',
  description: 'يحوّل بين العملات. مثال: .تحويل_عملة 100 USD SAR',
  execute: async (sock, m, args, { args_text }) => {
    const parts = args_text.trim().split(/\s+/);
    if (parts.length !== 3) return m.reply('❌ الصيغة: .تحويل_عملة المبلغ من إلى\nمثال: .تحويل_عملة 100 USD SAR');
    const [amountStr, from, to] = parts;
    const amount = parseFloat(amountStr);
    if (isNaN(amount)) return m.reply('❌ المبلغ لازم يكون رقم.');

    try {
      const res = await fetch(`https://api.exchangerate-api.com/v4/latest/${from.toUpperCase()}`);
      if (!res.ok) throw new Error();
      const data = await res.json();
      const rate = data.rates?.[to.toUpperCase()];
      if (!rate) return m.reply('❌ عملة غير معروفة. تأكد من الرمز (مثال USD, SAR, EUR).');
      const result = (amount * rate).toFixed(2);
      await m.reply(`💱 ${amount} ${from.toUpperCase()} = ${result} ${to.toUpperCase()}`);
    } catch {
      await m.reply('⚠️ ما قدرت أوصل لخدمة أسعار الصرف حاليًا، حاول بعد شوي.');
    }
  },
};
