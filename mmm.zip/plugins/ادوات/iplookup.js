export default {
  command: ['فحص_ip'],
  category: 'أدوات',
  description: 'يعرض معلومات عن عنوان IP. مثال: .فحص_ip 8.8.8.8',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب عنوان IP بعد الأمر.');
    try {
      const res = await fetch(`http://ip-api.com/json/${encodeURIComponent(args_text.trim())}?lang=ar`);
      const data = await res.json();
      if (data.status !== 'success') return m.reply('❌ عنوان IP غير صحيح أو ما لقيت معلومات عنه.');
      await m.reply(
        `╭━━〔 🌐 معلومات IP 〕━━⬣\n` +
        `│ الدولة: ${data.country}\n` +
        `│ المدينة: ${data.city}\n` +
        `│ المزوّد: ${data.isp}\n` +
        `│ المنطقة الزمنية: ${data.timezone}\n` +
        `╰━━━━━━━━━━━━━━⬣`
      );
    } catch {
      await m.reply('⚠️ ما قدرت أوصل للخدمة حاليًا.');
    }
  },
};
