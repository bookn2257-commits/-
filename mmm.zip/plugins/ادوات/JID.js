export default {
  command: ['jid'],
  category: 'المالك',
  description: 'يطلع معرّف القناة (JID) من رابط دعوتها. مثال: .قناة_معلومات https://whatsapp.com/channel/xxxxx',
  ownerOnly: true,
  execute: async (sock, m, args, { args_text }) => {
    const match = args_text?.match(/channel\/([A-Za-z0-9]+)/);
    if (!match) return m.reply('❌ حط رابط قناة صحيح. مثال: .قناة_معلومات https://whatsapp.com/channel/xxxxx');

    try {
      const info = await sock.newsletterMetadata('invite', match[1]);
      await m.reply(
        `✅ معلومات القناة:\n\n` +
        `الاسم: ${info.name}\n` +
        `المعرّف (JID): ${info.id}\n\n` +
      );
    } catch (err) {
      await m.reply(`⚠️ ما قدرت أجيب معلومات القناة: ${err.message}`);
    }
  },
};
