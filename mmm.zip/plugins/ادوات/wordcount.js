export default {
  command: ['عد_الكلمات'],
  category: 'أدوات',
  description: 'يحسب عدد الكلمات والحروف بنص',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب النص بعد الأمر.');
    const words = args_text.trim().split(/\s+/).length;
    const chars = args_text.length;
    await m.reply(`📊 عدد الكلمات: ${words}\n📝 عدد الحروف: ${chars}`);
  },
};
