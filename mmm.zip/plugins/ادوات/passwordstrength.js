export default {
  command: ['فحص_كلمة_المرور'],
  category: 'أدوات',
  description: 'يفحص قوة كلمة مرور. مثال: .فحص_كلمة_المرور Ahmed123!',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب كلمة المرور بعد الأمر.');
    const pass = args_text;
    let score = 0;
    if (pass.length >= 8) score++;
    if (pass.length >= 12) score++;
    if (/[a-z]/.test(pass) && /[A-Z]/.test(pass)) score++;
    if (/[0-9]/.test(pass)) score++;
    if (/[^a-zA-Z0-9]/.test(pass)) score++;

    const levels = ['ضعيفة جدًا 🔴', 'ضعيفة 🟠', 'متوسطة 🟡', 'قوية 🟢', 'قوية جدًا 💚'];
    const level = levels[Math.min(score, levels.length - 1)];
    await m.reply(`🔐 تقييم كلمة المرور: ${level}\n(${score}/5 معايير محققة)`);
  },
};
