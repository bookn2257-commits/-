export default {
  command: ['ترميز'],
  category: 'أدوات',
  description: 'يحوّل نص إلى Base64. مثال: .encode مرحبا',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب النص بعد الأمر.');
    const encoded = Buffer.from(args_text, 'utf-8').toString('base64');
    await m.reply(`🔐 النتيجة:\n${encoded}`);
  },
};
