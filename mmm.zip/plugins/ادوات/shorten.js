export default {
  command: ['تقصير_رابط'],
  category: 'أدوات',
  description: 'يقصّر رابط طويل. مثال: .تقصير_رابط https://example.com/long-url',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text || !args_text.startsWith('http')) return m.reply('❌ اكتب رابط صحيح يبدأ بـ http بعد الأمر.');
    try {
      const res = await fetch(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(args_text)}`);
      const short = await res.text();
      if (!short.startsWith('http')) return m.reply('❌ ما قدرت أقصّر هذا الرابط.');
      await m.reply(`🔗 الرابط المختصر:\n${short}`);
    } catch {
      await m.reply('⚠️ ما قدرت أوصل لخدمة التقصير حاليًا.');
    }
  },
};
