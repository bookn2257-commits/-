export default {
  command: ['مؤقت'],
  category: 'أدوات',
  description: 'يذكّرك بعد عدد دقايق. مثال: .timer 5 خذ استراحة',
  execute: async (sock, m, args, { args_text }) => {
    const match = args_text.match(/^(\d+)\s*(.*)$/);
    if (!match) return m.reply('❌ الصيغة: .timer عدد_الدقايق الرسالة');
    const minutes = parseInt(match[1]);
    const note = match[2] || 'انتهى الوقت!';
    if (minutes < 1 || minutes > 120) return m.reply('❌ اكتب رقم بين 1 و120 دقيقة.');

    await m.reply(`⏰ تمام، بذكّرك بعد ${minutes} دقيقة.`);
    setTimeout(async () => {
      await sock.sendMessage(m.chat, { text: `⏰ تذكير: ${note}`, mentions: [m.sender] });
    }, minutes * 60 * 1000);
  },
};
