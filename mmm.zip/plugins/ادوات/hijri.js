// خوارزمية تحويل تقريبية (تقويم هجري جدولي) — كود أصلي
// تطوير: 𝑴𝑨𝑹𝑶

const hijriMonths = [
  'محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة',
  'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة',
];

function gregorianToHijri(date) {
  const jd = Math.floor(
    (1461 * (date.getFullYear() + 4800 + (date.getMonth() + 1 - 14) / 12)) / 4 +
    (367 * (date.getMonth() + 1 - 2 - 12 * ((date.getMonth() + 1 - 14) / 12))) / 12 -
    (3 * ((date.getFullYear() + 4900 + (date.getMonth() + 1 - 14) / 12) / 100)) / 4 +
    date.getDate() - 32075
  );

  const l = jd - 1948440 + 10632;
  const n = Math.floor((l - 1) / 10631);
  const l2 = l - 10631 * n + 354;
  const j =
    Math.floor((10985 - l2) / 5316) * Math.floor((50 * l2) / 17719) +
    Math.floor(l2 / 5670) * Math.floor((43 * l2) / 15238);
  const l3 =
    l2 - Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) -
    Math.floor(j / 16) * Math.floor((15238 * j) / 43) + 29;
  const month = Math.floor((24 * l3) / 709);
  const day = l3 - Math.floor((709 * month) / 24);
  const year = 30 * n + j - 30;

  return { day, month, year };
}

export default {
  command: ['التاريخ_الهجري'],
  category: 'أدوات',
  description: 'يحوّل التاريخ الميلادي الحالي (أو تاريخ معيّن) لهجري. مثال: .التاريخ_الهجري 2025-01-15',
  execute: async (sock, m, args, { args_text }) => {
    let date = new Date();
    if (args_text) {
      const parsed = new Date(args_text);
      if (isNaN(parsed.getTime())) return m.reply('❌ الصيغة: .التاريخ_الهجري YYYY-MM-DD');
      date = parsed;
    }

    const h = gregorianToHijri(date);
    await m.reply(
      `📅 التاريخ الميلادي: ${date.toLocaleDateString('ar-EG')}\n` +
      `🌙 التاريخ الهجري (تقريبي): ${h.day} ${hijriMonths[h.month - 1]} ${h.year}هـ`
    );
  },
};
