export default {
  command: ['تحويل_الحالة'],
  category: 'أدوات',
  description: 'يحوّل حالة النص. مثال: .تحويل_الحالة كبير Hello World',
  execute: async (sock, m, args, { args_text }) => {
    const match = args_text.match(/^(كبير|صغير)\s+([\s\S]+)$/);
    if (!match) return m.reply('❌ الصيغة: .تحويل_الحالة كبير/صغير النص');
    const [, mode, text] = match;
    const result = mode === 'كبير' ? text.toUpperCase() : text.toLowerCase();
    await m.reply(result);
  },
};
