export default {
  command: ['اختار'],
  category: 'ترفيه',
  description: 'يختار لك عشوائيًا من خيارات مفصولة بفاصلة. مثال: .اختار بيتزا, برجر, سوشي',
  execute: async (sock, m, args, { args_text }) => {
    const options = args_text.split(',').map((o) => o.trim()).filter(Boolean);
    if (options.length < 2) return m.reply('❌ اكتب خيارين على الأقل مفصولين بفاصلة.');
    const choice = options[Math.floor(Math.random() * options.length)];
    await m.reply(`🤔 اخترت لك: *${choice}*`);
  },
};
