const dares = [
  'غيّر صورة بروفايلك لمدة ساعة لصورة تختارها الجروب.',
  'اكتب حالة واتساب غريبة الحين.',
  'اتصل بأقرب صديق وقوله "أحبك" وسكر.',
  'ارسل آخر صورة بمعرض صورك بالجروب.',
  'اكتب بالجروب أطرف موقف صار معك.',
];

export default {
  command: ['تحدي'],
  category: 'ترفيه',
  description: 'يرسل تحدي عشوائي',
  execute: async (sock, m) => {
    const d = dares[Math.floor(Math.random() * dares.length)];
    await m.reply(`🔥 ${d}`);
  },
};
