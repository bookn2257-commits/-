const quotes = [
  'النجاح مجموع جهود صغيرة تتكرر يوم بعد يوم.',
  'ما تخاف من البطء، خاف من الوقوف.',
  'كل يوم تصحى فيه هو فرصة جديدة تبدأ فيها من جديد.',
  'الصبر مفتاح الفرج.',
  'اللي يزرع اليوم، يحصد بعد سنين.',
];

export default {
  command: ['اقتباس'],
  category: 'ترفيه',
  description: 'يرسل اقتباس تحفيزي عشوائي',
  execute: async (sock, m) => {
    const q = quotes[Math.floor(Math.random() * quotes.length)];
    await m.reply(`💬 ${q}`);
  },
};
