export default {
  command: ['توافق'],
  category: 'ترفيه',
  description: 'يحسب نسبة توافق (للتسلية بس) بين اسمين. مثال: .ship أحمد و سارة',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text.includes('و')) return m.reply('❌ الصيغة: .ship اسم1 و اسم2');
    const [a, b] = args_text.split('و').map((s) => s.trim());
    if (!a || !b) return m.reply('❌ الصيغة: .ship اسم1 و اسم2');

    let hash = 0;
    const combined = a + b;
    for (const c of combined) hash = (hash * 31 + c.charCodeAt(0)) % 100;
    const percent = Math.abs(hash);

    const bar = '█'.repeat(Math.round(percent / 10)) + '░'.repeat(10 - Math.round(percent / 10));
    await m.reply(`💞 ${a} × ${b}\n${bar} ${percent}%`);
  },
};
