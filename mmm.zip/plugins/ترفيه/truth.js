const truths = [
  'شنو أكثر شي تندم عليه؟',
  'شنو أكبر خوف عندك؟',
  'آخر كذبة قلتها كانت وش هي؟',
  'شنو أكثر شي يضايقك بالناس؟',
  'لو تقدر تغيّر شي بماضيك، وش راح يكون؟',
];

export default {
  command: ['صراحة'],
  category: 'ترفيه',
  description: 'يرسل سؤال صراحة عشوائي',
  execute: async (sock, m) => {
    const q = truths[Math.floor(Math.random() * truths.length)];
    await m.reply(`🤫 ${q}`);
  },
};
