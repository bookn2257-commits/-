const answers = [
  'أكيد ✅', 'للأسف لا ❌', 'ممكن 🤷', 'اسأل مرة ثانية 🔁',
  'بدون شك 💯', 'مستبعد 😕', 'الأرجح إنه صح ✅', 'ركّز واسأل غير كذا 🤨',
];

export default {
  command: ['الكرة_السحرية'],
  category: 'ترفيه',
  description: 'اسأل سؤال وياخذ لك إجابة عشوائية',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اسأل سؤال بعد الأمر.');
    const answer = answers[Math.floor(Math.random() * answers.length)];
    await m.reply(`🎱 ${answer}`);
  },
};
