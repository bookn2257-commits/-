export default {
  command: ['استهزاء'],
  category: 'ترفيه',
  description: 'يحوّل النص لأحرف كبيرة/صغيرة متبدّلة على طريقة السخرية. مثال: .mock مرحبا',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب نص بعد الأمر.');
    const result = [...args_text]
      .map((c, i) => (i % 2 === 0 ? c.toLowerCase() : c.toUpperCase()))
      .join('');
    await m.reply(result);
  },
};
