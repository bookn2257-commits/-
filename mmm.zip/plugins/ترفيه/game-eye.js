// plugins/game-eye.js
// 𝑀𝐴𝐷𝐴𝑅𝐴 𝐵🌀𝑇 - لعبة تخمين الشخصية من العين 👁️

import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';
import { config } from '../../config.js';

const timeout = 60000;
const reward = 500;
const sessions = new Map(); // chatId -> { correctAnswer, originalName, options, attempts, timer }
const points = new Map();   // senderId -> points

function additionalNodes(isGroup) {
  const nodes = [
    {
      tag: 'biz',
      attrs: {},
      content: [
        {
          tag: 'interactive',
          attrs: { type: 'native_flow', v: '1' },
          content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
        },
      ],
    },
  ];
  if (!isGroup) nodes.push({ tag: 'bot', attrs: { biz_bot: '1' } });
  return nodes;
}

function cleanText(text) {
  if (!text) return '';
  return text
    .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{1F900}-\u{1F9FF}\u{1F1E0}-\u{1F1FF}]/gu, '')
    .trim()
    .toLowerCase();
}

export default {
  command: ['عين', 'eye', 'مجوب', 'انهاء_عين'],
  category: 'العاب',
  description: 'لعبة تخمين الشخصية من العين',

  execute: async (sock, m, args, { command }) => {
    const react = async (emoji) => {
      try { await sock.sendMessage(m.chat, { react: { text: emoji, key: m.raw.key } }); } catch {}
    };

    const cmd = command ? command.toLowerCase() : '';
    const input = args ? args.join(' ').trim() : '';

    // 1️⃣ أمر إلغاء اللعبة الحالية في حال تعلق الجلسة القديمة
    if (cmd === 'انهاء_عين') {
      if (sessions.has(m.chat)) {
        clearTimeout(sessions.get(m.chat).timer);
        sessions.delete(m.chat);
        await react('🧹');
        return sock.sendMessage(m.chat, { text: `╭━━━〔 🧹 *${config.botName}* 〕━━━⬣\n│ تم إنهاء اللعبة السابقة بنجاح!\n╰━━━━━━━━━━━━━⬣` }, { quoted: m.raw });
      } else {
        return sock.sendMessage(m.chat, { text: `╭━━━〔 ⚠️ *${config.botName}* 〕━━━⬣\n│ لا توجد لعبة قائمة حالياً.\n╰━━━━━━━━━━━━━⬣` }, { quoted: m.raw });
      }
    }

    // 2️⃣ معالجة الإجابة عند استخدام أمر .مجوب أو إرسال مدخلات
    if (cmd === 'مجوب' || (sessions.has(m.chat) && input.length > 0)) {
      const task = sessions.get(m.chat);
      if (!task) {
        await react('⚠️');
        return sock.sendMessage(m.chat, { text: `╭━━━〔 ⚠️ *${config.botName}* 〕━━━⬣\n│ لا توجد مهمة نشطة حالياً!\n╰━━━━━━━━━━━━━⬣` }, { quoted: m.raw });
      }

      const cleanedInput = cleanText(input);
      let selectedAnswer = cleanedInput;
      let isAttempt = false;

      const selectedIndex = parseInt(cleanedInput);
      if (!isNaN(selectedIndex) && selectedIndex >= 1 && selectedIndex <= 4) {
        selectedAnswer = cleanText(task.options[selectedIndex - 1]);
        isAttempt = true;
      } else if (task.options.some(opt => cleanText(opt) === cleanedInput)) {
        isAttempt = true;
      }

      if (isAttempt) {
        const senderId = m.raw.key.participant || m.raw.key.remoteJid;
        const isCorrect = task.correctAnswer === selectedAnswer;

        if (isCorrect) {
          await react('✅');
          const total = (points.get(senderId) || 0) + reward;
          points.set(senderId, total);

          await sock.sendMessage(
            m.chat,
            {
              text:
                `╭━━━〔 ✅ *${config.botName}* 〕━━━⬣\n` +
                `│ 🎉 إجابة صحيحة أيها المحارب! +${reward} نقطة\n│\n` +
                `│ 👤 الشخصية: ${task.originalName}\n` +
                `│ 🏆 نقاطك الحالية: ${total}\n` +
                `╰━━━━━━━━━━━━━━━━━━⬣`,
            },
            { quoted: m.raw }
          );

          clearTimeout(task.timer);
          sessions.delete(m.chat);
          return;
        } else {
          task.attempts -= 1;
          if (task.attempts > 0) {
            await react('❌');
            return sock.sendMessage(
              m.chat,
              { text: `╭━━━〔 ❌ *${config.botName}* 〕━━━⬣\n│ إجابة خاطئة!\n│ المحاولات المتبقية: ${task.attempts}\n│ ⚔️ حاول مرة أخرى\n╰━━━━━━━━━━━━━⬣` },
              { quoted: m.raw }
            );
          } else {
            await react('❌');
            await sock.sendMessage(
              m.chat,
              { text: `╭━━━〔 ❌ *${config.botName}* 〕━━━⬣\n│ انتهت المحاولات!\n│ الإجابة الصحيحة كانت: ${task.originalName}\n╰━━━━━━━━━━━━━⬣` },
              { quoted: m.raw }
            );
            clearTimeout(task.timer);
            sessions.delete(m.chat);
            return;
          }
        }
      }
    }

    // 3️⃣ منع بدء لعبة جديدة إذا كانت هناك لعبة قائمة بالفعل
    if (sessions.has(m.chat)) {
      await react('⏳');
      return sock.sendMessage(
        m.chat,
        { text: `╭━━━〔 ⚠️ *${config.botName}* 〕━━━⬣\n│ هناك مهمة نشطة بالفعل في هذه المجموعة!\n│ أرسل: *.مجوب 1* أو اكتب الاسم بعد الأمر.\n│ لإلغاء اللعبة القديمة أرسل: *.انهاء_عين*\n╰━━━━━━━━━━━━━⬣` },
        { quoted: m.raw }
      );
    }

    // 4️⃣ بدء لعبة جديدة (.عين)
    try {
      const response = await fetch("https://raw.githubusercontent.com/DK3MK/worker-bot/main/eye.json");
      const data = await response.json();

      if (!data.length) throw new Error("No Data");

      const item = data[Math.floor(Math.random() * data.length)];
      const { img, name } = item;

      let options = [name];
      while (options.length < 4) {
        let random = data[Math.floor(Math.random() * data.length)].name;
        if (!options.includes(random)) options.push(random);
      }

      options.sort(() => Math.random() - 0.5);

      const media = await prepareWAMessageMedia(
        { image: { url: img } },
        { upload: sock.waUploadToServer }
      );

      const buttons = options.map((option, index) => ({
        name: 'quick_reply',
        buttonParamsJson: JSON.stringify({
          display_text: `🩸 ${option}`,
          id: `.مجوب ${index + 1}`
        })
      }));

      const interactiveMessage = {
        body: {
          text:
            `╭━━━〔 👁️ *${config.botName}* 〕━━━⬣\n` +
            `│ 🔮 *من صاحب هذه العين؟*\n│\n` +
            `│ 💡 اضغط على الزر أو اكتب: *.مجوب [الاسم]*\n` +
            `│ ⏰ الوقت: 60 ثانية\n` +
            `│ ⭐ الجائزة: ${reward} نقطة\n` +
            `│ 🎯 المحاولات: 2\n` +
            `╰━━━━━━━━━━━━━━━━━━⬣`
        },
        footer: { text: `❄️ ${config.botName} ❄️` },
        header: {
          hasMediaAttachment: true,
          subtitle: '👁️ اختر الشخصية الصحيحة',
          imageMessage: media.imageMessage,
        },
        nativeFlowMessage: {
          buttons: buttons,
          messageParamsJson: JSON.stringify({
            bottom_sheet: {
              list_title: "👁️ اختر اسم الشخصية",
              button_title: "▻ الخيارات ⚡"
            }
          })
        }
      };

      const msg = generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              interactiveMessage: proto.Message.InteractiveMessage.fromObject(interactiveMessage)
            }
          }
        },
        { userJid: sock.user.id, quoted: m.raw }
      );

      await react("👁️");
      const isGroup = m.chat.endsWith('@g.us');
      await sock.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id,
        additionalNodes: additionalNodes(isGroup)
      });

      const timer = setTimeout(async () => {
        if (sessions.has(m.chat)) {
          await sock.sendMessage(
            m.chat,
            { text: `╭━━━〔 ⏰ *${config.botName}* 〕━━━⬣\n│ انتهى وقت المهمة!\n│ الإجابة الصحيحة كانت: ${name}\n╰━━━━━━━━━━━━━⬣` },
            { quoted: m.raw }
          );
          sessions.delete(m.chat);
        }
      }, timeout);

      sessions.set(m.chat, {
        correctAnswer: cleanText(name),
        originalName: name,
        options: options,
        attempts: 2,
        timer: timer
      });

    } catch (e) {
      console.error('[game-eye:error]', e);
      await react("❌");
      await sock.sendMessage(
        m.chat,
        { text: `❄️ ${config.botName}: حدث خطأ أثناء بدء اللعبة` },
        { quoted: m.raw }
      );
    }
  }
};
