export default {
  command: ['نرد'],
  category: 'ترفيه',
  description: 'يرمي نرد ويطلع رقم من 1 إلى 6',
  execute: async (sock, m) => {
    const result = Math.floor(Math.random() * 6) + 1;
    await m.reply(`🎲 طلع لك: ${result}`);
  },
};
