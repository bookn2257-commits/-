export default {
  command: ['عملة'],
  category: 'ترفيه',
  description: 'يرمي عملة: كتابة أو صورة',
  execute: async (sock, m) => {
    const result = Math.random() < 0.5 ? '🪙 كتابة' : '🪙 صورة';
    await m.reply(result);
  },
};
