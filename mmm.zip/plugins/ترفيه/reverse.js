export default {
  command: ['عكس'],
  category: 'ترفيه',
  description: 'يعكس النص. مثال: .reverse مرحبا',
  execute: async (sock, m, args, { args_text }) => {
    if (!args_text) return m.reply('❌ اكتب نص بعد الأمر.');
    await m.reply([...args_text].reverse().join(''));
  },
};
