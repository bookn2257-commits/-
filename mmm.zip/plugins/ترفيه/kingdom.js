// plugins/kingdom.js
// ✧ نظام المملكة الكامل — النسخة الشاملة المدمجة (بنية بوتك + كل أنظمة MADARA) ✧

import { config } from '../../config.js';
import { sendButtons } from '../../lib/menus.js';
import { getUser, getChat, scheduleSave } from '../../lib/dIb.js';

const BRAND = config?.botName || '𝑀𝐴𝐷𝐴𝑅𝐴 𝐵🌀𝑇';

// ==================== دوال مساعدة ====================
function formatNumber(num) { return Math.floor(num || 0).toLocaleString('en-US'); }
function pick(list) { return list[Math.floor(Math.random() * list.length)]; }
function getRandomInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }

function msToTime(ms) {
  ms = Math.max(0, ms);
  const d = Math.floor(ms / (1000 * 60 * 60 * 24));
  const h = Math.floor((ms / (1000 * 60 * 60)) % 24);
  const m = Math.floor((ms / (1000 * 60)) % 60);
  const s = Math.floor((ms / 1000) % 60);
  if (d > 0) return `${d} يوم و ${h} ساعة`;
  if (h > 0) return `${h} ساعة و ${m} دقيقة`;
  return `${m} دقيقة و ${s} ثانية`;
}

function getSenderId(m) {
  return m.sender || m.raw?.key?.participant || m.raw?.key?.remoteJid;
}
function getMentionedJid(m) {
  return m.mentionedJid?.[0] || m.raw?.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || null;
}
function getQuotedSender(m) {
  return m.quoted?.sender || m.raw?.message?.extendedTextMessage?.contextInfo?.participant || null;
}

function isBotOwner(m) {
  try {
    const num = (getSenderId(m) || '').split('@')[0].replace(/\D/g, '');
    const candidates = [];
    if (Array.isArray(global.owner)) candidates.push(...global.owner);
    const cfgOwner = config?.owner || config?.ownerNumber || config?.ownerJid || config?.sudo;
    if (Array.isArray(cfgOwner)) candidates.push(...cfgOwner);
    else if (cfgOwner) candidates.push(cfgOwner);
    return candidates.some(o => String(Array.isArray(o) ? o[0] : o).replace(/\D/g, '') === num);
  } catch (e) { return false; }
}

// بناء نص الصندوق
function buildBody(title, lines = []) {
  let text = `╭━━━〔 *${title}* 〕━━━⬣\n│\n`;
  for (const line of lines) {
    if (line.type === 'info') text += `│ 🔹 *${line.label}:* ${line.value}\n`;
    else if (line.type === 'line') text += `│ ${line.text}\n`;
    else if (line.type === 'warning') text += `│ ⚠️ ${line.text}\n`;
    else if (line.type === 'subtitle') text += `│ ▫️ *${line.text}*\n`;
    else if (line.type === 'divider') text += `├────────────────⬣\n`;
  }
  text += `│\n╰━━━━━━━━━━━━━━━━━━━━━━⬣`;
  return text;
}

// ==================== إعدادات وقيم النظام ====================
const INCOME_COOLDOWN = 12 * 60 * 60 * 1000;          // 12 ساعة
const HUNT_COOLDOWN = 7 * 60 * 1000;                  // 7 دقائق (وحوش وكهوف)
const BOSS_RESPAWN_COOLDOWN = 12 * 60 * 60 * 1000;    // 12 ساعة للزعيم
const ATTACK_SAME_TARGET_COOLDOWN = 60 * 60 * 1000;   // ساعة على نفس الهدف
const ATTACK_MIN_REWARD = 25000;
const ATTACK_PROTECTED_FLOOR = 250000;
const ALLIANCE_CREATE_COST = 100000;
const NAME_CHANGE_COST = 20000;
const ELEMENT_RESET_COST = 100000;

// ==================== العناصر والأفضلية (3 طبقات) ====================
const PRIMAL_ELEMENTS   = ['نار', 'ماء', 'أرض'];
const STRONG_ELEMENTS    = ['رياح', 'نباتات', 'برق', 'صوت', 'تلج', 'غاز'];
const LEGENDARY_ELEMENTS = ['ظلام', 'نور', 'فراغ'];

const ELEMENT_TIER_RANK = {
  'نار': 1, 'ماء': 1, 'أرض': 1,
  'رياح': 2, 'نباتات': 2, 'برق': 2, 'صوت': 2, 'تلج': 2, 'غاز': 2,
  'ظلام': 3, 'نور': 4, 'فراغ': 5
};

const ELEMENTS = {
  'نار':     { tier: 'بدائي', maxLvl: 15, evolved: 'لهب' },
  'ماء':     { tier: 'بدائي', maxLvl: 15, evolved: 'شلال' },
  'أرض':    { tier: 'بدائي', maxLvl: 15, evolved: 'جبال' },
  'رياح':   { tier: 'قوي', maxLvl: 25, evolved: 'إعصار' },
  'نباتات':  { tier: 'قوي', maxLvl: 25, evolved: 'غابة' },
  'برق':     { tier: 'قوي', maxLvl: 25, evolved: 'صاعقة' },
  'صوت':     { tier: 'قوي', maxLvl: 25, evolved: 'دوي' },
  'تلج':     { tier: 'قوي', maxLvl: 25, evolved: 'عاصفة ثلجية' },
  'غاز':     { tier: 'قوي', maxLvl: 25, evolved: 'سحابة سامة' },
  'ظلام':   { tier: 'أسطوري', maxLvl: 40, evolved: 'ظلام مطلق' },
  'نور':     { tier: 'أسطوري', maxLvl: 40, evolved: 'نور مقدس' },
  'فراغ':    { tier: 'أسطوري', maxLvl: 40, evolved: 'فراغ لا نهائي' }
};

const NORMAL_ELEMENT_LIST = PRIMAL_ELEMENTS;
const ALL_ELEMENT_LIST = [...PRIMAL_ELEMENTS, ...STRONG_ELEMENTS, ...LEGENDARY_ELEMENTS];

function getRandomElement() {
  const rand = Math.random() * 1000;
  if (rand <= 3) return 'فراغ';
  if (rand <= 13) return 'نور';
  if (rand <= 33) return 'ظلام';
  if (rand <= 383) return pick(STRONG_ELEMENTS);
  return pick(PRIMAL_ELEMENTS);
}

// دورة قوة العناصر البدائية: نار > ماء > أرض > نار
// دورة قوة العناصر القوية: رياح > نباتات > برق > صوت > تلج > غاز > رياح
function cyclicMultiplier(order, attackerElem, defenderElem) {
  const ai = order.indexOf(attackerElem);
  const di = order.indexOf(defenderElem);
  if (ai === -1 || di === -1) return 1.0;
  const len = order.length;
  const diff = (di - ai + len) % len;
  if (diff === len - 1) return 1.3;
  if (diff === 1) return 0.7;
  return 1.0;
}

function getElementMultiplier(attackerElem, defenderElem) {
  if (!attackerElem || !defenderElem || attackerElem === defenderElem) return 1.0;
  const rA = ELEMENT_TIER_RANK[attackerElem] || 1;
  const rD = ELEMENT_TIER_RANK[defenderElem] || 1;
  if (rA !== rD) {
    if (rA > rD) return Math.min(2.0, 1.0 + (rA - rD) * 0.25);
    return Math.max(0.5, 1.0 - (rD - rA) * 0.2);
  }
  if (rA === 1) return cyclicMultiplier(PRIMAL_ELEMENTS, attackerElem, defenderElem);
  if (rA === 2) return cyclicMultiplier(STRONG_ELEMENTS, attackerElem, defenderElem);
  return 1.0;
}

const WEAPON_TIER_BONUS = { 'عادي': 1500, 'مميز': 3000, 'خارق': 5000, 'أسطورة': 8000, 'لا يقهر': 15000 };
const SHIELD_TIER_BONUS = { 'عادي': 3000, 'مميز': 6000, 'خارق': 10000, 'أسطورة': 16000, 'لا يقهر': 25000 };

function enrichHeroWithGear(kd, hero) {
  const weapon = kd.weapons?.[hero.id];
  const shield = kd.heroShields?.[hero.id];
  let weaponAtk = weapon ? weapon.atk : 0;
  if (hero.id === 'maro' && weapon && weapon.role && weapon.role !== 'ساحر') {
    weaponAtk += 5000;
  }
  return { ...hero, weaponAtk, shieldHp: shield ? shield.hp : 0 };
}

// ==================== قاعدة بيانات الأبطال الـ 50 ====================
const HERO_RANKS = {
  'عادي':    { bonusMult: 1.0,  monsterBonus: 0.10, pvpBonus: 0.05 },
  'مميز':    { bonusMult: 1.4,  monsterBonus: 0.15, pvpBonus: 0.10 },
  'خارق':    { bonusMult: 2.0,  monsterBonus: 0.20, pvpBonus: 0.15 },
  'أسطورة':  { bonusMult: 2.8,  monsterBonus: 0.25, pvpBonus: 0.20 },
  'لا يقهر': { bonusMult: 4.0,  monsterBonus: 0.30, pvpBonus: 0.25 }
};
const HERO_RANK_ORDER = ['عادي', 'مميز', 'خارق', 'أسطورة', 'لا يقهر'];

const HERO_TIER_REQUIREMENTS = {
  'عادي':    { gold: 100000,   heartLevel: 1,  scrollTier: null,   bookElement: null },
  'مميز':    { gold: 300000,   heartLevel: 15, scrollTier: null,   bookElement: null },
  'خارق':    { gold: 700000,   heartLevel: 40, scrollTier: 'قوي', bookElement: null },
  'أسطورة':  { gold: 1200000,  heartLevel: 60, scrollTier: 'قوي', bookElement: null }
};

const LEGENDARY_HERO_REQUIREMENTS = {
  outa: { gold: 4000000, bookElement: 'فراغ', leaderHeartElement: 'فراغ' },
  maro: { gold: 4000000, bookElement: 'نور',  leaderHeartElement: 'نور' },
  h46:  { gold: 2500000, bookElement: 'ظلام', leaderHeartElement: 'ظلام' },
  h47:  { gold: 2500000, bookElement: 'ظلام', leaderHeartElement: 'ظلام' },
  h48:  { gold: 2500000, bookElement: 'ظلام', leaderHeartElement: 'ظلام' }
};

const HERO_ROLES = ['مهاجم', 'مدافع', 'رامي', 'قاتل', 'ساحر'];

function buildTierHeroes(names, rank, elementPool, startIndex) {
  return names.map((name, i) => ({
    id: `h${startIndex + i}`,
    listIndex: startIndex + i,
    name, rank,
    role: HERO_ROLES[i % HERO_ROLES.length],
    element: elementPool[i % elementPool.length]
  }));
}

const TIER1_NAMES = ['بيلا', 'كورين', 'دورن', 'فينا', 'جاروث', 'هيلدا', 'اوسكار', 'ريتا', 'تانوس', 'مايا', 'بروك', 'سيلا', 'دانتي', 'نورا', 'فيكتور'];
const TIER2_NAMES = ['برسيوس', 'اثينا', 'اوديسيوس', 'هيلين', 'اجاممنون', 'اخيل', 'هرقل', 'اندروميدا', 'كاساندرا', 'اجاكس'];
const TIER3_NAMES = ['رافائيل', 'سيرافينا', 'دراغان', 'لونا', 'نوكس', 'تيرا', 'زيوس', 'هيرميس', 'اورورا', 'فينيكس'];
const TIER4_NAMES = ['اراجون', 'فالكيري', 'زيلوس', 'ثورين', 'سيلفانا', 'داريوس', 'شينا', 'جاندالف', 'براوم', 'روبن'];

const HERO_DATABASE = [
  ...buildTierHeroes(TIER1_NAMES, 'عادي', PRIMAL_ELEMENTS, 1),
  ...buildTierHeroes(TIER2_NAMES, 'مميز', PRIMAL_ELEMENTS, 16),
  ...buildTierHeroes(TIER3_NAMES, 'خارق', STRONG_ELEMENTS, 26),
  ...buildTierHeroes(TIER4_NAMES, 'أسطورة', STRONG_ELEMENTS, 36),
  { id: 'h46', listIndex: 46, name: 'نيرو',  rank: 'لا يقهر', role: 'رامي',  element: 'ظلام' },
  { id: 'h47', listIndex: 47, name: 'سيلين', rank: 'لا يقهر', role: 'ساحر', element: 'ظلام' },
  { id: 'h48', listIndex: 48, name: 'كايوس', rank: 'لا يقهر', role: 'قاتل', element: 'ظلام' },
  { id: 'outa', listIndex: 49, name: 'أوتا', rank: 'لا يقهر', role: 'مهاجم', element: 'فراغ', isSpecial: true },
  { id: 'maro', listIndex: 50, name: 'مارو', rank: 'لا يقهر', role: 'ساحر', element: 'نور', isSpecial: true }
];

function getHeroTierRequirement(rank) { return HERO_TIER_REQUIREMENTS[rank] || null; }
function getHeroByIdentifier(idOrNumber) {
  const n = parseInt(idOrNumber);
  if (!isNaN(n)) return HERO_DATABASE.find(h => h.listIndex === n);
  return HERO_DATABASE.find(h => h.name === idOrNumber || h.id === idOrNumber);
}

function getHeroStats(heroData, level = 1) {
  const rankInfo = HERO_RANKS[heroData.rank] || HERO_RANKS['عادي'];
  let baseHp = 50000;
  let baseAtk = 50000;
  switch (heroData.role) {
    case 'مهاجم': baseHp = 50000; baseAtk = 60000; break;
    case 'مدافع': baseHp = 100000; baseAtk = 30000; break;
    case 'رامي':   baseHp = 40000; baseAtk = 80000; break;
    case 'قاتل':  baseHp = 25000; baseAtk = 110000; break;
    case 'ساحر':   baseHp = 30000; baseAtk = 100000; break;
  }
  if (heroData.id === 'outa') { baseHp = 150000; baseAtk = 200000; }
  if (heroData.id === 'maro') { baseHp = 110000; baseAtk = 150000; }

  const rate = 0.15;
  const cappedLevel = Math.min(level, 50);
  let levelMult = 1 + (cappedLevel - 1) * rate;
  if (level > 50) levelMult += (level - 50) * (rate * 2);

  const weaponBonus = heroData.weaponAtk || 0;
  const shieldBonus = heroData.shieldHp || 0;

  const hp = Math.floor((baseHp * levelMult * rankInfo.bonusMult) + shieldBonus);
  const atk = Math.floor((baseAtk * levelMult * rankInfo.bonusMult) + weaponBonus);
  return { hp, atk };
}

// ==================== معدات الحماية (خوذة/صدر/بنطلون/حذاء) ====================
const EQUIPMENT_SLOTS = ['خوذة', 'صدر', 'بنطلون', 'حذاء'];

function getEquipmentBonus(equipObj) {
  let totalAtk = 0;
  for (const slot of EQUIPMENT_SLOTS) {
    const lvl = equipObj[slot] || 0;
    totalAtk += lvl * 1500;
  }
  return totalAtk;
}

// ==================== قلوب الوحوش ولفائف العناصر ====================
const MONSTER_HEART_DROP_CHANCE = 30; // %
const SCROLL_DROP_CHANCE = 20; // %

function heartSellPrice(level) { return level * 10000; }

function maybeDropHeart(kd, monsterLevel) {
  if (getRandomInt(1, 100) <= MONSTER_HEART_DROP_CHANCE) {
    const key = String(monsterLevel);
    kd.hearts[key] = (kd.hearts[key] || 0) + 1;
    return monsterLevel;
  }
  return null;
}

function maybeDropScroll(kd, monsterElement) {
  if (STRONG_ELEMENTS.includes(monsterElement) && getRandomInt(1, 100) <= SCROLL_DROP_CHANCE) {
    kd.scrolls[monsterElement] = (kd.scrolls[monsterElement] || 0) + 1;
    return monsterElement;
  }
  return null;
}

function getBestHeartLevel(kd) {
  const levels = Object.keys(kd.hearts || {}).map(Number).filter(l => (kd.hearts[l] || 0) > 0);
  return levels.length ? Math.max(...levels) : 0;
}

function hasStrongScroll(kd) {
  return Object.values(kd.scrolls || {}).some(q => q > 0);
}
function consumeAnyStrongScroll(kd) {
  for (const elem of STRONG_ELEMENTS) {
    if ((kd.scrolls[elem] || 0) > 0) { kd.scrolls[elem] -= 1; return elem; }
  }
  return null;
}
function consumeHeartAtLeast(kd, minLevel) {
  const levels = Object.keys(kd.hearts).map(Number).filter(l => l >= minLevel && (kd.hearts[l] || 0) > 0).sort((a, b) => a - b);
  if (!levels.length) return null;
  const use = levels[0];
  kd.hearts[use] -= 1;
  return use;
}

// ==================== الزعماء الخمسة ====================
const WORLD_LEADERS = [
  { key: 'نار',  name: 'زعيم اللهب الأحمر',    element: 'نار',  minP: 5000000,   maxP: 25000000 },
  { key: 'ماء',  name: 'زعيم الطوفان الأزرق',  element: 'ماء',  minP: 5000000,   maxP: 25000000 },
  { key: 'أرض', name: 'زعيم الجبل الراسخ',    element: 'أرض', minP: 5000000,   maxP: 25000000 },
  { key: 'قوي',  name: 'زعيم العاصفة القوية',  element: null,   minP: 5000000,   maxP: 60000000 },
  { key: 'اسطوري', name: 'زعيم الفراغ الأبدي', element: null,   minP: 5000000,   maxP: 150000000 }
];

function spawnWorldLeader() {
  const template = pick(WORLD_LEADERS);
  let element = template.element;
  if (!element) {
    element = template.key === 'قوي' ? pick(STRONG_ELEMENTS) : pick(LEGENDARY_ELEMENTS);
  }
  return {
    name: template.name,
    element,
    power: getRandomInt(template.minP, template.maxP),
    isDead: false,
    lastSpawn: Date.now()
  };
}

// ==================== الألقاب ====================
const TITLES = {
  'صياد_الوحوش': { name: '🩸 صياد الوحوش', require: kd => (kd.monsterKills || 0) >= 100, monsterBonus: 0.05 },
  'مسقط_العمالقة_المبتدئ': { name: '👑 مسقط العمالقة المبتدئ', require: kd => (kd.bossKills || 0) >= 1, bossFlatBonus: 30000 },
  'مقاتل_عشرة': { name: '⚔️ مقاتل العشرة', require: kd => (kd.pvpAttacksCount || 0) >= 10, reward: 30000 },
  'سياف_المئة': { name: '🗡️ سياف المئة', require: kd => (kd.pvpAttacksCount || 0) >= 100, reward: 150000 },
  'صياد_ماهر': { name: '🎣 الصياد الماهر', require: kd => (kd.fishCount || 0) >= 50, goldMult: 0.05 },
  'فارس_التنانين': { name: '🐉 فارس التنانين', require: kd => (kd.dragonKills || 0) >= 5, reward: 200000 },
  'قائد_الحملات': { name: '🐫 قائد الحملات', require: kd => (kd.caravanSuccessCount || 0) >= 10, reward: 100000 }
};

function checkAndAwardTitles(kd) {
  const newly = [];
  for (const [key, t] of Object.entries(TITLES)) {
    if (!kd.titles.includes(key) && t.require(kd)) {
      kd.titles.push(key);
      newly.push(t.name);
      if (t.reward) kd.gold += t.reward;
      if (!kd.activeTitle) kd.activeTitle = key;
    }
  }
  return newly;
}

function getTitleCombatBonus(kd, targetType) {
  let flat = 0, mult = 1;
  for (const key of (kd.titles || [])) {
    const t = TITLES[key];
    if (!t) continue;
    if (targetType === 'monster' && t.monsterBonus) mult += t.monsterBonus;
    if (targetType === 'boss' && t.bossFlatBonus) flat += t.bossFlatBonus;
  }
  return { flat, mult };
}

// ==================== المهام اليومية ====================
const DAILY_MISSION_POOL = [
  { id: 'kill_monsters', label: 'اقتل 3 وحوش', target: 3, type: 'monsterKill' },
  { id: 'win_cave', label: 'طهّر كهفاً واحداً بنجاح', target: 1, type: 'caveWin' },
  { id: 'attack_player', label: 'اهجم على لاعب مرة واحدة', target: 1, type: 'pvpAttack' },
  { id: 'collect_income', label: 'اجمع الدخل الدوري', target: 1, type: 'collectIncome' }
];
const DAILY_MISSION_REWARD = { gold: 100000, gift: '🎁 هدية بسيطة (سلاح عشوائي بسيط)' };

function todayKey() {
  const d = new Date();
  return `${d.getUTCFullYear()}-${d.getUTCMonth() + 1}-${d.getUTCDate()}`;
}

function ensureDailyMissions(kd) {
  const key = todayKey();
  if (!kd.dailyMissions || kd.dailyMissions.date !== key) {
    kd.dailyMissions = {
      date: key,
      tasks: DAILY_MISSION_POOL.map(t => ({ id: t.id, progress: 0 })),
      claimed: false
    };
  }
  return kd.dailyMissions;
}

function progressMission(kd, type, amount = 1) {
  const dm = ensureDailyMissions(kd);
  const def = DAILY_MISSION_POOL.find(t => t.type === type);
  if (!def) return;
  const task = dm.tasks.find(t => t.id === def.id);
  if (task) task.progress = Math.min(def.target, task.progress + amount);
}

function allMissionsDone(kd) {
  const dm = ensureDailyMissions(kd);
  return DAILY_MISSION_POOL.every(def => {
    const task = dm.tasks.find(t => t.id === def.id);
    return task && task.progress >= def.target;
  });
}

// ==================== الهدايا الدورية ====================
const GIFT_DAILY_COOLDOWN = 24 * 60 * 60 * 1000;
const GIFT_WEEKLY_COOLDOWN = 7 * 24 * 60 * 60 * 1000;
const GIFT_MONTHLY_COOLDOWN = 30 * 24 * 60 * 60 * 1000;
const GIFT_DAILY_AMOUNT = 5000;
const GIFT_WEEKLY_AMOUNT = 50000;
const GIFT_MONTHLY_AMOUNT = 400000;

// ==================== بيانات الجروب ====================
function getChatData(chatId) {
  try {
    const c = getChat(chatId);
    if (c) return c;
  } catch (e) {}
  return {};
}

function ensureGameEnabled(chatData) {
  if (chatData.kingdomEnabled === undefined) chatData.kingdomEnabled = true;
  return chatData.kingdomEnabled;
}

// سجل اللاعبين عالمياً (للتوب والبحث)
global.kdKnownJids = global.kdKnownJids || [];
function trackGlobalPlayer(jid) {
  if (!jid) return;
  if (!global.kdKnownJids.includes(jid)) {
    global.kdKnownJids.push(jid);
    if (global.kdKnownJids.length > 10000) global.kdKnownJids.shift();
  }
}

// ==================== الطقس (يتغير كل 3 ساعات) ====================
const WEATHER_CYCLE = 3 * 60 * 60 * 1000;
const WEATHER_TYPES = {
  'حر':    { emoji: '🔥', label: 'الجو حر', boostElement: 'نار' },
  'ممطر':  { emoji: '🌧️', label: 'الدنيا تمطر', boostElement: 'ماء' },
  'اعصار': { emoji: '🌪️', label: 'الدنيا إعصار', boostElement: 'رياح' },
  'تلج':   { emoji: '❄️', label: 'الدنيا تثلج', boostElement: 'تلج' }
};
function ensureWeather(chatData) {
  const now = Date.now();
  if (!chatData.weather || now - chatData.weather.changedAt >= WEATHER_CYCLE) {
    const keys = Object.keys(WEATHER_TYPES);
    chatData.weather = { type: pick(keys), changedAt: now };
  }
  return chatData.weather;
}

// ==================== نظام الصيد ====================
const FISH_COOLDOWN = 8 * 60 * 1000;
const FISHING_SPOTS = {
  'بحيرة': {
    label: '🎣 بحيرة عادية',
    catches: [
      { key: 'سمك_عادي', name: 'سمك عادي', reqPower: 100000, pricePerKg: 700, weight: 60 },
      { key: 'سمك_فضي', name: 'سمك فضي', reqPower: 120000, pricePerKg: 1000, weight: 25 },
      { key: 'سمك_ذهبي', name: 'سمك ذهبي', reqPower: 150000, pricePerKg: 1200, weight: 10 }
    ]
  },
  'نهر_الظلام': {
    label: '🌑 نهر الظلام',
    catches: [
      { key: 'ثعبان_ماء', name: 'ثعبان ماء', reqPower: 200000, pricePerKg: 1500, weight: 50 },
      { key: 'سمك_شبح', name: 'سمك شبح', reqPower: 250000, pricePerKg: 1700, weight: 30 },
      { key: 'وحش_النهر', name: 'وحش النهر', reqPower: 400000, pricePerKg: 2000, weight: 15 }
    ]
  },
  'بحر_الاحلام': {
    label: '🌊 بحر الأحلام',
    catches: [
      { key: 'لؤلؤ', name: 'لؤلؤ', reqPower: 600000, pricePerKg: 2500, weight: 55 },
      { key: 'مرجان', name: 'مرجان', reqPower: 700000, pricePerKg: 3400, weight: 30 },
      { key: 'حورية_بحر', name: 'حورية بحر', reqPower: 1000000, weight: 6, isMermaid: true }
    ]
  }
};
const MERMAID_RESPAWN = 60 * 60 * 1000;
const MERMAID_POWER = 1000000;
const MERMAID_IMMUNE_ELEMENTS = ['ماء', 'نار'];

function rollFishWeight() {
  const r = Math.random();
  if (r < 0.6) return getRandomInt(1, 10);
  if (r < 0.9) return getRandomInt(11, 25);
  return getRandomInt(26, 50);
}

function pickWeightedCatch(list) {
  const total = list.reduce((s, c) => s + c.weight, 0);
  let roll = Math.random() * total;
  for (const c of list) {
    if (roll < c.weight) return c;
    roll -= c.weight;
  }
  return list[list.length - 1];
}

// ==================== التنانين ====================
const DRAGON_ENCOUNTER_CHANCE = 15; // %
const DRAGON_PENDING_TTL = 5 * 60 * 1000;

function spawnCaveDragon(caveNum) {
  const elementCount = getRandomInt(1, 100) <= 30 ? 2 : 1;
  const pool = [...PRIMAL_ELEMENTS, ...STRONG_ELEMENTS, ...LEGENDARY_ELEMENTS];
  const elements = [];
  while (elements.length < elementCount) {
    const e = pick(pool);
    if (!elements.includes(e)) elements.push(e);
  }
  return {
    cave: caveNum,
    elements,
    power: getRandomInt(2000000, 50000000),
    createdAt: Date.now(),
    expiresAt: Date.now() + DRAGON_PENDING_TTL
  };
}
function dragonReward(power) {
  if (power <= 10000000) return 500000;
  if (power <= 30000000) return 800000;
  return 1000000;
}

// ==================== قوافل الكنوز ====================
const CARAVAN_DURATION = 15 * 60 * 1000;
const CARAVAN_MONSTER_CHANCE = 50;
const CARAVAN_DRAGON_CHANCE = 20;
const CARAVAN_REGIONS = {
  'صحراء':        { label: '🏜️ الصحراء', resourceName: 'ذهب', resourceField: 'gold', ratio: 0.5 },
  'غابة':         { label: '🌲 الغابة', resourceName: 'خشب', resourceField: 'wood', ratio: 0.4 },
  'جبال_ثلجية':   { label: '🏔️ الجبال الثلجية', resourceName: 'حجر', resourceField: 'stone', ratio: 0.45 },
  'ارض_البراكين': { label: '🌋 أرض البراكين', resourceName: 'ذهب', resourceField: 'gold', ratio: 0.6 }
};

// ==================== القتال الجماعي ====================
const TEAM_BATTLE_WIN_REWARD = 700000;
const TEAM_BATTLE_LOSS_TOTAL = 1000000;

// ==================== متجر اللاعب ====================
const PLAYER_SHOP_COST = 1000000;
const SHOP_FORBIDDEN_KEYWORDS = ['بطل', 'عنصر', 'كتاب', 'قلب', 'لفيفة', 'حرشف'];
function isForbiddenShopItem(name) {
  return SHOP_FORBIDDEN_KEYWORDS.some(k => name.includes(k));
}

// ==================== أحداث العالم العشوائية ====================
const WORLD_EVENT_CHECK_INTERVAL = 3 * 60 * 60 * 1000;
const WORLD_EVENT_TRIGGER_CHANCE = 30; // %
const WORLD_EVENT_DURATION = 5 * 60 * 1000;
const WORLD_EVENT_DRAGON_POWER = 30000000;
const WORLD_EVENT_DRAGON_LOSS = 50000;
const GOLD_RAIN_AMOUNT = 40000;
const POISON_RAIN_ATK_DIVISOR = 4;

function trackKnownPlayer(chatData, jid) {
  if (!chatData.knownPlayers) chatData.knownPlayers = [];
  if (!chatData.knownPlayers.includes(jid)) chatData.knownPlayers.push(jid);
}

async function resolveDragonWorldEvent(sock, chatId, chatData) {
  const ev = chatData.activeWorldEvent;
  if (!ev || ev.type !== 'تنين_عالمي') return;
  const totalPower = ev.totalPower || 0;
  const success = totalPower >= ev.power;
  let msg;
  if (success) {
    msg = buildBody('🐉 تم صد التنين العالمي!', [
      { type: 'line', text: `القوة المجمّعة: ${formatNumber(totalPower)} ضد قوة التنين ${formatNumber(ev.power)}` },
      { type: 'line', text: '🎉 نجا الجميع بلا خسائر!' }
    ]);
  } else {
    let affected = 0;
    for (const jid of (chatData.knownPlayers || [])) {
      const u = getUser(jid);
      if (u && u.kingdom) {
        u.kingdom.gold = Math.max(0, u.kingdom.gold - WORLD_EVENT_DRAGON_LOSS);
        affected++;
      }
    }
    msg = buildBody('💥 هجم التنين العالمي!', [
      { type: 'line', text: `القوة المجمّعة: ${formatNumber(totalPower)} لم تكفِ ضد قوة التنين ${formatNumber(ev.power)}` },
      { type: 'warning', text: `خسر كل لاعب معروف ${formatNumber(WORLD_EVENT_DRAGON_LOSS)}$ (${affected} لاعب)` }
    ]);
  }
  try { await sock.sendMessage(chatId, { text: msg }); } catch (e) {}
  chatData.activeWorldEvent = null;
}

async function resolveWorldEventExpiry(sock, chatId, chatData) {
  const ev = chatData.activeWorldEvent;
  if (!ev) return;
  if (Date.now() < ev.expiresAt) return;
  if (ev.type === 'تنين_عالمي') {
    await resolveDragonWorldEvent(sock, chatId, chatData);
  } else {
    chatData.activeWorldEvent = null;
  }
}

function maybeTriggerWorldEvent(chatData) {
  const now = Date.now();
  if (!chatData.lastWorldEventCheck) { chatData.lastWorldEventCheck = now; return null; }
  if (chatData.activeWorldEvent) return null;
  if (now - chatData.lastWorldEventCheck < WORLD_EVENT_CHECK_INTERVAL) return null;
  chatData.lastWorldEventCheck = now;
  if (getRandomInt(1, 100) > WORLD_EVENT_TRIGGER_CHANCE) return null;

  const type = pick(['تنين_عالمي', 'مطر_ذهب', 'مطر_سم']);
  const ev = { type, startedAt: now, expiresAt: now + WORLD_EVENT_DURATION };
  if (type === 'تنين_عالمي') { ev.power = WORLD_EVENT_DRAGON_POWER; ev.totalPower = 0; ev.responders = []; }
  if (type === 'مطر_ذهب') ev.claimed = [];
  chatData.activeWorldEvent = ev;
  return ev;
}

function worldEventAnnouncement(ev) {
  if (ev.type === 'تنين_عالمي') {
    return [
      { type: 'title', text: '🚨 تنبيه! تنين عملاق يهاجم!' },
      { type: 'warning', text: `قوة التنين: ${formatNumber(ev.power)} — لديكم 5 دقائق للتصدي!` },
      { type: 'line', text: `استخدم أمر: تصدي_للتنين للانضمام بقوتك` }
    ];
  }
  if (ev.type === 'مطر_ذهب') {
    return [
      { type: 'title', text: '🌟 السماء تمطر ذهباً!' },
      { type: 'line', text: `استخدم أمر: جمع خلال 5 دقائق لتحصل على ${formatNumber(GOLD_RAIN_AMOUNT)}$` }
    ];
  }
  return [
    { type: 'title', text: '☠️ أمطار سامة!' },
    { type: 'warning', text: 'قوة الهجوم لدى الجميع أصبحت الرُبع لمدة 5 دقائق!' }
  ];
}

// ==================== الرتب والخبرة ====================
const RANKS = [
  { name: 'غير مصنف', minExp: 0 },
  { name: 'برونزي 1', minExp: 300 },
  { name: 'برونزي 2', minExp: 600 },
  { name: 'برونزي 3', minExp: 1000 },
  { name: 'فضي 1',   minExp: 1500 },
  { name: 'فضي 2',   minExp: 2200 },
  { name: 'فضي 3',   minExp: 3000 },
  { name: 'ذهبي 1',   minExp: 4000 },
  { name: 'ذهبي 2',   minExp: 5500 },
  { name: 'ذهبي 3',   minExp: 7500 },
  { name: 'ماسي',     minExp: 10000 },
  { name: 'أسطوري',   minExp: 15000 }
];

function getRank(totalExp) {
  let current = RANKS[0];
  for (const r of RANKS) { if (totalExp >= r.minExp) current = r; else break; }
  return current;
}

function expNeededForLevel(level) { return level * 1000; }

// ==================== الوحوش والكهوف ====================
const MONSTER_BASE_POWER = 3000;
function getMonsterPower(n) {
  let power = MONSTER_BASE_POWER;
  for (let i = 2; i <= n; i++) power *= (i <= 10) ? 1.25 : 1.5;
  return Math.min(Math.round(power), 1e15);
}

function getWildMonsterElement(weatherBoostElement = null) {
  if (weatherBoostElement && getRandomInt(1, 100) <= 35) return weatherBoostElement;
  return getRandomInt(1, 100) <= 25 ? pick(STRONG_ELEMENTS) : pick(PRIMAL_ELEMENTS);
}

function getMonster(n, chosenElement = null, weatherBoostElement = null) {
  const level = Math.max(1, Math.min(100, n));
  const element = chosenElement && ELEMENTS[chosenElement] ? chosenElement : getWildMonsterElement(weatherBoostElement);
  return {
    name: `وحش الـ ${element} (مستوى ${level})`,
    power: getMonsterPower(level),
    gold: Math.round(1200 * level * (1 + level * 0.03)),
    exp: level * 15,
    level,
    element
  };
}

const CAVE_BASE_POWER = 2000;
const CAVE_NAMES = [
  'كهف المبتدئين', 'كهف الصيادين', 'كهف المحاربين', 'كهف الأبطال', 'كهف الأساطير',
  'كهف الآلهة', 'كهف الجحيم', 'كهف النهاية', 'كهف الظلام', 'كهف الأشباح'
];

function getCavePower(n) {
  let power = CAVE_BASE_POWER;
  for (let i = 2; i <= n; i++) power *= (i <= 10) ? 1.25 : 1.5;
  return Math.min(Math.round(power), 1e15);
}

function getCave(n) {
  const level = Math.max(1, Math.min(100, n));
  const gold = Math.round(1000 * level * (1 + level * 0.03));
  return {
    name: CAVE_NAMES[(level - 1) % CAVE_NAMES.length] + (level > CAVE_NAMES.length ? ` ${level}` : ''),
    level,
    power: getCavePower(level),
    gold,
    exp: level * 12,
    wood: Math.round(gold * 0.4),
    stone: Math.round(gold * 0.2)
  };
}

// ==================== المتاجر والكتب والأدوات ====================
const SHOP_WEAPONS = {
  'سيف عادي':   { price: 10000, attack: 200 },
  'جندي عادي':  { price: 8000,  attack: 50 },
  'قوس':        { price: 9000,  attack: 100 },
  'سيف':        { price: 10000, attack: 200 },
  'فأس':        { price: 11000, attack: 300 },
  'رمح':        { price: 12000, attack: 400 },
  'خنجر':       { price: 13000, attack: 500 },
  'مطرقة':      { price: 14000, attack: 600 },
  'منجل':       { price: 15000, attack: 700 },
  'فِرَس':       { price: 16000, attack: 800 },
  'رمح طويل':   { price: 17000, attack: 900 },
  'مطرقة حديد': { price: 18000, attack: 1000 },
  'سيف مزدوج':  { price: 19000, attack: 1100 },
  'فأس كبير':   { price: 20000, attack: 1200 },
  'رمح قصير':   { price: 21000, attack: 1300 },
  'سيف مسنن':   { price: 22000, attack: 1400 },
  'خنجر مسموم': { price: 23000, attack: 1500 },
  'رمح صاعقة':  { price: 24000, attack: 1600 },
  'قوس مركب':   { price: 25000, attack: 1700 },
  'كاتيانا':    { price: 26000, attack: 1800 },
  'فأس مزدوج':  { price: 27000, attack: 1900 },
  'نصل الملك':  { price: 50000, attack: 5000 }
};

const SHOP_SPELLS = {
  'درع الحماية': { price: 100000, attack: 0, shield: true },
  'صاعقة النيزك': { price: 80000, attack: 7000 },
  'درع':      { price: 100000, attack: 0, shield: true },
  'لهب':      { price: 29000, attack: 2100 },
  'عاصفة':    { price: 30000, attack: 2200 },
  'زلزال':    { price: 31000, attack: 2300 },
  'موجة':     { price: 32000, attack: 2400 },
  'نيزك':     { price: 33000, attack: 2500 },
  'جليد':     { price: 34000, attack: 2600 },
  'رعد':      { price: 35000, attack: 2700 },
  'شبح':      { price: 36000, attack: 2800 },
  'وحش':      { price: 37000, attack: 2900 },
  'قوى الظل': { price: 38000, attack: 3000 }
};

const BOOKS = {
  'كتاب_تطوير': { price: 50000,  desc: 'يزيد لفل البطل مباشرة بدون قتال' },
  'كتاب_سحر':   { price: 150000, desc: 'يضاعف قوة هجوم العنصر للبطل والمملكة' },
  'كتاب_عناصر': { price: 300000, desc: 'يعطيك عنصر عشوائي عالي (ظلام/نور/فراغ) لمدة ساعة' },
  'كتاب_شجاعة': { price: 100000, desc: 'يزيد نسبة الهجوم عشوائياً (حد أقصى 3)' },
  'كتاب_موارد': { price: 600000, desc: 'يضاعف كل الموارد المكتسبة من المعارك والحلبة' }
};

const SHOP_ITEMS = { ...SHOP_WEAPONS, ...SHOP_SPELLS };

const PRODUCTION_ITEMS = {
  'حيوان': { price: 20000,  income: 500,   key: 'animals' },
  'خروف':  { price: 20000,  income: 500,   key: 'sheep' },
  'عامل':  { price: 20000,  income: 500,   key: 'workers' },
  'منقب':  { price: 20000,  income: 500,   key: 'miners' },
  'أرض':   { price: 200000, income: 10000, key: 'lands' },
  'قلعة':  { price: 500000, income: 30000, key: 'castles' }
};

const RESOURCE_ITEMS = {
  'خشب': { price: 1000, amount: 500, key: 'wood' },
  'حجر': { price: 1500, amount: 500, key: 'stone' }
};

const SOLDIER_ITEM = { price: 5000, power: 50 };

// أدوات البوت الأصلية (نظامك أنت)
const TOOLS_TYPES = {
  'سيف':    { atkBonus: 0.05 },
  'فأس':    { atkBonus: 0.04 },
  'بيكاكس': { atkBonus: 0.02 },
  'معزقة':  { atkBonus: 0.01 }
};

const KINGDOM_NAMES = [
  'مملكة الوادي المظلم', 'إمبراطورية الرماد', 'مملكة الفجر الدامي',
  'دولة الصحراء الحمراء', 'مملكة القمر الأسود', 'إمبراطورية الثلج',
  'مملكة النار الخالدة', 'دولة الغيوم السوداء'
];

// ==================== تهيئة بيانات اللاعب ====================
function ensureKingdom(user) {
  if (!user.kingdom) {
    user.kingdom = {
      name: pick(KINGDOM_NAMES),
      level: 1, exp: 0, totalExp: 0,
      gold: 50000, vault: 0,
      wood: 0, stone: 0, scrollPieces: 0, soldiers: 0,
      production: { animals: 0, sheep: 0, workers: 0, miners: 0, lands: 0, castles: 0 },
      inventory: {},
      books: { كتاب_تطوير: 0, كتاب_سحر: 0, كتاب_عناصر: 0, كتاب_شجاعة: 0, كتاب_موارد: 0 },
      activeBooks: [],
      tempElement: null, tempElementExpires: 0,
      tools: {
        'سيف': { rank: 'عادي', level: 1 },
        'فأس': { rank: 'عادي', level: 1 },
        'بيكاكس': { rank: 'عادي', level: 1 },
        'معزقة': { rank: 'عادي', level: 1 }
      },
      heroes: [],
      equipment: { خوذة: 0, صدر: 0, بنطلون: 0, حذاء: 0 },
      element: getRandomElement(),
      elementLvl: 1,
      isElementEvolved: false,
      hasElementReset: false,
      baseAttack: 10,
      lastIncome: 0, lastHunt: 0, lastCave: 0, lastFish: 0,
      attackTimestamps: [], lastAttackOnTarget: {},
      currentCave: null,
      allianceId: null, pendingInvite: null,
      hearts: {}, leaderHearts: {}, scrolls: {},
      heroBooks: { نور: 0, ظلام: 0, فراغ: 0 },
      weapons: {}, heroShields: {},
      monsterKills: 0, bossKills: 0, dragonKills: 0,
      fishCount: 0, mermaidScales: 0,
      pvpAttacksCount: 0, caravanSuccessCount: 0,
      titles: [], activeTitle: null,
      dailyMissions: null,
      lastDailyGift: 0, lastWeeklyGift: 0, lastMonthlyGift: 0,
      caravan: { active: false, troops: 0, region: null, sentAt: 0, returnAt: 0 },
      shop: { open: false, items: [] },
      createdAt: Date.now()
    };

    const starterHero = HERO_DATABASE.find(h => h.id === 'h11');
    user.kingdom.heroes.push({ ...starterHero, level: 1, exp: 0, readyToUpgrade: false });
  }

  const kd = user.kingdom;
  // ترقية تلقائية للاعبين القدامى (تعويض أي حقل ناقص)
  if (kd.gold === undefined) kd.gold = 50000;
  if (kd.vault === undefined) kd.vault = 0;
  if (!kd.production) kd.production = { animals: 0, sheep: 0, workers: 0, miners: 0, lands: 0, castles: 0 };
  if (!kd.inventory) kd.inventory = {};
  if (!kd.books) kd.books = { كتاب_تطوير: 0, كتاب_سحر: 0, كتاب_عناصر: 0, كتاب_شجاعة: 0, كتاب_موارد: 0 };
  if (!kd.activeBooks) kd.activeBooks = [];
  if (!kd.tools) kd.tools = { 'سيف': { rank: 'عادي', level: 1 }, 'فأس': { rank: 'عادي', level: 1 }, 'بيكاكس': { rank: 'عادي', level: 1 }, 'معزقة': { rank: 'عادي', level: 1 } };
  if (!kd.heroes) kd.heroes = [];
  if (!kd.equipment) kd.equipment = { خوذة: 0, صدر: 0, بنطلون: 0, حذاء: 0 };
  if (!kd.element) kd.element = getRandomElement();
  if (kd.elementLvl === undefined) kd.elementLvl = 1;
  if (kd.isElementEvolved === undefined) kd.isElementEvolved = false;
  if (kd.hasElementReset === undefined) kd.hasElementReset = false;
  if (kd.wood === undefined) kd.wood = 0;
  if (kd.stone === undefined) kd.stone = 0;
  if (kd.scrollPieces === undefined) kd.scrollPieces = 0;
  if (kd.soldiers === undefined) kd.soldiers = 0;
  if (kd.baseAttack === undefined) kd.baseAttack = 10;
  if (kd.totalExp === undefined) kd.totalExp = kd.exp || 0;
  if (kd.lastIncome === undefined) kd.lastIncome = 0;
  if (kd.lastHunt === undefined) kd.lastHunt = 0;
  if (kd.lastCave === undefined) kd.lastCave = 0;
  if (kd.lastFish === undefined) kd.lastFish = 0;
  if (!kd.attackTimestamps) kd.attackTimestamps = [];
  if (!kd.lastAttackOnTarget) kd.lastAttackOnTarget = {};
  if (kd.currentCave === undefined) kd.currentCave = null;
  if (kd.allianceId === undefined) kd.allianceId = null;
  if (kd.pendingInvite === undefined) kd.pendingInvite = null;
  if (!kd.hearts) kd.hearts = {};
  if (!kd.leaderHearts) kd.leaderHearts = {};
  if (!kd.scrolls) kd.scrolls = {};
  if (!kd.heroBooks) kd.heroBooks = { نور: 0, ظلام: 0, فراغ: 0 };
  if (!kd.weapons) kd.weapons = {};
  if (!kd.heroShields) kd.heroShields = {};
  if (kd.monsterKills === undefined) kd.monsterKills = 0;
  if (kd.bossKills === undefined) kd.bossKills = 0;
  if (kd.dragonKills === undefined) kd.dragonKills = 0;
  if (kd.fishCount === undefined) kd.fishCount = 0;
  if (kd.mermaidScales === undefined) kd.mermaidScales = 0;
  if (kd.pvpAttacksCount === undefined) kd.pvpAttacksCount = 0;
  if (kd.caravanSuccessCount === undefined) kd.caravanSuccessCount = 0;
  if (!kd.titles) kd.titles = [];
  if (kd.activeTitle === undefined) kd.activeTitle = null;
  if (kd.lastDailyGift === undefined) kd.lastDailyGift = 0;
  if (kd.lastWeeklyGift === undefined) kd.lastWeeklyGift = 0;
  if (kd.lastMonthlyGift === undefined) kd.lastMonthlyGift = 0;
  if (!kd.caravan) kd.caravan = { active: false, troops: 0, region: null, sentAt: 0, returnAt: 0 };
  if (!kd.shop) kd.shop = { open: false, items: [] };
  ensureDailyMissions(kd);
  return kd;
}

// ==================== إدارة الزعيم العالمي (لكل جروب) ====================
function getGroupBoss(chatData) {
  const now = Date.now();
  if (!chatData.boss || (now - chatData.boss.lastSpawn >= BOSS_RESPAWN_COOLDOWN && chatData.boss.isDead)) {
    chatData.boss = spawnWorldLeader();
  }
  return chatData.boss;
}

// ==================== الحسابات المشتقة ====================
function getEffectiveElement(kd) {
  if (kd.tempElement && Date.now() < kd.tempElementExpires) return kd.tempElement;
  return kd.element;
}

function getAttackPower(kd, isBoss = false, isPvP = false) {
  let atk = kd.baseAttack || 10;

  for (const [name, qty] of Object.entries(kd.inventory || {})) {
    const item = SHOP_ITEMS[name];
    if (item && item.attack) atk += item.attack * qty;
  }

  atk += getEquipmentBonus(kd.equipment || {});

  let elemMult = 1;
  if (kd.activeBooks && kd.activeBooks.includes('كتاب_سحر')) elemMult = 2;
  atk += (kd.elementLvl * 2000 * elemMult);

  // أدواتك الخاصة
  for (const [tName, tData] of Object.entries(kd.tools || {})) {
    const baseDef = TOOLS_TYPES[tName] || { atkBonus: 0 };
    const rankBonus = (HERO_RANK_ORDER.indexOf(tData.rank) || 0) * 0.10;
    const lvlBonus = (tData.level - 1) * 0.02;
    atk *= (1 + baseDef.atkBonus + rankBonus + lvlBonus);
  }

  let heroesAtk = 0;
  if (kd.heroes && kd.heroes.length > 0) {
    for (const hero of kd.heroes) {
      const stats = getHeroStats(enrichHeroWithGear(kd, hero), hero.level);
      heroesAtk += stats.atk;
    }
  }
  atk += heroesAtk;

  if (kd.activeBooks) {
    const courageCount = kd.activeBooks.filter(b => b === 'كتاب_شجاعة').length;
    if (courageCount > 0) atk += atk * (courageCount * 0.10);
  }

  // مهارات أوتا ومارو
  const hasOuta = kd.heroes?.some(h => h.id === 'outa');
  const hasMaro = kd.heroes?.some(h => h.id === 'maro');
  if (hasOuta) {
    if (isBoss) atk *= 2.0;
    else if (isPvP) atk *= 0.5;
    else atk *= 2.0; // أوتا مضاعف ضد الوحوش أيضاً
  }
  if (hasMaro) {
    if (isBoss || isPvP) atk *= 1.5;
  }

  if (kd.caravan && kd.caravan.active && Date.now() < kd.caravan.returnAt) {
    atk -= kd.caravan.troops;
  }

  return Math.max(1, Math.floor(atk));
}

function getShieldCount(kd) { return (kd.inventory['درع'] || 0) + (kd.inventory['درع الحماية'] || 0); }
function maxAttacksPerHour(level) { return 2 + Math.floor(level / 100); }

function getAttackLevelBonus(level) {
  let bonus = 0;
  let remaining = Math.max(0, level - 1);
  const tier1Cap = Math.floor(500000 / 25000);
  const tier1 = Math.min(remaining, tier1Cap);
  bonus += tier1 * 25000; remaining -= tier1;
  if (remaining > 0) {
    const tier2Cap = Math.ceil((1000000 - 500000) / 15000);
    const tier2 = Math.min(remaining, tier2Cap);
    bonus += tier2 * 15000; remaining -= tier2;
  }
  if (remaining > 0) bonus += remaining * 10000;
  return bonus;
}

function kingdomValuation(user, kd) {
  const levelValue = (kd.level - 1) * 20000;
  const prod = kd.production || {};
  const productionValue = ((prod.animals || 0) + (prod.sheep || 0) + (prod.workers || 0) + (prod.miners || 0)) * 20000;
  const landValue = ((prod.lands || 0) + (prod.castles || 0)) * 200000;
  let weaponsValue = 0;
  for (const [name, qty] of Object.entries(kd.inventory || {})) {
    const item = SHOP_ITEMS[name];
    if (item) weaponsValue += item.price * qty;
  }
  return Math.floor(levelValue + productionValue + landValue + weaponsValue + (kd.gold || 0) + (kd.vault || 0));
}

function calculateDailyIncomeBreakdown(kd, alliances) {
  const prod = kd.production || {};
  const baseIncome = 10000;
  const expBonus = kd.exp * 1000;
  const cowsIncome = (prod.animals || 0) * 500;
  const sheepIncome = (prod.sheep || 0) * 500;
  const workersIncome = (prod.workers || 0) * 500;
  const minersIncome = (prod.miners || 0) * 500;
  const landsIncome = (prod.lands || 0) * 10000;
  const castlesIncome = (prod.castles || 0) * 30000;
  const allianceIncome = getAllianceIncome(kd.allianceId, alliances);
  const total = baseIncome + expBonus + cowsIncome + sheepIncome + workersIncome + minersIncome + landsIncome + castlesIncome + allianceIncome;
  return { baseIncome, expBonus, cowsIncome, sheepIncome, workersIncome, minersIncome, landsIncome, castlesIncome, allianceIncome, total };
}

// ==================== التحالفات ====================
function getAlliances() {
  global.kdAlliances = global.kdAlliances || {};
  return global.kdAlliances;
}

function getAllianceIncome(allianceId, alliances) {
  if (!allianceId || !alliances[allianceId]) return 0;
  const sorted = Object.values(alliances).sort((a, b) => (b.power || 0) - (a.power || 0));
  const rank = sorted.findIndex(a => a.id === allianceId);
  if (rank === -1) return 0;
  return Math.max(100000, 1000000 - rank * 100000);
}

// ==================== بطاقات الواجهة ====================
async function sendCard(sock, m, title, bodyLines, buttonDefs = []) {
  const text = buildBody(title, bodyLines);
  const quotedMsg = m.raw || m;
  const buttons = buttonDefs.slice(0, 15);

  if (typeof sendButtons === 'function') {
    try {
      await sendButtons(sock, m.chat, {
        text,
        footer: `⚜️ ${BRAND} ⚜️`,
        buttons: buttons.map(b => ({ id: b.id, text: b.text })),
        quoted: quotedMsg
      });
      return;
    } catch (e) {}
  }

  let btnText = '\n\n*الأوامر المتاحة:*\n';
  buttonDefs.forEach(b => { btnText += `• ${b.text}: \`${b.id}\`\n`; });
  await sock.sendMessage(m.chat, { text: text + btnText }, { quoted: quotedMsg });
}

function mainButtons(usedPrefix) {
  return [
    { text: '💰 الدخل', id: `${usedPrefix} دخل` },
    { text: '⚔️ ساحة المعارك', id: `${usedPrefix} معارك` },
    { text: '🛡️ أبطالي', id: `${usedPrefix} ابطال` },
    { text: '📜 قائمة الأبطال (50)', id: `${usedPrefix} عرض_ابطال` },
    { text: '🏟️ حلبة الأبطال', id: `${usedPrefix} حلبة` },
    { text: '🐉 الزعيم', id: `${usedPrefix} زعيم` },
    { text: '🎣 الصيد', id: `${usedPrefix} صيد` },
    { text: '🐫 القوافل', id: `${usedPrefix} قافلة` },
    { text: '⚔️ قتال جماعي', id: `${usedPrefix} قتال_جماعي 3` },
    { text: '🌤️ الطقس', id: `${usedPrefix} طقس` },
    { text: '❤️ القلوب واللفائف', id: `${usedPrefix} قلوب` },
    { text: '🗒️ مهام اليوم', id: `${usedPrefix} مهام` },
    { text: '🎁 الهدايا', id: `${usedPrefix} هدية` },
    { text: '🏅 الألقاب', id: `${usedPrefix} القاب` },
    { text: '🏪 المتجر', id: `${usedPrefix} متجر` },
    { text: '🏦 البنك', id: `${usedPrefix} بنك` },
    { text: '🤝 التحالف', id: `${usedPrefix} تحالف` },
    { text: '🏆 التوب', id: `${usedPrefix} توب` }
  ];
}

async function showMain(sock, m, usedPrefix, title, extra, kd) {
  const atk = getAttackPower(kd);
  const rank = getRank(kd.totalExp);
  const activeElem = getEffectiveElement(kd);
  const elemName = kd.isElementEvolved ? (ELEMENTS[activeElem]?.evolved || activeElem) : activeElem;
  const titleDecor = kd.activeTitle && TITLES[kd.activeTitle] ? ` 『${TITLES[kd.activeTitle].name}』` : '';

  return sendCard(sock, m, title, [
    { type: 'info', label: '🏰 المملكة', value: `${kd.name}${titleDecor}` },
    { type: 'info', label: '📈 المستوى', value: `${kd.level}` },
    { type: 'info', label: '⭐ الخبرة', value: `${formatNumber(kd.exp)} / ${formatNumber(expNeededForLevel(kd.level))}` },
    { type: 'info', label: '🎖️ الرتبة', value: rank.name },
    { type: 'info', label: '🔮 العنصر', value: `${elemName} (مستوى ${kd.elementLvl})${kd.tempElement ? ' ⏳مؤقت' : ''}` },
    { type: 'info', label: '⚔️ قوة الهجوم', value: formatNumber(atk) },
    { type: 'info', label: '🛡️ الأبطال', value: `${kd.heroes.length} / 50` },
    { type: 'info', label: '💰 الذهب', value: formatNumber(kd.gold) },
    { type: 'info', label: '🏦 البنك', value: formatNumber(kd.vault) },
    { type: 'info', label: '🪵 خشب', value: formatNumber(kd.wood) },
    { type: 'info', label: '🪨 حجر', value: formatNumber(kd.stone) },
    { type: 'info', label: '📜 شظايا التمريرة', value: formatNumber(kd.scrollPieces) },
    { type: 'info', label: '⚔️ الجنود', value: formatNumber(kd.soldiers) },
    ...(extra || [])
  ], mainButtons(usedPrefix));
}

// ─── ساحة المعارك المدمجة ───
async function showBattleMenu(sock, m, usedPrefix, kd, note) {
  const rank = getRank(kd.totalExp);
  const suggestedCave = Math.min(100, Math.max(1, Math.floor(kd.totalExp / 150) + 1));

  return sendCard(sock, m, `⚔️ ساحة المعارك والمغامرات`, [
    { type: 'info', label: '⚔️ قوتك الإجمالية', value: formatNumber(getAttackPower(kd)) },
    { type: 'info', label: '🔮 عنصرك', value: getEffectiveElement(kd) },
    { type: 'info', label: '🎖️ رتبتك', value: rank.name },
    { type: 'divider' },
    { type: 'line', text: `🗡️ للهجوم على لاعب: ${usedPrefix} هجوم @لاعب` },
    { type: 'line', text: `🐾 للقتال حسب المستوى: ${usedPrefix} وحش [رقم]` },
    { type: 'line', text: `⛰️ لدخول كهف معين: ${usedPrefix} كهف [رقم]` },
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [
    { text: '🐾 قتال وحش عشوائي', id: `${usedPrefix} وحش` },
    { text: '🔥 وحش نار', id: `${usedPrefix} وحش نار` },
    { text: '💧 وحش ماء', id: `${usedPrefix} وحش ماء` },
    { text: `⛰️ دخول كهف ${suggestedCave}`, id: `${usedPrefix} كهف ${suggestedCave}` },
    { text: '🔙 رجوع للقائمة', id: usedPrefix }
  ]);
}

// ─── المتجر المدمج ───
async function showShop(sock, m, usedPrefix, kd, note) {
  return sendCard(sock, m, `🏪 مركز التجارة والتطوير`, [
    { type: 'info', label: '💰 رصيدك', value: formatNumber(kd.gold) },
    { type: 'divider' },
    { type: 'line', text: 'اختر القسم الذي تريد الوصول إليه:' },
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [
    { text: '⚔️ الأسلحة', id: `${usedPrefix} متجر اسلحة` },
    { text: '✨ التعاويذ السحرية', id: `${usedPrefix} متجر تعاويذ` },
    { text: '📖 الكتب السحرية', id: `${usedPrefix} متجر كتب` },
    { text: '🐾 معدات الإنتاج', id: `${usedPrefix} متجر انتاج` },
    { text: '🪵 الموارد والجنود', id: `${usedPrefix} متجر موارد` },
    { text: '🔮 تطوير العنصر', id: `${usedPrefix} عنصر` },
    { text: '🛡️ ترقية المعدات', id: `${usedPrefix} معدات` },
    { text: '🎒 مخزنك', id: `${usedPrefix} مخزن` },
    { text: '🔙 رجوع للقائمة', id: usedPrefix }
  ]);
}

async function showEquipment(sock, m, usedPrefix, kd, note) {
  const eq = kd.equipment;
  return sendCard(sock, m, `🛡️ معدات ${kd.name}`, [
    { type: 'info', label: '🪖 الخوذة', value: `مستوى ${eq['خوذة'] || 0} / 15` },
    { type: 'info', label: '🛡️ درع الصدر', value: `مستوى ${eq['صدر'] || 0} / 15` },
    { type: 'info', label: '👖 البنطلون', value: `مستوى ${eq['بنطلون'] || 0} / 15` },
    { type: 'info', label: '🥾 الحذاء', value: `مستوى ${eq['حذاء'] || 0} / 15` },
    { type: 'divider' },
    { type: 'line', text: 'تطوير القطع يزيد القوة 1500 لكل مستوى!' },
    { type: 'line', text: `للترقية: ${usedPrefix} ترقية [اسم القطعة]` },
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [
    { text: '🪖 ترقية الخوذة', id: `${usedPrefix} ترقية خوذة` },
    { text: '🛡️ ترقية الصدر', id: `${usedPrefix} ترقية صدر` },
    { text: '👖 ترقية البنطلون', id: `${usedPrefix} ترقية بنطلون` },
    { text: '🥾 ترقية الحذاء', id: `${usedPrefix} ترقية حذاء` },
    { text: '🔙 رجوع للمتجر', id: `${usedPrefix} متجر` }
  ]);
}

async function showElementInfo(sock, m, usedPrefix, kd, note) {
  const elem = getEffectiveElement(kd);
  const max = ELEMENTS[elem]?.maxLvl || 15;
  const name = kd.isElementEvolved ? ELEMENTS[elem]?.evolved : elem;

  return sendCard(sock, m, `🔮 عنصر ${kd.name}`, [
    { type: 'info', label: '🔮 العنصر الحالي', value: name },
    { type: 'info', label: '📈 مستوى العنصر', value: `${kd.elementLvl} / ${max}` },
    { type: 'info', label: '⚡ الحالة', value: kd.isElementEvolved ? 'متطور بالكامل 🌟' : 'عادي' },
    { type: 'info', label: '🧪 عنصر التأهيل', value: kd.hasElementReset ? 'مفعل (جاهز لسرقة عنصر الزعيم)' : 'غير مفعل' },
    { type: 'divider' },
    { type: 'line', text: 'ترقية العنصر تحتاج ذهب حتى الحد الأقصى.' },
    { type: 'line', text: 'عند مستوى 15 يلزمك قتل زعيم لتطوير العنصر!' },
    { type: 'line', text: 'اشترِ "عنصر تأهيل" واسحق الزعيم لتستولي على عنصره.' },
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [
    { text: '⬆️ تطوير العنصر', id: `${usedPrefix} تطوير_العنصر` },
    { text: '🧪 شراء عنصر تأهيل', id: `${usedPrefix} تأهيل` },
    { text: '🔙 رجوع للمتجر', id: `${usedPrefix} متجر` }
  ]);
}

async function showShopCategory(sock, m, usedPrefix, kd, category, note) {
  let items, title;
  if (category === 'اسلحة') { items = SHOP_WEAPONS; title = '⚔️ الأسلحة'; }
  else if (category === 'تعاويذ') { items = SHOP_SPELLS; title = '✨ التعاويذ السحرية'; }
  else if (category === 'انتاج') { items = PRODUCTION_ITEMS; title = '🐾 معدات الإنتاج'; }
  else if (category === 'كتب') { items = BOOKS; title = '📖 الكتب السحرية'; }

  const lines = Object.entries(items).map(([name, it]) => {
    const priceK = it.price >= 1000 ? `${Math.round(it.price / 1000)}k` : it.price;
    const stat = it.income ? `دخل ${formatNumber(it.income)}` : it.shield ? 'حماية' : it.desc ? it.desc : `+${formatNumber(it.attack)} هجوم`;
    return { type: 'line', text: `${name} ⟞ ${stat} | ${priceK}` };
  });

  const buttons = Object.keys(items).slice(0, 4).map(name => ({
    text: `🛒 شراء ${name}`, id: `${usedPrefix} شراء ${name} 1`
  }));

  if (category === 'اسلحة') buttons.push({ text: '✨ قسم التعاويذ', id: `${usedPrefix} متجر تعاويذ` });
  else if (category === 'تعاويذ') buttons.push({ text: '📖 قسم الكتب', id: `${usedPrefix} متجر كتب` });
  else if (category === 'كتب') buttons.push({ text: '⚔️ قسم الأسلحة', id: `${usedPrefix} متجر اسلحة` });
  buttons.push({ text: '🔙 رجوع للمتجر', id: `${usedPrefix} متجر` });

  return sendCard(sock, m, title, [
    { type: 'info', label: '💰 رصيدك', value: formatNumber(kd.gold) },
    { type: 'divider' },
    ...lines,
    { type: 'divider' },
    { type: 'line', text: `للشراء بكمية: ${usedPrefix} شراء [اسم] [عدد]` },
    ...(note ? [{ type: 'divider' }, note] : [])
  ], buttons);
}

async function showResourcesShop(sock, m, usedPrefix, kd, note) {
  return sendCard(sock, m, `🪵 الموارد والجنود`, [
    { type: 'info', label: '💰 رصيدك', value: formatNumber(kd.gold) },
    { type: 'divider' },
    { type: 'line', text: `🪵 خشب ⟞ +${RESOURCE_ITEMS['خشب'].amount} | ${RESOURCE_ITEMS['خشب'].price}` },
    { type: 'line', text: `🪨 حجر ⟞ +${RESOURCE_ITEMS['حجر'].amount} | ${RESOURCE_ITEMS['حجر'].price}` },
    { type: 'line', text: `⚔️ جندي ⟞ +${SOLDIER_ITEM.power} قوة | ${SOLDIER_ITEM.price}` },
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [
    { text: '🪵 شراء خشب', id: `${usedPrefix} شراء خشب 1` },
    { text: '🪨 شراء حجر', id: `${usedPrefix} شراء حجر 1` },
    { text: '⚔️ شراء جندي', id: `${usedPrefix} شراء جندي 1` },
    { text: '🔙 رجوع للمتجر', id: `${usedPrefix} متجر` }
  ]);
}

async function showInventory(sock, m, usedPrefix, kd, note) {
  const weapons = Object.entries(kd.inventory).filter(([n]) => SHOP_WEAPONS[n]);
  const spells = Object.entries(kd.inventory).filter(([n]) => SHOP_SPELLS[n]);
  const books = Object.entries(kd.books || {}).filter(([, q]) => q > 0);
  const prod = kd.production || {};

  const lines = [];
  lines.push({ type: 'subtitle', text: 'الأسلحة' });
  if (weapons.length) weapons.forEach(([n, q]) => lines.push({ type: 'line', text: `${n} × ${formatNumber(q)}` }));
  else lines.push({ type: 'line', text: 'لا يوجد أسلحة' });

  lines.push({ type: 'subtitle', text: 'التعاويذ' });
  if (spells.length) spells.forEach(([n, q]) => lines.push({ type: 'line', text: `${n} × ${formatNumber(q)}` }));
  else lines.push({ type: 'line', text: 'لا يوجد تعاويذ' });

  lines.push({ type: 'subtitle', text: 'الكتب السحرية' });
  if (books.length) books.forEach(([n, q]) => lines.push({ type: 'line', text: `${n} × ${formatNumber(q)}` }));
  else lines.push({ type: 'line', text: 'لا يوجد كتب' });

  lines.push({ type: 'subtitle', text: 'الإنتاج' });
  lines.push({ type: 'line', text: `🐄 حيوانات: ${prod.animals || 0} | 🐑 خراف: ${prod.sheep || 0}` });
  lines.push({ type: 'line', text: `👷 عمال: ${prod.workers || 0} | ⛏️ منقبون: ${prod.miners || 0}` });
  lines.push({ type: 'line', text: `🌍 أراضي: ${prod.lands || 0} | 🏰 قلاع: ${prod.castles || 0}` });

  lines.push({ type: 'subtitle', text: 'الأدوات' });
  for (const [tName, tData] of Object.entries(kd.tools || {})) {
    lines.push({ type: 'line', text: `🛠️ ${tName} ⟞ [${tData.rank}] Lvl ${tData.level}/15` });
  }

  return sendCard(sock, m, `🎒 مخزون ${kd.name}`, lines, [
    { text: '🔙 رجوع للمتجر', id: `${usedPrefix} متجر` },
    { text: '🏰 القائمة الرئيسية', id: usedPrefix }
  ]);
}

async function showBank(sock, m, usedPrefix, kd, note) {
  return sendCard(sock, m, `🏦 بنك ${kd.name}`, [
    { type: 'info', label: '💰 الذهب في اليد', value: formatNumber(kd.gold) },
    { type: 'info', label: '🏦 رصيد البنك', value: formatNumber(kd.vault) },
    { type: 'line', text: '🔒 رصيد البنك آمن ولا يُسرق عند الهجوم' },
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [
    { text: '📥 إيداع الكل', id: `${usedPrefix} ايداع الكل` },
    { text: '📤 سحب الكل', id: `${usedPrefix} سحب الكل` },
    { text: '🎲 لعبة الحظ', id: `${usedPrefix} حظ` },
    { text: '🔙 رجوع', id: usedPrefix }
  ]);
}

async function showGamble(sock, m, usedPrefix, kd, note) {
  return sendCard(sock, m, `🎲 لعبة الحظ`, [
    { type: 'info', label: '🏦 رصيد بنكك', value: formatNumber(kd.vault) },
    { type: 'line', text: 'فوز = يتضاعف رهانك (ربح صافي = نفس الرهان)' },
    { type: 'line', text: 'خسارة = يُخصم مبلغ الرهان من بنكك' },
    { type: 'line', text: `للرهان: ${usedPrefix} حظ [مبلغ]` },
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [
    { text: '🎲 راهن بالكل', id: `${usedPrefix} حظ الكل` },
    { text: '🔙 رجوع للبنك', id: `${usedPrefix} بنك` }
  ]);
}

async function showAlliance(sock, m, usedPrefix, kd, alliances, note) {
  const my = kd.allianceId ? alliances[kd.allianceId] : null;
  if (my) {
    const members = my.members.map((j, i) => ({ type: 'line', text: `${i + 1}. @${j.split('@')[0]}${j === my.leader ? ' 👑' : ''}` }));
    const income = getAllianceIncome(my.id, alliances);
    return sendCard(sock, m, `🤝 تحالف ${my.name}`, [
      { type: 'info', label: '👑 القائد', value: `@${my.leader.split('@')[0]}` },
      { type: 'info', label: '👥 الأعضاء', value: `${my.members.length}` },
      { type: 'info', label: '💰 دخل الرابطة', value: `${formatNumber(income)}/دخل` },
      { type: 'divider' },
      ...members,
      ...(note ? [{ type: 'divider' }, note] : [])
    ], [
      { text: '👥 تحديث', id: `${usedPrefix} تحالف` },
      { text: '🚪 مغادرة', id: `${usedPrefix} تحالف مغادرة` },
      { text: '🔙 رجوع', id: usedPrefix }
    ]);
  }
  const inviteNote = kd.pendingInvite && alliances[kd.pendingInvite]
    ? { type: 'line', text: `📩 لديك دعوة من: ${alliances[kd.pendingInvite].name}` } : null;
  return sendCard(sock, m, `🤝 لا تملك تحالفاً`, [
    { type: 'info', label: '💰 رصيدك', value: formatNumber(kd.gold) },
    { type: 'info', label: '💵 تكلفة التأسيس', value: formatNumber(ALLIANCE_CREATE_COST) },
    ...(inviteNote ? [{ type: 'divider' }, inviteNote] : []),
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [
    { text: '🏰 تأسيس تحالف', id: `${usedPrefix} تحالف انشاء` },
    ...(kd.pendingInvite ? [{ text: '✅ قبول الدعوة', id: `${usedPrefix} تحالف قبول` }] : []),
    { text: '🔙 رجوع', id: usedPrefix }
  ]);
}

// ─── إدارة الأبطال ───
async function showHeroesMenu(sock, m, usedPrefix, kd, note) {
  const heroLines = kd.heroes.map((h, idx) => {
    const stats = getHeroStats(enrichHeroWithGear(kd, h), h.level);
    const upReady = h.readyToUpgrade ? '🌟 [جاهز للترقية!]' : '';
    const weapon = kd.weapons[h.id] ? ` | 🗡️ ${kd.weapons[h.id].name}` : '';
    const shield = kd.heroShields[h.id] ? ` | 🛡️ ${kd.heroShields[h.id].name}` : '';
    return {
      type: 'line',
      text: `${idx + 1}. ${h.name} (${h.rank} - ${h.role} - ${h.element}) | لفل ${h.level}/100 | HP: ${formatNumber(stats.hp)} - ATK: ${formatNumber(stats.atk)} ${upReady}${weapon}${shield}`
    };
  });

  return sendCard(sock, m, `🛡️ أبطال ${kd.name} (${kd.heroes.length}/50)`, [
    ...heroLines,
    { type: 'divider' },
    { type: 'line', text: `ترقية بالذهب: ${usedPrefix} ابطال ترقية [رقم]` },
    { type: 'line', text: `كتاب تطوير: ${usedPrefix} ابطال كتاب [رقم]` },
    { type: 'line', text: `صناعة سلاح/درع: ${usedPrefix} سلاح_بطل [رقم] | ${usedPrefix} درع_بطل [رقم]` },
    { type: 'line', text: `تجنيد بطل: ${usedPrefix} تجنيد_بطل [عادي/مميز/خارق/أسطورة/اسم]` },
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [
    { text: '📜 كل الأبطال (50)', id: `${usedPrefix} عرض_ابطال` },
    { text: '➕ تجنيد بطل عادي', id: `${usedPrefix} تجنيد_بطل عادي` },
    { text: '🔙 رجوع للقائمة', id: usedPrefix }
  ]);
}

// ─── مخزون القلوب واللفائف ───
async function showHeartsMenu(sock, m, usedPrefix, kd, note) {
  const heartLines = Object.entries(kd.hearts).filter(([, q]) => q > 0)
    .sort((a, b) => Number(a[0]) - Number(b[0]))
    .map(([lvl, q]) => ({ type: 'line', text: `❤️ قلب وحش (مستوى ${lvl}) × ${q} ⟞ سعر البيع للواحد: ${formatNumber(heartSellPrice(Number(lvl)))}$` }));
  const leaderLines = Object.entries(kd.leaderHearts).filter(([, q]) => q > 0)
    .map(([elem, q]) => ({ type: 'line', text: `💎 قلب زعيم (${elem}) × ${q}` }));
  const scrollLines = Object.entries(kd.scrolls).filter(([, q]) => q > 0)
    .map(([elem, q]) => ({ type: 'line', text: `📜 لفيفة عنصر (${elem}) × ${q}` }));

  return sendCard(sock, m, `❤️ قلوب ولفائف ${kd.name}`, [
    { type: 'subtitle', text: 'قلوب الوحوش' },
    ...(heartLines.length ? heartLines : [{ type: 'line', text: 'لا تملك أي قلوب وحوش' }]),
    { type: 'subtitle', text: 'قلوب الزعماء' },
    ...(leaderLines.length ? leaderLines : [{ type: 'line', text: 'لا تملك أي قلوب زعماء' }]),
    { type: 'subtitle', text: 'لفائف العناصر' },
    ...(scrollLines.length ? scrollLines : [{ type: 'line', text: 'لا تملك أي لفائف' }]),
    { type: 'divider' },
    { type: 'line', text: `لبيع قلب: ${usedPrefix} بيع_قلب [مستوى] [عدد]` },
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [
    { text: '🛡️ أبطال المملكة', id: `${usedPrefix} ابطال` },
    { text: '🔙 رجوع للقائمة', id: usedPrefix }
  ]);
}

// ─── قائمة الأبطال الـ 50 ───
async function showHeroCatalog(sock, m, usedPrefix, kd) {
  const lines = [...HERO_DATABASE].sort((a, b) => a.listIndex - b.listIndex).map(h => {
    const owned = kd.heroes.some(myH => myH.id === h.id);
    return { type: 'line', text: `${h.listIndex}. ${h.name} | ${h.rank} | ${h.role} | ${h.element} ${owned ? '✅' : ''}` };
  });
  return sendCard(sock, m, `📜 قائمة الأبطال (1 الأضعف ← 50 الأقوى)`, [
    ...lines,
    { type: 'divider' },
    { type: 'line', text: `لعرض تفاصيل بطل: ${usedPrefix} اختيار_بطل [الاسم أو الرقم]` }
  ], [
    { text: '🛡️ أبطالي', id: `${usedPrefix} ابطال` },
    { text: '🔙 رجوع للقائمة', id: usedPrefix }
  ]);
}

async function showHeroDetail(sock, m, usedPrefix, kd, hero, note) {
  const req = getHeroTierRequirement(hero.rank);
  const legReq = LEGENDARY_HERO_REQUIREMENTS[hero.id];
  const owned = kd.heroes.find(myH => myH.id === hero.id);
  const reqLines = [];
  if (req) {
    reqLines.push({ type: 'info', label: '💰 التكلفة', value: formatNumber(req.gold) });
    reqLines.push({ type: 'info', label: '❤️ قلب وحش مطلوب', value: `مستوى ${req.heartLevel} فما فوق` });
    if (req.scrollTier) reqLines.push({ type: 'info', label: '📜 لفيفة عنصر', value: 'مطلوبة (من عنصر قوي)' });
  } else if (legReq) {
    reqLines.push({ type: 'info', label: '💰 التكلفة', value: formatNumber(legReq.gold) });
    reqLines.push({ type: 'info', label: '📖 كتاب مطلوب', value: `كتاب ${legReq.bookElement}` });
    reqLines.push({ type: 'info', label: '💎 قلب زعيم مطلوب', value: `قلب زعيم (${legReq.leaderHeartElement})` });
  }
  return sendCard(sock, m, `🔎 بطل: ${hero.name}`, [
    { type: 'info', label: '📊 الترتيب', value: `${hero.listIndex} / 50` },
    { type: 'info', label: '🎖️ الفئة', value: hero.rank },
    { type: 'info', label: '⚔️ الدور', value: hero.role },
    { type: 'info', label: '🔮 العنصر', value: hero.element },
    { type: 'info', label: '📦 الحالة', value: owned ? `مملوك (لفل ${owned.level})` : 'غير مملوك' },
    { type: 'divider' },
    ...reqLines,
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [
    { text: '➕ تجنيد هذه الفئة', id: `${usedPrefix} تجنيد_بطل ${hero.rank}` },
    { text: '📜 قائمة الأبطال', id: `${usedPrefix} عرض_ابطال` },
    { text: '🔙 رجوع', id: usedPrefix }
  ]);
}

// ─── المهام اليومية ───
async function showMissions(sock, m, usedPrefix, kd, note) {
  const dm = ensureDailyMissions(kd);
  const lines = DAILY_MISSION_POOL.map(def => {
    const task = dm.tasks.find(t => t.id === def.id);
    const done = task.progress >= def.target ? '✅' : '⏳';
    return { type: 'line', text: `${done} ${def.label} (${task.progress}/${def.target})` };
  });
  const finished = allMissionsDone(kd);
  return sendCard(sock, m, `🗒️ مهام اليوم`, [
    ...lines,
    { type: 'divider' },
    { type: 'info', label: '🎁 المكافأة', value: `${formatNumber(DAILY_MISSION_REWARD.gold)}$ + ${DAILY_MISSION_REWARD.gift}` },
    { type: 'info', label: '📌 الحالة', value: dm.claimed ? 'تم الاستلام اليوم ✅' : (finished ? 'جاهزة للاستلام! 🎉' : 'قيد الإنجاز') },
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [
    ...(finished && !dm.claimed ? [{ text: '🎁 استلام مكافأة المهام', id: `${usedPrefix} مهام استلام` }] : []),
    { text: '🔄 تحديث', id: `${usedPrefix} مهام` },
    { text: '🔙 رجوع', id: usedPrefix }
  ]);
}

// ─── الهدايا الدورية ───
async function showGifts(sock, m, usedPrefix, kd, note) {
  const now = Date.now();
  const dailyReady = now - kd.lastDailyGift >= GIFT_DAILY_COOLDOWN;
  const weeklyReady = now - kd.lastWeeklyGift >= GIFT_WEEKLY_COOLDOWN;
  const monthlyReady = now - kd.lastMonthlyGift >= GIFT_MONTHLY_COOLDOWN;
  return sendCard(sock, m, `🎁 الهدايا الدورية`, [
    { type: 'info', label: '📅 يومية', value: dailyReady ? `جاهزة (${formatNumber(GIFT_DAILY_AMOUNT)}$)` : `عد بعد ${msToTime(GIFT_DAILY_COOLDOWN - (now - kd.lastDailyGift))}` },
    { type: 'info', label: '📆 أسبوعية', value: weeklyReady ? `جاهزة (${formatNumber(GIFT_WEEKLY_AMOUNT)}$)` : `عد بعد ${msToTime(GIFT_WEEKLY_COOLDOWN - (now - kd.lastWeeklyGift))}` },
    { type: 'info', label: '🗓️ شهرية', value: monthlyReady ? `جاهزة (${formatNumber(GIFT_MONTHLY_AMOUNT)}$)` : `عد بعد ${msToTime(GIFT_MONTHLY_COOLDOWN - (now - kd.lastMonthlyGift))}` },
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [
    ...(dailyReady ? [{ text: '📅 استلام اليومية', id: `${usedPrefix} هدية يومية` }] : []),
    ...(weeklyReady ? [{ text: '📆 استلام الأسبوعية', id: `${usedPrefix} هدية اسبوعية` }] : []),
    ...(monthlyReady ? [{ text: '🗓️ استلام الشهرية', id: `${usedPrefix} هدية شهرية` }] : []),
    { text: '🔙 رجوع', id: usedPrefix }
  ]);
}

// ─── الألقاب ───
async function showTitles(sock, m, usedPrefix, kd, note) {
  const lines = Object.entries(TITLES).map(([key, t]) => {
    const owned = kd.titles.includes(key);
    const active = kd.activeTitle === key ? ' (مفعّل ⭐)' : '';
    return { type: 'line', text: `${owned ? '🏅' : '🔒'} ${t.name}${owned ? active : ' (غير مفتوح)'}` };
  });
  return sendCard(sock, m, `🏅 ألقاب ${kd.name}`, [
    ...lines,
    { type: 'divider' },
    { type: 'line', text: `لتفعيل لقب: ${usedPrefix} لقب [اسم مختصر]` },
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [{ text: '🔙 رجوع', id: usedPrefix }]);
}

// ─── أدواتك الخاصة (من نظامك الأصلي) ───
async function showToolsMenu(sock, m, usedPrefix, kd, note) {
  const lines = Object.entries(kd.tools || {}).map(([tName, tData]) => ({
    type: 'line',
    text: `🛠️ ${tName} ⟞ [${tData.rank}] | Lvl: ${tData.level}/15`
  }));
  return sendCard(sock, m, `⚒️ الأدوات والمعدات`, [
    ...lines,
    { type: 'divider' },
    { type: 'line', text: 'تطوير الأدوات يزيد الموارد والقوة!' },
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [
    { text: '🪓 تطوير الفأس', id: `${usedPrefix} ترقية_أداة فأس` },
    { text: '⛏️ تطوير البيكاكس', id: `${usedPrefix} ترقية_أداة بيكاكس` },
    { text: '🗡️ تطوير السيف', id: `${usedPrefix} ترقية_أداة سيف` },
    { text: '🌾 تطوير المعزقة', id: `${usedPrefix} ترقية_أداة معزقة` },
    { text: '🔙 رجوع', id: usedPrefix }
  ]);
}

// ─── مكتبة الكتب (دمج نظامك الأصلي) ───
async function showBooksMenu(sock, m, usedPrefix, kd, note) {
  const lines = Object.entries(BOOKS).map(([bName, bInfo]) => {
    const owned = kd.books[bName] || 0;
    return { type: 'line', text: `📜 ${bName} (${owned}) ⟞ ${bInfo.desc} — ${formatNumber(bInfo.price)}$` };
  });
  return sendCard(sock, m, `📜 مكتبة الكتب`, [
    { type: 'info', label: '⚡ المفعل حالياً', value: kd.activeBooks.join(', ') || 'لا يوجد' },
    { type: 'divider' },
    ...lines,
    { type: 'divider' },
    { type: 'line', text: `للشراء: ${usedPrefix} شراء_كتاب [اسم الكتاب]` },
    { type: 'line', text: `للتفعيل: ${usedPrefix} تفعيل [اسم الكتاب]` },
    { type: 'line', text: `دمج شظايا التمريرة (10 + 100k): ${usedPrefix} دمج_لفائف` },
    ...(note ? [{ type: 'divider' }, note] : [])
  ], [
    { text: '✨ تفعيل كتاب سحر', id: `${usedPrefix} تفعيل كتاب_سحر` },
    { text: '⚔️ تفعيل كتاب شجاعة', id: `${usedPrefix} تفعيل كتاب_شجاعة` },
    { text: '💰 تفعيل كتاب موارد', id: `${usedPrefix} تفعيل كتاب_موارد` },
    { text: '🔮 دمج لفائف العناصر', id: `${usedPrefix} دمج_لفائف` },
    { text: '🔙 رجوع', id: usedPrefix }
  ]);
}

// ==================== المعالج الرئيسي ====================
async function runAction(ctx) {
  const { sock, m, args, action: rawAction, usedPrefix, user, kd, chatData, isGroup } = ctx;
  let action = rawAction;
  const alliances = getAlliances();

  // ─── أمر المطور ───
  if (action === 'الجروبات') {
    if (!isBotOwner(m)) return m.reply('⚠️ هذا الأمر لمطور البوت فقط!');
    const list = (global.kdKnownJids || []).map(j => getUser(j)).filter(u => u && u.kingdom);
    const lines = list.slice(0, 30).map((u, i) => ({ type: 'line', text: `${i + 1}. ${u.kingdom.name}` }));
    return sendCard(sock, m, `🗂️ اللاعبون المسجلون (${list.length})`, lines.length ? lines : [{ type: 'line', text: 'لا يوجد لاعبون بعد' }], [{ text: '🔙 رجوع', id: usedPrefix }]);
  }

  // ─── تفعيل/إيقاف اللعبة بالجروب ───
  if (isGroup && (action === 'تشغيل' || action === 'تشغيل_اللعبة')) {
    chatData.kingdomEnabled = true;
    return m.reply('✅ تم تفعيل اللعبة في هذا الجروب');
  }
  if (isGroup && (action === 'ايقاف' || action === 'ايقاف_اللعبة')) {
    chatData.kingdomEnabled = false;
    return m.reply('⛔ تم إيقاف اللعبة في هذا الجروب');
  }
  if (isGroup && !ensureGameEnabled(chatData)) {
    return m.reply(`⛔ اللعبة غير مفعّلة هنا — فعّلها بالأمر: ${usedPrefix} تشغيل`);
  }

  // ─── أحداث العالم العشوائية ───
  if (isGroup && chatData) {
    trackKnownPlayer(chatData, getSenderId(m));
    ensureWeather(chatData);
    try { await resolveWorldEventExpiry(sock, m.chat, chatData); } catch (e) {}
    const newEvent = maybeTriggerWorldEvent(chatData);
    if (newEvent) {
      try { await sock.sendMessage(m.chat, { text: buildBody('🌐 حدث عالمي!', worldEventAnnouncement(newEvent)) }); } catch (e) {}
      if (newEvent.type === 'تنين_عالمي') {
        setTimeout(() => { resolveDragonWorldEvent(sock, m.chat, chatData); }, WORLD_EVENT_DURATION + 2000);
      }
    }
  }

  // ─── القائمة الرئيسية ───
  if (!action) return showMain(sock, m, usedPrefix, `🏰 تقرير حالة ${kd.name}`, [], kd);

  // ─── أسماء بديلة للتوافق ───
  if (action === 'وحوش') action = 'وحش';
  if (action === 'وحش_عالمي') action = 'زعيم';
  if (action === 'أبطال' || action === 'ابطالي') action = 'ابطال';
  if (action === 'متجري' || action === 'متجر_اللاعب') { /* يُعالج أسفل */ }
  if (action === 'دمج_اللفيفة') action = 'دمج_لفائف';
  if (action === 'تفعيل_كتاب') action = 'تفعيل';

  // ─── إدارة الأبطال ───
  if (action === 'ابطال') {
    const sub = (args[1] || '').trim();

    if (sub === 'تجنيد') {
      const req = HERO_TIER_REQUIREMENTS['عادي'];
      if (kd.heroes.length >= 50) return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'warning', text: 'وصلت للحد الأقصى من الأبطال!' });
      if (kd.gold < req.gold) return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'warning', text: `تجنيد بطل عادي يتطلب ${formatNumber(req.gold)}$ وقلب وحش مستوى 1 فما فوق` });
      if (getBestHeartLevel(kd) < req.heartLevel) return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'warning', text: `تحتاج قلب وحش مستوى ${req.heartLevel} فما فوق! اصطد وحوشاً أولاً` });
      const available = HERO_DATABASE.filter(h => h.rank === 'عادي' && !kd.heroes.some(myH => myH.id === h.id));
      if (!available.length) return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'warning', text: 'امتلكت كل أبطال الفئة العادية! جرّب: تجنيد_بطل مميز' });
      kd.gold -= req.gold;
      consumeHeartAtLeast(kd, req.heartLevel);
      const pickedHero = pick(available);
      kd.heroes.push({ ...pickedHero, level: 1, exp: 0, readyToUpgrade: false });
      return showHeroesMenu(sock, m, usedPrefix, kd, {
        type: 'info', label: '🎉 تم تجنيد بطل جديد!',
        value: `${pickedHero.name} | ${pickedHero.rank} | ${pickedHero.role} | ${pickedHero.element}`
      });
    }

    if (sub === 'ترقية') {
      const idx = parseInt(args[2]) - 1;
      if (isNaN(idx) || !kd.heroes[idx]) return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'warning', text: 'حدد رقم بطل صحيح للترقية.' });
      const hero = kd.heroes[idx];
      if (hero.level >= 100) return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'warning', text: 'البطل بلغ المستوى الأقصى (100)!' });
      if (!hero.readyToUpgrade) return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'warning', text: 'البطل ليس جاهزاً للترقية بعد! قاتل به أولاً.' });
      const cost = hero.level * 15000;
      if (kd.gold < cost) return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'warning', text: `تحتاج ${formatNumber(cost)}$ لترقية ${hero.name}` });
      kd.gold -= cost;
      hero.level += 1;
      hero.readyToUpgrade = false;
      hero.exp = 0;
      return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'info', label: '🌟 تمت الترقية!', value: `${hero.name} أصبح في المستوى ${hero.level}` });
    }

    if (sub === 'كتاب') {
      const idx = parseInt(args[2]) - 1;
      if (isNaN(idx) || !kd.heroes[idx]) return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'warning', text: 'حدد رقم بطل صحيح.' });
      const hero = kd.heroes[idx];
      if (hero.level >= 100) return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'warning', text: 'البطل في المستوى الأقصى!' });
      if ((kd.books['كتاب_تطوير'] || 0) <= 0) return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'warning', text: 'لا تملك كتاب تطوير!' });
      kd.books['كتاب_تطوير'] -= 1;
      let levelUpAmount = hero.id === 'maro' ? 4 : 1;
      hero.level = Math.min(100, hero.level + levelUpAmount);
      hero.readyToUpgrade = false;
      return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'info', label: '📖 كتاب التطوير!', value: `${hero.name} ارتفع +${levelUpAmount} (المستوى: ${hero.level})` });
    }

    return showHeroesMenu(sock, m, usedPrefix, kd);
  }

  // ─── تجنيد بطل حسب الفئة ───
  if (action === 'تجنيد_بطل') {
    const rankArg = (args[1] || '').trim();
    if (kd.heroes.length >= 50) return m.reply('⚠️ وصلت للحد الأقصى من الأبطال!');

    const heroDef = HERO_DATABASE.find(h => h.name === rankArg);
    const legReq = heroDef ? LEGENDARY_HERO_REQUIREMENTS[heroDef.id] : null;

    if (legReq) {
      if (kd.heroes.some(h => h.id === heroDef.id)) return m.reply(`⚠️ تملك بالفعل ${heroDef.name}!`);
      if (kd.gold < legReq.gold) return m.reply(`⚠️ تحتاج ${formatNumber(legReq.gold)}$ لإنشاء ${heroDef.name}`);
      if ((kd.heroBooks[legReq.bookElement] || 0) < 1) return m.reply(`⚠️ تحتاج كتاب (${legReq.bookElement})`);
      if ((kd.leaderHearts[legReq.leaderHeartElement] || 0) < 1) return m.reply(`⚠️ تحتاج قلب زعيم (${legReq.leaderHeartElement})`);
      kd.gold -= legReq.gold;
      kd.heroBooks[legReq.bookElement] -= 1;
      kd.leaderHearts[legReq.leaderHeartElement] -= 1;
      kd.heroes.push({ ...heroDef, level: 1, exp: 0, readyToUpgrade: false });
      return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'info', label: '🎉 وُلد بطل أسطوري!', value: `${heroDef.name} انضم لصفوفك!` });
    }

    const req = getHeroTierRequirement(rankArg);
    if (!req) {
      return m.reply(`⚠️ اكتب فئة صحيحة: عادي / مميز / خارق / أسطورة، أو اسم بطل من فئة "لا يقهر" (أوتا/مارو/نيرو/سيلين/كايوس)\nمثال: ${usedPrefix} تجنيد_بطل عادي`);
    }
    const available = HERO_DATABASE.filter(h => h.rank === rankArg && !kd.heroes.some(myH => myH.id === h.id));
    if (!available.length) return m.reply('⚠️ امتلكت كل أبطال هذه الفئة بالفعل!');
    if (kd.gold < req.gold) return m.reply(`⚠️ تحتاج ${formatNumber(req.gold)}$ لتجنيد بطل من فئة ${rankArg}`);
    if (getBestHeartLevel(kd) < req.heartLevel) return m.reply(`⚠️ تحتاج قلب وحش من مستوى ${req.heartLevel} فما فوق (أعلى قلب تملكه: ${getBestHeartLevel(kd)})`);
    if (req.scrollTier === 'قوي' && !hasStrongScroll(kd)) return m.reply('⚠️ تحتاج لفيفة عنصر (من عنصر قوي)!');

    kd.gold -= req.gold;
    consumeHeartAtLeast(kd, req.heartLevel);
    if (req.scrollTier === 'قوي') consumeAnyStrongScroll(kd);
    const pickedHero = pick(available);
    kd.heroes.push({ ...pickedHero, level: 1, exp: 0, readyToUpgrade: false });
    return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'info', label: '🎉 تم إنشاء بطل جديد!', value: `${pickedHero.name} | ${pickedHero.rank} | ${pickedHero.role} | ${pickedHero.element}` });
  }

  if (action === 'عرض_ابطال') return showHeroCatalog(sock, m, usedPrefix, kd);

  if (action === 'اختيار_بطل') {
    const identifier = args.slice(1).join(' ').trim();
    const hero = getHeroByIdentifier(identifier);
    if (!hero) return m.reply('⚠️ لم أجد بطلاً بهذا الاسم أو الرقم! استخدم رقماً من 1 إلى 50.');
    return showHeroDetail(sock, m, usedPrefix, kd, hero);
  }

  // ─── القلوب واللفائف ───
  if (action === 'قلوب') return showHeartsMenu(sock, m, usedPrefix, kd);

  if (action === 'بيع_قلب') {
    const level = parseInt(args[1]);
    const qty = Math.max(1, parseInt(args[2]) || 1);
    if (!level || (kd.hearts[level] || 0) < qty) return showHeartsMenu(sock, m, usedPrefix, kd, { type: 'warning', text: 'لا تملك هذا العدد من القلوب بهذا المستوى!' });
    kd.hearts[level] -= qty;
    const total = heartSellPrice(level) * qty;
    kd.gold += total;
    return showHeartsMenu(sock, m, usedPrefix, kd, { type: 'info', label: '💰 تم البيع', value: `بعت ${qty} قلب (مستوى ${level}) مقابل ${formatNumber(total)}$` });
  }

  if (action === 'دمج_كتاب_عنصر') {
    const elem = (args[1] || '').trim();
    if (!LEGENDARY_ELEMENTS.includes(elem)) return m.reply('⚠️ حدد عنصراً أسطورياً: ظلام / نور / فراغ');
    if (kd.gold < 500000) return m.reply('⚠️ صنع كتاب عنصر أسطوري يتطلب 500,000$');
    kd.gold -= 500000;
    kd.heroBooks[elem] = (kd.heroBooks[elem] || 0) + 1;
    return m.reply(`📖 تم صنع كتاب عنصر! حصلت على كتاب (${elem}).`);
  }

  // ─── صناعة سلاح/درع لبطل ───
  if (action === 'سلاح_بطل') {
    const idx = parseInt(args[1]) - 1;
    const hero = kd.heroes[idx];
    if (!hero) return m.reply('⚠️ حدد رقم بطل صحيح من قائمة أبطالك!');
    if (hero.id === 'outa' && kd.weapons['outa']) return m.reply('⚠️ أوتا يمتلك منجله الخاص بالفعل!');
    const req = getHeroTierRequirement(hero.rank) || (() => {
      const l = LEGENDARY_HERO_REQUIREMENTS[hero.id];
      return l ? { gold: Math.floor(l.gold / 2), heartLevel: null, scrollTier: null, bookElement: l.bookElement, leaderHeartElement: l.leaderHeartElement } : null;
    })();
    if (!req) return m.reply('⚠️ تعذر تحديد متطلبات صناعة السلاح!');
    const weaponCost = Math.floor(req.gold / 2);
    if (kd.gold < weaponCost) return m.reply(`⚠️ تحتاج ${formatNumber(weaponCost)}$ لصناعة سلاح لهذا البطل`);
    if (req.heartLevel && getBestHeartLevel(kd) < req.heartLevel) return m.reply(`⚠️ تحتاج قلب وحش من مستوى ${req.heartLevel} فما فوق!`);
    if (req.scrollTier === 'قوي' && !hasStrongScroll(kd)) return m.reply('⚠️ تحتاج لفيفة عنصر قوي!');
    if (req.bookElement) {
      if ((kd.heroBooks[req.bookElement] || 0) < 1) return m.reply(`⚠️ تحتاج كتاب (${req.bookElement})!`);
      if ((kd.leaderHearts[req.leaderHeartElement] || 0) < 1) return m.reply(`⚠️ تحتاج قلب زعيم (${req.leaderHeartElement})!`);
    }
    kd.gold -= weaponCost;
    if (req.heartLevel) consumeHeartAtLeast(kd, req.heartLevel);
    if (req.scrollTier === 'قوي') consumeAnyStrongScroll(kd);
    if (req.bookElement) { kd.heroBooks[req.bookElement] -= 1; kd.leaderHearts[req.leaderHeartElement] -= 1; }
    const weaponAtk = WEAPON_TIER_BONUS[hero.rank] || 1500;
    kd.weapons[hero.id] = { tier: hero.rank, name: hero.id === 'outa' ? 'منجل أوتا الخاص' : `سلاح ${hero.name}`, atk: weaponAtk };
    return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'info', label: '⚔️ تم صنع السلاح!', value: `${hero.name} حصل على ${kd.weapons[hero.id].name} (+${formatNumber(weaponAtk)} هجوم)` });
  }

  if (action === 'درع_بطل') {
    const idx = parseInt(args[1]) - 1;
    const hero = kd.heroes[idx];
    if (!hero) return m.reply('⚠️ حدد رقم بطل صحيح من قائمة أبطالك!');
    const req = getHeroTierRequirement(hero.rank);
    const legReq = LEGENDARY_HERO_REQUIREMENTS[hero.id];
    const gold = req ? Math.floor(req.gold / 3) : Math.floor((legReq?.gold || 3000000) / 3);
    if (kd.gold < gold) return m.reply(`⚠️ تحتاج ${formatNumber(gold)}$ لصناعة درع لهذا البطل`);
    kd.gold -= gold;
    const shieldHp = SHIELD_TIER_BONUS[hero.rank] || 3000;
    kd.heroShields[hero.id] = { tier: hero.rank, name: `درع_البطل_${hero.name}`, hp: shieldHp };
    return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'info', label: '🛡️ تم صنع الدرع!', value: `${hero.name} حصل على درع (+${formatNumber(shieldHp)} صحة)` });
  }

  if (action === 'سلاح_ماء') {
    const idx = parseInt(args[1]) - 1;
    const hero = kd.heroes[idx];
    if (!hero) return m.reply('⚠️ حدد رقم بطل صحيح من قائمة أبطالك!');
    const isTopBow = hero.role === 'رامي' && hero.rank === 'لا يقهر';
    if (isTopBow && kd.mermaidScales < 1) return m.reply('⚠️ صناعة القوس الأعلى تحتاج حرشفة حورية بحر!');
    if (hero.rank === 'عادي') return m.reply('⚠️ سلاح الماء لا يُصنع للفئة العادية!');
    const req = getHeroTierRequirement(hero.rank) || { gold: 2000000 };
    const cost = Math.floor(req.gold / 2);
    if (kd.gold < cost) return m.reply(`⚠️ تحتاج ${formatNumber(cost)}$!`);
    kd.gold -= cost;
    if (isTopBow) kd.mermaidScales -= 1;
    const weaponAtk = Math.floor((WEAPON_TIER_BONUS[hero.rank] || 1500) * (isTopBow ? 2 : 1.3));
    kd.weapons[hero.id] = { tier: hero.rank, name: isTopBow ? 'قوس حورية البحر الأسطوري' : `سلاح ماء ${hero.name}`, atk: weaponAtk };
    return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'info', label: '🌊 تم صنع سلاح الماء!', value: `${hero.name} حصل على ${kd.weapons[hero.id].name}` });
  }

  // ─── المهام اليومية ───
  if (action === 'مهام') {
    const sub = (args[1] || '').trim();
    if (sub === 'استلام') {
      if (!allMissionsDone(kd)) return showMissions(sock, m, usedPrefix, kd, { type: 'warning', text: 'لم تُنهِ كل المهام بعد!' });
      const dm = ensureDailyMissions(kd);
      if (dm.claimed) return showMissions(sock, m, usedPrefix, kd, { type: 'warning', text: 'استلمت مكافأة اليوم بالفعل!' });
      dm.claimed = true;
      kd.gold += DAILY_MISSION_REWARD.gold;
      kd.inventory['سيف عادي'] = (kd.inventory['سيف عادي'] || 0) + 1;
      return showMissions(sock, m, usedPrefix, kd, { type: 'info', label: '🎉 تم الاستلام!', value: `+${formatNumber(DAILY_MISSION_REWARD.gold)}$ + سيف عادي` });
    }
    return showMissions(sock, m, usedPrefix, kd);
  }

  // ─── الهدايا الدورية ───
  if (action === 'هدية') {
    const sub = (args[1] || '').trim();
    const now = Date.now();
    if (sub === 'يومية') {
      if (now - kd.lastDailyGift < GIFT_DAILY_COOLDOWN) return showGifts(sock, m, usedPrefix, kd, { type: 'warning', text: 'الهدية اليومية غير جاهزة بعد!' });
      kd.lastDailyGift = now; kd.gold += GIFT_DAILY_AMOUNT;
      return showGifts(sock, m, usedPrefix, kd, { type: 'info', label: '🎁 الهدية اليومية', value: `+${formatNumber(GIFT_DAILY_AMOUNT)}$` });
    }
    if (sub === 'اسبوعية') {
      if (now - kd.lastWeeklyGift < GIFT_WEEKLY_COOLDOWN) return showGifts(sock, m, usedPrefix, kd, { type: 'warning', text: 'الهدية الأسبوعية غير جاهزة بعد!' });
      kd.lastWeeklyGift = now; kd.gold += GIFT_WEEKLY_AMOUNT;
      return showGifts(sock, m, usedPrefix, kd, { type: 'info', label: '🎁 الهدية الأسبوعية', value: `+${formatNumber(GIFT_WEEKLY_AMOUNT)}$` });
    }
    if (sub === 'شهرية') {
      if (now - kd.lastMonthlyGift < GIFT_MONTHLY_COOLDOWN) return showGifts(sock, m, usedPrefix, kd, { type: 'warning', text: 'الهدية الشهرية غير جاهزة بعد!' });
      kd.lastMonthlyGift = now; kd.gold += GIFT_MONTHLY_AMOUNT;
      return showGifts(sock, m, usedPrefix, kd, { type: 'info', label: '🎁 الهدية الشهرية', value: `+${formatNumber(GIFT_MONTHLY_AMOUNT)}$` });
    }
    return showGifts(sock, m, usedPrefix, kd);
  }

  // ─── الألقاب ───
  if (action === 'القاب') return showTitles(sock, m, usedPrefix, kd);
  if (action === 'لقب') {
    const key = (args[1] || '').trim();
    if (!kd.titles.includes(key)) return showTitles(sock, m, usedPrefix, kd, { type: 'warning', text: 'لا تملك هذا اللقب بعد!' });
    kd.activeTitle = key;
    return showTitles(sock, m, usedPrefix, kd, { type: 'info', label: '⭐ تم التفعيل', value: TITLES[key].name });
  }

  // ─── حلبة الأبطال (PvP) ───
  if (action === 'حلبة') {
    const targetJid = getMentionedJid(m) || getQuotedSender(m);
    if (!targetJid) {
      return sendCard(sock, m, `🏟️ حلبة الأبطال`, [
        { type: 'line', text: 'تطاحن الأبطال والمخاطرة بالجوائز!' },
        { type: 'line', text: 'الفائز يختار: أسر بطل الخصم، أو كتب تطوير، أو سرقة عنصره!' },
        { type: 'divider' },
        { type: 'line', text: `للمبارزة: ${usedPrefix} حلبة @لاعب` }
      ], [{ text: '🔙 رجوع', id: usedPrefix }]);
    }
    if (targetJid === getSenderId(m)) return m.reply('⚠️ لا يمكنك مبارزة نفسك!');
    const targetUser = getUser(targetJid);
    if (!targetUser || !targetUser.kingdom) return m.reply('⚠️ الخصم لا يملك مملكة!');

    const enemyKd = targetUser.kingdom;
    if (!kd.heroes.length || !enemyKd.heroes.length) return m.reply('⚠️ يجب أن يملك كلا الطرفين بطلاً واحداً على الأقل!');

    const myHero = kd.heroes[0];
    const enemyHero = enemyKd.heroes[0];
    const myStats = getHeroStats(enrichHeroWithGear(kd, myHero), myHero.level);
    const enemyStats = getHeroStats(enrichHeroWithGear(enemyKd, enemyHero), enemyHero.level);

    let myPower = myStats.atk + myStats.hp;
    let enemyPower = enemyStats.atk + enemyStats.hp;
    const myElem = getEffectiveElement(kd);
    const enemyElem = getEffectiveElement(enemyKd);
    myPower *= getElementMultiplier(myElem, enemyElem);
    enemyPower *= getElementMultiplier(enemyElem, myElem);
    const winChance = (myPower / (myPower + enemyPower)) * 100;

    if (getRandomInt(1, 100) <= winChance) {
      let rewardText = '';
      if (enemyKd.heroes.length > 1) {
        const stolen = enemyKd.heroes.pop();
        if (kd.heroes.length < 50) kd.heroes.push(stolen);
        rewardText = `تم أسر البطل (${stolen.name}) وضمه لصفوفك!`;
      } else if (enemyKd.books['كتاب_تطوير'] >= 2) {
        enemyKd.books['كتاب_تطوير'] -= 2;
        kd.books['كتاب_تطوير'] = (kd.books['كتاب_تطوير'] || 0) + 2;
        rewardText = 'دفع الخصم 2 كتاب تطوير كفدية!';
      } else {
        const oldElem = enemyKd.element;
        kd.element = oldElem;
        rewardText = `سحبت عنصر الخصم (${oldElem})!`;
      }
      return sendCard(sock, m, `🏆 انتصار ساحق في الحلبة!`, [
        { type: 'info', label: 'بطلك الفائز', value: `${myHero.name} (لفل ${myHero.level})` },
        { type: 'info', label: 'بطل الخصم', value: `${enemyHero.name} (لفل ${enemyHero.level})` },
        { type: 'line', text: rewardText }
      ], [{ text: '🔙 رجوع', id: usedPrefix }]);
    } else {
      return sendCard(sock, m, `💥 هزيمة في الحلبة!`, [
        { type: 'warning', text: `تغلب بطل الخصم (${enemyHero.name}) على بطلك (${myHero.name})!` }
      ], [{ text: '🔙 رجوع', id: usedPrefix }]);
    }
  }

  // ─── الكتب السحرية ───
  if (action === 'كتب') return showBooksMenu(sock, m, usedPrefix, kd);

  if (action === 'شراء_كتاب') {
    const bName = (args[1] || '').trim();
    if (!BOOKS[bName]) return m.reply('⚠️ كتاب غير معروف.');
    const price = BOOKS[bName].price;
    if (kd.gold < price) return m.reply(`⚠️ تحتاج ${formatNumber(price)}$`);
    kd.gold -= price;
    kd.books[bName] = (kd.books[bName] || 0) + 1;
    return m.reply(`✅ اشتريت ${bName}!`);
  }

  if (action === 'تفعيل') {
    const bookName = (args[1] || '').trim();
    if (!BOOKS[bookName]) return m.reply('⚠️ الكتاب غير موجود!');
    if ((kd.books[bookName] || 0) <= 0) return m.reply('⚠️ لا تملك هذا الكتاب!');
    if (bookName === 'كتاب_شجاعة') {
      const courageCount = kd.activeBooks.filter(b => b === 'كتاب_شجاعة').length;
      if (courageCount >= 3) return m.reply('⚠️ الحد الأقصى 3 كتب شجاعة معاً!');
    }
    if (bookName === 'كتاب_عناصر') {
      kd.books[bookName] -= 1;
      kd.tempElement = pick(['ظلام', 'نور', 'فراغ']);
      kd.tempElementExpires = Date.now() + (60 * 60 * 1000);
      return m.reply(`✨ تفعيل كتاب العناصر! حصلت على عنصر (${kd.tempElement}) لمدة ساعة!`);
    }
    kd.books[bookName] -= 1;
    kd.activeBooks.push(bookName);
    return m.reply(`📖 تم تفعيل ${bookName}! ${BOOKS[bookName].desc}`);
  }

  if (action === 'استخدم_كتاب') {
    if ((kd.books['كتاب_تطوير'] || 0) <= 0) return m.reply('⚠️ لا تملك كتاب تطوير!');
    if (!kd.heroes.length) return m.reply('⚠️ لا تملك أبطالاً.');
    const targetHero = kd.heroes[0];
    kd.books['كتاب_تطوير'] -= 1;
    const up = targetHero.id === 'maro' ? 4 : 1;
    targetHero.level = Math.min(100, targetHero.level + up);
    targetHero.readyToUpgrade = false;
    return showHeroesMenu(sock, m, usedPrefix, kd, { type: 'info', label: '📜 كتاب التطوير!', value: `${targetHero.name} ارتفع +${up} (المستوى: ${targetHero.level})` });
  }

  if (action === 'دمج_لفائف') {
    if (kd.scrollPieces < 10) return m.reply(`⚠️ تحتاج 10 شظايا تمريرة للدمج. تملك: ${kd.scrollPieces}`);
    if (kd.gold < 100000) return m.reply('⚠️ الدمج يتطلب 100,000$');
    kd.scrollPieces -= 10;
    kd.gold -= 100000;
    kd.books['كتاب_عناصر'] = (kd.books['كتاب_عناصر'] || 0) + 1;
    return m.reply('📜 تم دمج التمريرة! حصلت على كتاب_عناصر نادر!');
  }

  // ─── ساحة المعارك ───
  if (action === 'معارك') return showBattleMenu(sock, m, usedPrefix, kd);

  // ─── قتال الزعيم العالمي ───
  if (action === 'زعيم') {
    if (!isGroup || !chatData) return m.reply('⚠️ الزعيم العالمي يظهر فقط داخل الجروبات!');
    const boss = getGroupBoss(chatData);
    const now = Date.now();
    const elapsed = now - boss.lastSpawn;

    if (boss.isDead) {
      return sendCard(sock, m, `🐉 زعيم العالم`, [
        { type: 'warning', text: 'تمت إبادة الزعيم الحالي!' },
        { type: 'info', label: '⏳ الزعيم القادم بعد', value: msToTime(BOSS_RESPAWN_COOLDOWN - elapsed) }
      ], [{ text: '🔙 رجوع', id: usedPrefix }]);
    }

    const sub = (args[1] || '').trim();
    if (sub === 'قتال') {
      const activeElem = getEffectiveElement(kd);
      let myPower = getAttackPower(kd, true, false);
      if (chatData?.activeWorldEvent?.type === 'مطر_سم' && Date.now() < chatData.activeWorldEvent.expiresAt) {
        myPower = Math.floor(myPower / POISON_RAIN_ATK_DIVISOR);
      }
      const outaHero = kd.heroes.find(h => h.id === 'outa');
      const maroHero = kd.heroes.find(h => h.id === 'maro');
      if (outaHero) myPower *= 2.0;
      else if (maroHero) myPower *= 1.5;

      const mult = getElementMultiplier(activeElem, boss.element);
      const titleBonus = getTitleCombatBonus(kd, 'boss');
      const effectivePower = (myPower * mult) + titleBonus.flat;
      const winChance = Math.min(90, (effectivePower / boss.power) * 100);

      if (getRandomInt(1, 100) <= winChance) {
        boss.isDead = true;
        kd.gold += 4000000;
        kd.inventory['درع الحماية'] = (kd.inventory['درع الحماية'] || 0) + 3;
        if (outaHero) kd.books['كتاب_تطوير'] = (kd.books['كتاب_تطوير'] || 0) + 6;
        const slot = pick(EQUIPMENT_SLOTS);
        if (kd.equipment[slot] < 15) kd.equipment[slot] += 1;
        kd.leaderHearts[boss.element] = (kd.leaderHearts[boss.element] || 0) + 1;
        kd.bossKills = (kd.bossKills || 0) + 1;
        const newTitles = checkAndAwardTitles(kd);

        let elemMsg = null;
        if (kd.hasElementReset) {
          kd.element = boss.element;
          kd.elementLvl = 1;
          kd.isElementEvolved = false;
          kd.hasElementReset = false;
          elemMsg = { type: 'line', text: `🔮 سرقت عنصر الزعيم! عنصرك الجديد: ${kd.element}` };
        } else if (kd.elementLvl >= 15 && !kd.isElementEvolved && kd.element === boss.element) {
          kd.isElementEvolved = true;
          elemMsg = { type: 'line', text: `🌟 تطور عنصرك إلى (${ELEMENTS[kd.element]?.evolved})!` };
        }

        return sendCard(sock, m, `💥 هزمت الزعيم!`, [
          { type: 'info', label: '🏆 الجوائز', value: `4,000,000$ + 3 دروع + ترقية [${slot}]${outaHero ? ' + 6 كتب (أوتا)' : ''}` },
          { type: 'info', label: '❤️ قلب زعيم', value: `(${boss.element})` },
          ...(elemMsg ? [elemMsg] : []),
          ...(newTitles.length ? [{ type: 'line', text: `🏅 لقب جديد: ${newTitles.join('، ')}` }] : [])
        ], [{ text: '🔙 رجوع', id: usedPrefix }]);
      } else {
        const loss = Math.floor(kd.gold * 0.1);
        kd.gold -= loss;
        return sendCard(sock, m, `💀 سحقك الزعيم!`, [
          { type: 'warning', text: `فشلت وخسرت ${formatNumber(loss)}$` }
        ], [{ text: '🔄 حاول مجدداً', id: `${usedPrefix} زعيم قتال` }, { text: '🔙 رجوع', id: usedPrefix }]);
      }
    }

    const activeElem = getEffectiveElement(kd);
    return sendCard(sock, m, `🐉 زعيم العالم`, [
      { type: 'info', label: '👹 الزعيم', value: boss.name },
      { type: 'info', label: '🔮 عنصره', value: boss.element },
      { type: 'info', label: '⚔️ قوته', value: formatNumber(boss.power) },
      { type: 'info', label: '💥 قوتك الفعالة', value: formatNumber(getAttackPower(kd, true, false) * getElementMultiplier(activeElem, boss.element)) },
      { type: 'divider' },
      { type: 'info', label: '🎁 المكافأة', value: '4,000,000$ + 3 دروع + قطعة معدات + قلب زعيم' }
    ], [
      { text: '⚔️ هجوم على الزعيم', id: `${usedPrefix} زعيم قتال` },
      { text: '🔙 رجوع', id: usedPrefix }
    ]);
  }

  // ─── المعدات ───
  if (action === 'معدات') return showEquipment(sock, m, usedPrefix, kd);
  if (action === 'ترقية') {
    const slot = (args[1] || '').trim();
    if (!EQUIPMENT_SLOTS.includes(slot)) return m.reply('⚠️ اختر: خوذة، صدر، بنطلون، حذاء');
    const currentLvl = kd.equipment[slot] || 0;
    if (currentLvl >= 15) return m.reply('⚠️ القطعة بلغت الحد الأقصى (15)!');
    const cost = (currentLvl + 1) * 50000;
    if (kd.gold < cost) return m.reply(`⚠️ تكلفة الترقية للمستوى ${currentLvl + 1} هي ${formatNumber(cost)}$`);
    kd.gold -= cost;
    kd.equipment[slot] += 1;
    return showEquipment(sock, m, usedPrefix, kd);
  }

  // ─── العنصر ───
  if (action === 'عنصر') return showElementInfo(sock, m, usedPrefix, kd);
  if (action === 'تطوير_العنصر') {
    const activeElem = getEffectiveElement(kd);
    const max = ELEMENTS[activeElem]?.maxLvl || 15;
    if (kd.elementLvl >= max) {
      if (kd.elementLvl === 15 && !kd.isElementEvolved) return m.reply('⚠️ وصلت للمستوى 15! قاتل زعيم من نفس عنصرك لتطويره!');
      return m.reply('⚠️ العنصر بالمستوى الأقصى!');
    }
    const cost = kd.elementLvl * 100000;
    if (kd.gold < cost) return m.reply(`⚠️ تكلفة التطوير: ${formatNumber(cost)}$`);
    kd.gold -= cost;
    kd.elementLvl += 1;
    return showElementInfo(sock, m, usedPrefix, kd);
  }
  if (action === 'تأهيل') {
    if (kd.gold < ELEMENT_RESET_COST) return m.reply(`⚠️ تحتاج ${formatNumber(ELEMENT_RESET_COST)}$ لشراء عنصر تأهيل.`);
    kd.gold -= ELEMENT_RESET_COST;
    kd.hasElementReset = true;
    return m.reply('🧪 تم شراء عنصر التأهيل! اقتل أي زعيم لتستولي على عنصره فوراً!');
  }

  // ─── الدخل الدوري ───
  if (action === 'دخل') {
    const now = Date.now();
    const elapsed = now - kd.lastIncome;
    if (elapsed < INCOME_COOLDOWN) {
      return m.reply(`⏳ المملكة ما زالت تنتج! عد بعد: ${msToTime(INCOME_COOLDOWN - elapsed)}`);
    }
    const inc = calculateDailyIncomeBreakdown(kd, alliances);
    kd.gold += inc.total;
    kd.lastIncome = now;
    progressMission(kd, 'collectIncome', 1);
    return showMain(sock, m, usedPrefix, `💰 دخل ${kd.name}`, [
      { type: 'divider' },
      { type: 'info', label: 'أساسي', value: formatNumber(inc.baseIncome) },
      { type: 'info', label: 'بونص الخبرة', value: formatNumber(inc.expBonus) },
      { type: 'info', label: 'الإنتاج', value: formatNumber(inc.cowsIncome + inc.sheepIncome + inc.workersIncome + inc.minersIncome) },
      { type: 'info', label: 'العقارات', value: formatNumber(inc.landsIncome + inc.castlesIncome) },
      { type: 'info', label: 'الرابطة', value: formatNumber(inc.allianceIncome) },
      { type: 'divider' },
      { type: 'info', label: '💰 الإجمالي', value: formatNumber(inc.total) }
    ], kd);
  }

  // ─── التوب والبحث ───
  if (action === 'توب') {
    const all = (global.kdKnownJids || [])
      .map(j => ({ jid: j, u: getUser(j) }))
      .filter(x => x.u && x.u.kingdom)
      .map(x => ({ jid: x.jid, name: x.u.kingdom.name, value: kingdomValuation(x.u, x.u.kingdom) }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 10);
    const lines = all.map((p, i) => ({ type: 'line', text: `${i + 1}. ${p.name} (@${p.jid.split('@')[0]}) ⟞ ${formatNumber(p.value)}$` }));
    return sendCard(sock, m, `🏆 توب المملكة`, lines.length ? lines : [{ type: 'line', text: 'لا يوجد لاعبون بعد' }], [{ text: '🔙 رجوع', id: usedPrefix }]);
  }

  if (action === 'بحث') {
    const q = args.slice(1).join(' ').trim();
    if (!q) return m.reply(`⚠️ اكتب: ${usedPrefix} بحث [اسم المملكة]`);
    const matches = (global.kdKnownJids || [])
      .map(j => ({ jid: j, u: getUser(j) }))
      .filter(x => x.u && x.u.kingdom && x.u.kingdom.name && x.u.kingdom.name.includes(q))
      .map(x => ({ jid: x.jid, name: x.u.kingdom.name, value: kingdomValuation(x.u, x.u.kingdom) }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 10);
    const lines = matches.map((p, i) => ({ type: 'line', text: `${i + 1}. ${p.name} (@${p.jid.split('@')[0]}) ⟞ ${formatNumber(p.value)}$` }));
    return sendCard(sock, m, `🔍 نتائج البحث`, lines.length ? lines : [{ type: 'line', text: 'لا توجد نتائج مطابقة' }], [{ text: '🔙 رجوع', id: usedPrefix }]);
  }

  // ─── قتال الوحوش ───
  if (action === 'وحش') {
    const param = (args[1] || '').trim();
    let num = parseInt(param);
    let chosenElement = null;
    if (PRIMAL_ELEMENTS.includes(param) || STRONG_ELEMENTS.includes(param)) {
      chosenElement = param;
      num = Math.min(100, Math.max(1, Math.floor(kd.totalExp / 100) + 1));
    } else if (!num) {
      num = Math.min(100, Math.max(1, Math.floor(kd.totalExp / 100) + 1));
    }

    const now = Date.now();
    const elapsed = now - kd.lastHunt;
    if (elapsed < HUNT_COOLDOWN) return m.reply(`⏳ قواتك مجهدة! عد بعد: ${msToTime(HUNT_COOLDOWN - elapsed)}`);

    const weatherNow = isGroup && chatData ? ensureWeather(chatData) : null;
    const weatherBoost = weatherNow ? WEATHER_TYPES[weatherNow.type]?.boostElement : null;
    const monster = getMonster(num, chosenElement, weatherBoost);
    let baseAtk = getAttackPower(kd);
    if (chatData?.activeWorldEvent?.type === 'مطر_سم' && Date.now() < chatData.activeWorldEvent.expiresAt) {
      baseAtk = Math.floor(baseAtk / POISON_RAIN_ATK_DIVISOR);
    }
    const outaHero = kd.heroes.find(h => h.id === 'outa');
    const maroHero = kd.heroes.find(h => h.id === 'maro');
    if (outaHero) baseAtk *= 2.0;
    else if (maroHero) baseAtk *= 1.5;

    const activeElem = getEffectiveElement(kd);
    const mult = getElementMultiplier(activeElem, monster.element);
    const titleBonus = getTitleCombatBonus(kd, 'monster');
    const effectiveAtk = baseAtk * mult * titleBonus.mult;
    const winChance = Math.min(95, (effectiveAtk / (monster.power + 1)) * 50 + (getShieldCount(kd) > 0 ? 15 : 0));
    kd.lastHunt = now;

    if (getRandomInt(1, 100) <= winChance) {
      let resourceMult = 1;
      if (kd.activeBooks && kd.activeBooks.includes('كتاب_موارد')) resourceMult = 2;
      const gold = Math.floor(monster.gold * (1 + getRandomInt(10, 50) / 100)) * resourceMult;
      kd.gold += gold;
      kd.exp += monster.exp; kd.totalExp += monster.exp;
      if (getRandomInt(1, 100) <= 25) kd.scrollPieces = (kd.scrollPieces || 0) + 1;
      const droppedHeart = maybeDropHeart(kd, monster.level);
      const droppedScroll = maybeDropScroll(kd, monster.element);
      kd.monsterKills = (kd.monsterKills || 0) + 1;
      progressMission(kd, 'monsterKill', 1);
      const newTitles = checkAndAwardTitles(kd);

      if (kd.heroes && kd.heroes.length > 0) {
        kd.heroes.forEach(h => {
          h.exp = (h.exp || 0) + monster.exp;
          if (h.exp >= expNeededForLevel(h.level)) h.readyToUpgrade = true;
        });
      }
      const nextNeed = expNeededForLevel(kd.level);
      if (kd.exp >= nextNeed) { kd.exp -= nextNeed; kd.level++; }

      let advantageMsg = mult > 1.0 ? '⚡ أفضلية عنصرية' : (mult < 1.0 ? '⚠️ تفوق عنصر الوحش' : 'تكافؤ عنصري');
      let dropMsg = '';
      if (droppedHeart) dropMsg += `\n❤️ سقط قلب وحش (مستوى ${droppedHeart})`;
      if (droppedScroll) dropMsg += `\n📜 سقطت لفيفة عنصر (${droppedScroll})`;
      if (newTitles.length) dropMsg += `\n🏅 لقب جديد: ${newTitles.join('، ')}`;

      return showBattleMenu(sock, m, usedPrefix, kd, {
        type: 'info', label: `🏆 انتصرت على ${monster.name}`,
        value: `${advantageMsg}\n+${formatNumber(gold)}$ / +${monster.exp} خبرة${dropMsg}`
      });
    } else {
      const loss = Math.floor(kd.gold * 0.05);
      kd.gold -= loss;
      return showBattleMenu(sock, m, usedPrefix, kd, { type: 'warning', text: `💥 هزمك ${monster.name}! خسرت ${formatNumber(loss)}$` });
    }
  }

  // ─── التنانين ───
  if (action === 'تنين_قتال') {
    const dragon = user.pendingDragon;
    if (!dragon || Date.now() > dragon.expiresAt) {
      user.pendingDragon = null;
      return m.reply('⚠️ لا يوجد تنين بانتظارك الآن!');
    }
    let atk = getAttackPower(kd);
    for (const el of dragon.elements) atk *= getElementMultiplier(getEffectiveElement(kd), el);
    const winChance = Math.min(85, (atk / dragon.power) * 55);

    if (getRandomInt(1, 100) <= winChance) {
      const reward = dragonReward(dragon.power);
      kd.gold += reward;
      kd.dragonKills = (kd.dragonKills || 0) + 1;
      let dropMsg = '';
      for (const el of dragon.elements) {
        if (getRandomInt(1, 100) <= 40) {
          kd.scrolls[el] = (kd.scrolls[el] || 0) + 1;
          dropMsg += `\n📜 لفيفة عنصر (${el})`;
        }
      }
      const newTitles = checkAndAwardTitles(kd);
      if (newTitles.length) dropMsg += `\n🏅 لقب جديد: ${newTitles.join('، ')}`;
      user.pendingDragon = null;
      return showBattleMenu(sock, m, usedPrefix, kd, { type: 'info', label: '🐉 هزمت التنين!', value: `+${formatNumber(reward)}$${dropMsg}` });
    } else {
      const loss = Math.floor(kd.gold * 0.05);
      kd.gold -= loss;
      user.pendingDragon = null;
      return showBattleMenu(sock, m, usedPrefix, kd, { type: 'warning', text: `💀 هزمك التنين! خسرت ${formatNumber(loss)}$` });
    }
  }

  if (action === 'تنين_تجاهل') {
    user.pendingDragon = null;
    return showBattleMenu(sock, m, usedPrefix, kd, { type: 'line', text: '🏃 انسحبت بأمان من التنين.' });
  }

  // ─── الكهوف ───
  if (action === 'كهف' || action === 'كهوف') {
    const num = parseInt(args[1]);
    if (!num) return showBattleMenu(sock, m, usedPrefix, kd);

    const now = Date.now();
    const elapsed = now - kd.lastCave;
    if (elapsed < HUNT_COOLDOWN) return m.reply(`⏳ جيشك يتعافى! عد بعد: ${msToTime(HUNT_COOLDOWN - elapsed)}`);

    if (!user.pendingDragon && getRandomInt(1, 100) <= DRAGON_ENCOUNTER_CHANCE) {
      kd.lastCave = now;
      user.pendingDragon = spawnCaveDragon(num);
      return sendCard(sock, m, `🐲 اكتشاف تنين أثناء التنقيب!`, [
        { type: 'info', label: '🔮 عنصر التنين', value: user.pendingDragon.elements.join(' + ') },
        { type: 'info', label: '💪 قوة التنين', value: formatNumber(user.pendingDragon.power) },
        { type: 'line', text: 'هل تريد الهجوم أم الانسحاب؟' }
      ], [
        { text: '⚔️ هجوم على التنين', id: `${usedPrefix} تنين_قتال` },
        { text: '🏃 تجاهل والانسحاب', id: `${usedPrefix} تنين_تجاهل` }
      ]);
    }

    const cave = getCave(num);
    let atk = getAttackPower(kd);
    const outaHero = kd.heroes.find(h => h.id === 'outa');
    if (outaHero) atk *= 1.5;
    const winChance = Math.min(90, (atk / cave.power) * 45 + (getShieldCount(kd) > 0 ? 15 : 0));
    kd.lastCave = now;

    if (getRandomInt(1, 100) <= winChance) {
      let extraMult = 1;
      if (outaHero) extraMult = 1.8;
      if (kd.activeBooks && kd.activeBooks.includes('كتاب_موارد')) extraMult *= 2;
      const gold = Math.floor(cave.gold * (1 + getRandomInt(10, 40) / 100) * extraMult);
      const wood = Math.floor(cave.wood * extraMult);
      const stone = Math.floor(cave.stone * extraMult);
      kd.gold += gold;
      kd.exp += cave.exp; kd.totalExp += cave.exp;
      kd.wood += wood; kd.stone += stone;
      kd.currentCave = num;
      progressMission(kd, 'caveWin', 1);
      if (kd.heroes && kd.heroes.length > 0) {
        kd.heroes.forEach(h => {
          h.exp = (h.exp || 0) + cave.exp;
          if (h.exp >= expNeededForLevel(h.level)) h.readyToUpgrade = true;
        });
      }
      const nextNeed = expNeededForLevel(kd.level);
      if (kd.exp >= nextNeed) { kd.exp -= nextNeed; kd.level++; }
      return showBattleMenu(sock, m, usedPrefix, kd, {
        type: 'info', label: `🎉 طهّرت ${cave.name}`,
        value: `+${formatNumber(gold)}$ / +${cave.exp} خبرة / +${wood} خشب / +${stone} حجر`
      });
    } else {
      const loss = Math.floor(kd.gold * 0.03);
      kd.gold -= loss;
      return showBattleMenu(sock, m, usedPrefix, kd, { type: 'warning', text: `💀 فشلت بتطهير ${cave.name}! خسرت ${formatNumber(loss)}$` });
    }
  }

  // ─── الهجوم على لاعب (PvP) ───
  if (action === 'هجوم') {
    const targetJid = getMentionedJid(m) || getQuotedSender(m);
    if (!targetJid) return m.reply(`⚔️ اعمل منشن للاعب أو رد على رسالته واكتب:\n${usedPrefix} هجوم`);
    if (targetJid === getSenderId(m)) return m.reply('⚠️ لا يمكنك مهاجمة نفسك!');

    const targetUser = getUser(targetJid);
    if (!targetUser || !targetUser.kingdom) return m.reply('⚠️ هذا اللاعب ليس لديه مملكة بعد!');

    const targetKd = targetUser.kingdom;
    const now = Date.now();
    const lastHit = kd.lastAttackOnTarget[targetJid] || 0;
    if (now - lastHit < ATTACK_SAME_TARGET_COOLDOWN) {
      return m.reply(`⚠️ لا يمكنك مهاجمة نفس الهدف إلا بعد: ${msToTime(ATTACK_SAME_TARGET_COOLDOWN - (now - lastHit))}`);
    }
    kd.attackTimestamps = kd.attackTimestamps.filter(t => now - t < 60 * 60 * 1000);
    const maxAtk = maxAttacksPerHour(kd.level);
    if (kd.attackTimestamps.length >= maxAtk) return m.reply(`⚠️ استنفذت هجماتك لهذه الساعة (${maxAtk})`);

    let myBaseAtk = getAttackPower(kd, false, true);
    let targetBaseAtk = getAttackPower(targetKd, false, true);
    const outaHero = kd.heroes.find(h => h.id === 'outa');
    const maroHero = kd.heroes.find(h => h.id === 'maro');
    if (outaHero) myBaseAtk *= 0.5;
    else if (maroHero) myBaseAtk *= 1.5;

    const myPower = myBaseAtk * getElementMultiplier(getEffectiveElement(kd), getEffectiveElement(targetKd));
    const targetPower = targetBaseAtk * getElementMultiplier(getEffectiveElement(targetKd), getEffectiveElement(kd));
    const winChance = (myPower / (myPower + targetPower + 1)) * 100;
    kd.attackTimestamps.push(now);
    kd.lastAttackOnTarget[targetJid] = now;
    progressMission(kd, 'pvpAttack', 1);
    kd.pvpAttacksCount = (kd.pvpAttacksCount || 0) + 1;
    const newPvpTitles = checkAndAwardTitles(kd);

    if (getRandomInt(1, 100) <= winChance) {
      const levelBonus = getAttackLevelBonus(kd.level);
      const reward = Math.max(ATTACK_MIN_REWARD, Math.floor(targetPower * 0.4)) + levelBonus;
      const deduction = targetKd.gold > ATTACK_PROTECTED_FLOOR ? Math.min(reward, targetKd.gold - ATTACK_PROTECTED_FLOOR) : 0;
      if (deduction > 0) targetKd.gold -= deduction;
      kd.gold += reward;
      const expBonus = Math.floor(targetPower * 0.02);
      kd.exp += expBonus; kd.totalExp += expBonus;
      return sendCard(sock, m, `⚔️ هجوم ناجح!`, [
        { type: 'info', label: '🏆 المكافأة', value: `${formatNumber(reward)}$` },
        { type: 'info', label: '💸 خسارة الخصم', value: deduction > 0 ? formatNumber(deduction) : 'محمي (رصيد قليل)' },
        ...(newPvpTitles.length ? [{ type: 'line', text: `🏅 لقب جديد: ${newPvpTitles.join('، ')}` }] : [])
      ], [{ text: '🔙 رجوع', id: usedPrefix }]);
    } else {
      const loss = Math.floor(kd.gold * 0.05);
      kd.gold -= loss;
      return sendCard(sock, m, `💥 تم صد هجومك!`, [
        { type: 'warning', text: `فشل هجومك وخسرت ${formatNumber(loss)}$` }
      ], [{ text: '🔙 رجوع', id: usedPrefix }]);
    }
  }

  // ─── الطقس ───
  if (action === 'طقس') {
    if (!isGroup || !chatData) return m.reply('⚠️ هذا الأمر متاح فقط داخل الجروبات!');
    const w = ensureWeather(chatData);
    const info = WEATHER_TYPES[w.type];
    const remaining = WEATHER_CYCLE - (Date.now() - w.changedAt);
    return sendCard(sock, m, `${info.emoji} الطقس الحالي`, [
      { type: 'info', label: 'الحالة', value: info.label },
      { type: 'info', label: 'العنصر المدعوم', value: info.boostElement },
      { type: 'info', label: '⏳ يتغير خلال', value: msToTime(remaining) }
    ], [{ text: '🔙 رجوع', id: usedPrefix }]);
  }

  // ─── أحداث العالم ───
  if (action === 'تصدي_للتنين') {
    if (!isGroup || !chatData || !chatData.activeWorldEvent || chatData.activeWorldEvent.type !== 'تنين_عالمي') {
      return m.reply('⚠️ لا يوجد حدث تنين عالمي نشط الآن!');
    }
    const ev = chatData.activeWorldEvent;
    if (Date.now() > ev.expiresAt) return m.reply('⚠️ انتهت مهلة التصدي!');
    if (!ev.responders.includes(getSenderId(m))) {
      ev.responders.push(getSenderId(m));
      ev.totalPower += getAttackPower(kd);
    }
    return m.reply(`🛡️ انضممت للدفاع!\nالقوة المجمّعة: ${formatNumber(ev.totalPower)}\nقوة التنين: ${formatNumber(ev.power)}`);
  }

  if (action === 'جمع') {
    if (!isGroup || !chatData || !chatData.activeWorldEvent || chatData.activeWorldEvent.type !== 'مطر_ذهب') {
      return m.reply('⚠️ لا يوجد مطر ذهب نشط الآن!');
    }
    const ev = chatData.activeWorldEvent;
    if (Date.now() > ev.expiresAt) return m.reply('⚠️ انتهى مطر الذهب!');
    if (ev.claimed.includes(getSenderId(m))) return m.reply('⚠️ جمعت نصيبك بالفعل!');
    ev.claimed.push(getSenderId(m));
    kd.gold += GOLD_RAIN_AMOUNT;
    return m.reply(`🌟 جمعت الذهب المتساقط! +${formatNumber(GOLD_RAIN_AMOUNT)}$`);
  }

  // ─── الصيد ───
  if (action === 'صيد') {
    const spotKey = (args[1] || '').trim();
    if (!spotKey || !FISHING_SPOTS[spotKey]) {
      const buttons = Object.entries(FISHING_SPOTS).map(([key, spot]) => ({ text: spot.label, id: `${usedPrefix} صيد ${key}` }));
      return sendCard(sock, m, `🎣 أماكن الصيد`, [
        { type: 'line', text: 'اختر مكان الصيد:' },
        { type: 'divider' },
        { type: 'info', label: '🎣 بحيرة عادية', value: 'سمك عادي/فضي/ذهبي — قوة 100k+' },
        { type: 'info', label: '🌑 نهر الظلام', value: 'ثعبان ماء/سمك شبح/وحش النهر — قوة 200k+' },
        { type: 'info', label: '🌊 بحر الأحلام', value: 'لؤلؤ/مرجان/حورية بحر — قوة 600k+' }
      ], [...buttons, { text: '🔙 رجوع', id: usedPrefix }]);
    }

    const now = Date.now();
    const elapsed = now - kd.lastFish;
    if (elapsed < FISH_COOLDOWN) return m.reply(`⏳ الصيادون متعبون! عد بعد: ${msToTime(FISH_COOLDOWN - elapsed)}`);

    const spot = FISHING_SPOTS[spotKey];
    const atk = getAttackPower(kd);
    let eligible = spot.catches.filter(c => atk >= c.reqPower);
    eligible = eligible.filter(c => {
      if (!c.isMermaid) return true;
      if (!isGroup || !chatData) return false;
      if (!chatData.mermaid || chatData.mermaid.dead === false) return true;
      return (now - chatData.mermaid.diedAt) >= MERMAID_RESPAWN;
    });

    if (!eligible.length) {
      const minReq = Math.min(...spot.catches.map(c => c.reqPower));
      kd.lastFish = now;
      return m.reply(`💧 القوة غير كافية! تحتاج قوة ${formatNumber(minReq)} فما فوق لهذا المكان!`);
    }

    kd.lastFish = now;
    const target = pickWeightedCatch(eligible);

    if (target.isMermaid) {
      const activeElem = getEffectiveElement(kd);
      const immune = MERMAID_IMMUNE_ELEMENTS.includes(activeElem);
      const mult = immune ? 1.0 : getElementMultiplier(activeElem, 'ماء');
      const effectiveAtk = atk * mult;
      const winChance = Math.min(85, (effectiveAtk / MERMAID_POWER) * 55);

      if (getRandomInt(1, 100) <= winChance) {
        kd.gold += 100000;
        kd.fishCount = (kd.fishCount || 0) + 1;
        let dropMsg = '';
        if (getRandomInt(1, 100) <= 30) {
          kd.scrolls['ماء'] = (kd.scrolls['ماء'] || 0) + 1;
          dropMsg += '\n📜 لفيفة عنصر (ماء)';
        }
        if (getRandomInt(1, 100) <= 15) {
          kd.mermaidScales = (kd.mermaidScales || 0) + 1;
          dropMsg += '\n✨ حرشفة حورية بحر!';
        }
        if (isGroup && chatData) chatData.mermaid = { dead: true, diedAt: now };
        const newTitles = checkAndAwardTitles(kd);
        if (newTitles.length) dropMsg += `\n🏅 لقب جديد: ${newTitles.join('، ')}`;
        return m.reply(`🧜‍♀️ هزمت حورية البحر! +100,000$${dropMsg}`);
      } else {
        return m.reply('🌊 هربت منك حورية البحر! حاول لاحقاً.');
      }
    }

    const weight = rollFishWeight();
    const earned = weight * target.pricePerKg;
    kd.gold += earned;
    kd.fishCount = (kd.fishCount || 0) + 1;
    const newTitles = checkAndAwardTitles(kd);
    return sendCard(sock, m, `🎣 اصطدت ${target.name}!`, [
      { type: 'info', label: '⚖️ الوزن', value: `${weight} كيلو` },
      { type: 'info', label: '💰 القيمة', value: `${formatNumber(earned)}$` },
      ...(newTitles.length ? [{ type: 'line', text: `🏅 لقب جديد: ${newTitles.join('، ')}` }] : [])
    ], [{ text: '🎣 صيد مجدداً', id: `${usedPrefix} صيد ${spotKey}` }, { text: '🔙 رجوع', id: usedPrefix }]);
  }

  // ─── القوافل ───
  if (action === 'قافلة') {
    const region = (args[1] || '').trim();
    if (!region || !CARAVAN_REGIONS[region]) {
      const buttons = Object.entries(CARAVAN_REGIONS).map(([key, r]) => ({ text: r.label, id: `${usedPrefix} قافلة ${key}` }));
      return sendCard(sock, m, `🐫 قوافل الموارد`, [
        { type: 'line', text: `اختر المنطقة: ${usedPrefix} قافلة [المنطقة] [القوة المرسلة]` },
        { type: 'divider' },
        ...Object.values(CARAVAN_REGIONS).map(r => ({ type: 'info', label: r.label, value: `مورد: ${r.resourceName}` }))
      ], [...buttons, { text: '🔙 رجوع', id: usedPrefix }]);
    }
    if (kd.caravan && kd.caravan.active) {
      if (Date.now() > kd.caravan.returnAt) {
        kd.caravan.active = false;
      } else {
        return m.reply(`⚠️ لديك قافلة بالفعل في الطريق! تعود خلال ${msToTime(Math.max(0, kd.caravan.returnAt - Date.now()))}`);
      }
    }
    const troops = parseInt(args[2]);
    const myAtk = getAttackPower(kd);
    if (!troops || troops < 1000 || troops > myAtk) {
      return m.reply(`⚠️ حدد قوة صحيحة (1000 وحتى ${formatNumber(myAtk)})\nمثال: ${usedPrefix} قافلة ${region} 10000`);
    }

    const now = Date.now();
    const senderJid = getSenderId(m);
    kd.caravan = { active: true, troops, region, sentAt: now, returnAt: now + CARAVAN_DURATION };

    setTimeout(async () => {
      try {
        const freshUser = getUser(senderJid);
        if (!freshUser || !freshUser.kingdom) return;
        const freshKd = freshUser.kingdom;
        const regionDef = CARAVAN_REGIONS[region];

        let dragonMet = getRandomInt(1, 100) <= CARAVAN_DRAGON_CHANCE;
        let monsterMet = !dragonMet && getRandomInt(1, 100) <= CARAVAN_MONSTER_CHANCE;
        let success = true;
        let extraMsg = '';

        if (dragonMet) {
          const dragonPower = getRandomInt(2000000, 20000000);
          const winChance = Math.min(70, (troops / dragonPower) * 40);
          success = getRandomInt(1, 100) <= winChance;
          extraMsg = success ? '\n🐉 صدّت القافلة تنيناً ونجت!' : '\n🐉 دمّر تنين القافلة!';
        } else if (monsterMet) {
          const monsterLevel = getRandomInt(1, 40);
          const monsterPower = getMonsterPower(monsterLevel);
          const winChance = Math.min(85, (troops / monsterPower) * 60);
          success = getRandomInt(1, 100) <= winChance;
          extraMsg = success ? `\n⚔️ هزمت القافلة وحشاً (مستوى ${monsterLevel})!` : `\n⚔️ هُزمت القافلة أمام وحش (مستوى ${monsterLevel})!`;
        }

        freshKd.caravan.active = false;

        if (success) {
          const amount = Math.floor(troops * regionDef.ratio);
          freshKd[regionDef.resourceField] = (freshKd[regionDef.resourceField] || 0) + amount;
          freshKd.caravanSuccessCount = (freshKd.caravanSuccessCount || 0) + 1;
          const bonusWeapon = getRandomInt(1, 100) <= 20;
          if (bonusWeapon) freshKd.inventory['سيف عادي'] = (freshKd.inventory['سيف عادي'] || 0) + 1;
          const newTitles = checkAndAwardTitles(freshKd);
          await sock.sendMessage(m.chat, { text: buildBody(`🐫 عادت قافلة ${freshKd.name}!`, [
            { type: 'info', label: '🎉 النتيجة', value: `نجحت!${extraMsg}` },
            { type: 'info', label: `📦 ${regionDef.resourceName}`, value: `+${formatNumber(amount)}` },
            ...(bonusWeapon ? [{ type: 'line', text: '🗡️ عثرت القافلة على سلاح!' }] : []),
            ...(newTitles.length ? [{ type: 'line', text: `🏅 لقب جديد: ${newTitles.join('، ')}` }] : [])
          ]) });
        } else {
          await sock.sendMessage(m.chat, { text: buildBody(`💀 فشلت قافلة ${freshKd.name}!`, [
            { type: 'warning', text: `تدمير كامل!${extraMsg}` }
          ]) });
        }
        if (typeof scheduleSave === 'function') scheduleSave();
      } catch (e) {}
    }, CARAVAN_DURATION);

    return m.reply(`🐫 تم إرسال القافلة!\n⏳ النتيجة خلال ${msToTime(CARAVAN_DURATION)}`);
  }

  // ─── القتال الجماعي ───
  if (action === 'قتال_جماعي') {
    const sub = (args[1] || '').trim();
    if (sub === '3' || sub === '5') {
      if (!isGroup || !chatData) return m.reply('⚠️ هذا الأمر متاح فقط داخل الجروبات!');
      if (chatData.teamBattle) return m.reply('⚠️ يوجد قتال جماعي قائم بالفعل!');
      const size = parseInt(sub);
      chatData.teamBattle = { size, teamA: [getSenderId(m)], teamB: [], startedBy: getSenderId(m), startedAt: Date.now() };
      return sendCard(sock, m, `⚔️ قتال جماعي ${size} ضد ${size}`, [
        { type: 'line', text: `انضم لفريق حتى يكتمل العدد (${size} لكل فريق)` },
        { type: 'info', label: '🅰️ فريق أ', value: `1/${size}` },
        { type: 'info', label: '🅱️ فريق ب', value: `0/${size}` }
      ], [
        { text: '🅰️ انضم لفريق أ', id: `${usedPrefix} فريق_أ` },
        { text: '🅱️ انضم لفريق ب', id: `${usedPrefix} فريق_ب` },
        { text: '❌ إلغاء', id: `${usedPrefix} الغاء_القتال_الجماعي` }
      ]);
    }
    return m.reply(`⚠️ اكتب: ${usedPrefix} قتال_جماعي 3 أو ${usedPrefix} قتال_جماعي 5`);
  }

  if (action === 'الغاء_القتال_الجماعي') {
    if (!isGroup || !chatData || !chatData.teamBattle) return m.reply('⚠️ لا يوجد قتال جماعي قائم!');
    if (chatData.teamBattle.startedBy !== getSenderId(m) && !isBotOwner(m)) return m.reply('⚠️ فقط من بدأ القتال يمكنه إلغاءه!');
    chatData.teamBattle = null;
    return m.reply('❌ تم إلغاء القتال الجماعي');
  }

  if (action === 'فريق_أ' || action === 'فريق_ب') {
    if (!isGroup || !chatData || !chatData.teamBattle) return m.reply(`⚠️ لا يوجد قتال جماعي! ابدأ: ${usedPrefix} قتال_جماعي 3`);
    const tb = chatData.teamBattle;
    const myJid = getSenderId(m);
    if (tb.teamA.includes(myJid) || tb.teamB.includes(myJid)) return m.reply('⚠️ أنت منضم بالفعل لفريق!');
    const team = action === 'فريق_أ' ? tb.teamA : tb.teamB;
    if (team.length >= tb.size) return m.reply('⚠️ هذا الفريق مكتمل!');
    team.push(myJid);

    if (tb.teamA.length >= tb.size && tb.teamB.length >= tb.size) {
      const powerOf = jid => {
        const u = getUser(jid);
        return u && u.kingdom ? getAttackPower(u.kingdom) : 0;
      };
      const powerA = tb.teamA.reduce((s, j) => s + powerOf(j), 0);
      const powerB = tb.teamB.reduce((s, j) => s + powerOf(j), 0);
      const aWinChance = (powerA / (powerA + powerB + 1)) * 100;
      const aWins = getRandomInt(1, 100) <= aWinChance;
      const winners = aWins ? tb.teamA : tb.teamB;
      const losers = aWins ? tb.teamB : tb.teamA;
      const lossEach = Math.floor(TEAM_BATTLE_LOSS_TOTAL / losers.length);

      for (const jid of winners) {
        const u = getUser(jid);
        if (u && u.kingdom) u.kingdom.gold += TEAM_BATTLE_WIN_REWARD;
      }
      for (const jid of losers) {
        const u = getUser(jid);
        if (u && u.kingdom) u.kingdom.gold = Math.max(0, u.kingdom.gold - lossEach);
      }
      chatData.teamBattle = null;
      return sendCard(sock, m, `🏆 انتهى القتال الجماعي!`, [
        { type: 'info', label: 'الفريق الفائز', value: aWins ? '🅰️ فريق أ' : '🅱️ فريق ب' },
        { type: 'info', label: '💪 قوة أ', value: formatNumber(powerA) },
        { type: 'info', label: '💪 قوة ب', value: formatNumber(powerB) },
        { type: 'info', label: '🎉 مكافأة الفائز', value: `+${formatNumber(TEAM_BATTLE_WIN_REWARD)}$` },
        { type: 'info', label: '💸 خسارة الخاسر', value: `-${formatNumber(lossEach)}$` }
      ], [{ text: '🔙 رجوع', id: usedPrefix }]);
    }

    return sendCard(sock, m, `⚔️ قتال جماعي ${tb.size} ضد ${tb.size}`, [
      { type: 'info', label: '🅰️ فريق أ', value: `${tb.teamA.length}/${tb.size}` },
      { type: 'info', label: '🅱️ فريق ب', value: `${tb.teamB.length}/${tb.size}` }
    ], [
      { text: '🅰️ انضم لفريق أ', id: `${usedPrefix} فريق_أ` },
      { text: '🅱️ انضم لفريق ب', id: `${usedPrefix} فريق_ب` },
      { text: '❌ إلغاء', id: `${usedPrefix} الغاء_القتال_الجماعي` }
    ]);
  }

  // ─── متجر اللاعب ───
  if (action === 'فتح_متجري') {
    if (kd.shop.open) return m.reply('⚠️ متجرك مفتوح بالفعل!');
    if (kd.gold < PLAYER_SHOP_COST) return m.reply(`⚠️ فتح المتجر يتطلب ${formatNumber(PLAYER_SHOP_COST)}$`);
    kd.gold -= PLAYER_SHOP_COST;
    kd.shop.open = true;
    return m.reply('🏪 تم فتح متجرك الخاص!');
  }

  if (action === 'اضافة_للمتجر') {
    if (!kd.shop.open) return m.reply(`⚠️ افتح متجرك أولاً: ${usedPrefix} فتح_متجري`);
    const price = parseInt(args[args.length - 1]);
    const itemName = args.slice(1, -1).join(' ').trim();
    if (!itemName || !price || price <= 0) return m.reply(`⚠️ اكتب: ${usedPrefix} اضافة_للمتجر [اسم الصنف] [السعر]`);
    if (isForbiddenShopItem(itemName)) return m.reply('⚠️ لا يمكن بيع الأبطال أو العناصر أو الكتب أو القلوب أو اللفائف!');
    if (!kd.inventory[itemName] || kd.inventory[itemName] < 1) return m.reply('⚠️ لا تملك هذا الصنف!');
    kd.inventory[itemName] -= 1;
    kd.shop.items.push({ name: itemName, price, sellerJid: getSenderId(m) });
    return m.reply('✅ تمت إضافة الصنف لمتجرك!');
  }

  if (action === 'متجري' || action === 'متجر_اللاعب') {
    const targetJid = action === 'متجري'
      ? (getMentionedJid(m) || getQuotedSender(m) || getSenderId(m))
      : (getMentionedJid(m) || getQuotedSender(m));
    if (!targetJid) return m.reply('⚠️ منشن الشخص صاحب المتجر!');
    const targetUser = getUser(targetJid);
    const targetKd = targetUser?.kingdom;
    if (!targetKd || !targetKd.shop.open) return m.reply('⚠️ لا يوجد متجر مفتوح لهذا اللاعب!');
    const lines = targetKd.shop.items.map((it, i) => ({ type: 'line', text: `${i + 1}. ${it.name} — ${formatNumber(it.price)}$` }));
    return sendCard(sock, m, `🏪 متجر ${targetKd.name}`, lines.length ? lines : [{ type: 'line', text: 'المتجر فارغ' }], [
      { text: '🔙 رجوع', id: usedPrefix }
    ]);
  }

  if (action === 'شراء_من') {
    const targetJid = getMentionedJid(m) || getQuotedSender(m);
    const itemName = args.slice(1).join(' ').trim();
    if (!targetJid || !itemName) return m.reply(`⚠️ اكتب: ${usedPrefix} شراء_من [منشن البائع] [اسم الصنف]`);
    const sellerUser = getUser(targetJid);
    const sellerKd = sellerUser?.kingdom;
    if (!sellerKd || !sellerKd.shop.open) return m.reply('⚠️ لا يوجد متجر مفتوح!');
    const itemIdx = sellerKd.shop.items.findIndex(it => it.name === itemName);
    if (itemIdx === -1) return m.reply('⚠️ الصنف غير موجود!');
    const item = sellerKd.shop.items[itemIdx];
    if (kd.gold < item.price) return m.reply(`⚠️ تحتاج ${formatNumber(item.price)}$!`);
    kd.gold -= item.price;
    sellerKd.gold += item.price;
    kd.inventory[item.name] = (kd.inventory[item.name] || 0) + 1;
    sellerKd.shop.items.splice(itemIdx, 1);
    return m.reply(`✅ تم الشراء! ${item.name} — ${formatNumber(item.price)}$`);
  }

  // ─── البنك والحظ ───
  if (action === 'بنك') return showBank(sock, m, usedPrefix, kd);

  if (action === 'ايداع') {
    const val = args[1];
    if (val === 'الكل') { kd.vault += kd.gold; kd.gold = 0; }
    else {
      const amt = parseInt(val);
      if (!amt || amt <= 0 || kd.gold < amt) return m.reply('⚠️ مبلغ غير صالح!');
      kd.gold -= amt; kd.vault += amt;
    }
    return showBank(sock, m, usedPrefix, kd);
  }

  if (action === 'سحب') {
    const val = args[1];
    if (val === 'الكل') { kd.gold += kd.vault; kd.vault = 0; }
    else {
      const amt = parseInt(val);
      if (!amt || amt <= 0 || kd.vault < amt) return m.reply('⚠️ مبلغ غير صالح أو رصيد غير كافٍ!');
      kd.vault -= amt; kd.gold += amt;
    }
    return showBank(sock, m, usedPrefix, kd);
  }

  if (action === 'حظ') {
    const val = args[1];
    if (!val) return showGamble(sock, m, usedPrefix, kd);
    let bet = val === 'الكل' ? kd.vault : parseInt(val);
    if (!bet || bet <= 0 || kd.vault < bet) return showGamble(sock, m, usedPrefix, kd, { type: 'warning', text: 'الرهان يجب أن يكون من رصيد بنكك!' });
    if (getRandomInt(1, 100) <= 48) {
      kd.vault += bet;
      return showGamble(sock, m, usedPrefix, kd, { type: 'info', label: '🎉 فزت!', value: `+${formatNumber(bet)}$ لبنكك` });
    } else {
      kd.vault -= bet;
      return showGamble(sock, m, usedPrefix, kd, { type: 'warning', text: `💥 خسرت! -${formatNumber(bet)}$` });
    }
  }

  // ─── المتجر ───
  if (action === 'متجر') {
    const sub = (args[1] || '').trim();
    if (sub === 'اسلحة') return showShopCategory(sock, m, usedPrefix, kd, 'اسلحة');
    if (sub === 'تعاويذ') return showShopCategory(sock, m, usedPrefix, kd, 'تعاويذ');
    if (sub === 'كتب') return showShopCategory(sock, m, usedPrefix, kd, 'كتب');
    if (sub === 'انتاج') return showShopCategory(sock, m, usedPrefix, kd, 'انتاج');
    if (sub === 'موارد') return showResourcesShop(sock, m, usedPrefix, kd);
    return showShop(sock, m, usedPrefix, kd);
  }

  if (action === 'مخزن') return showInventory(sock, m, usedPrefix, kd);

  if (action === 'شراء') {
    const name = args[1];
    const qty = Math.max(1, parseInt(args[2]) || 1);
    if (!name) return showShop(sock, m, usedPrefix, kd);

    if (SHOP_ITEMS[name]) {
      const cost = SHOP_ITEMS[name].price * qty;
      if (kd.gold < cost) return showShop(sock, m, usedPrefix, kd, { type: 'warning', text: `تكلفة ${qty} من ${name} هي ${formatNumber(cost)}$` });
      kd.gold -= cost;
      kd.inventory[name] = (kd.inventory[name] || 0) + qty;
      return showShop(sock, m, usedPrefix, kd, { type: 'info', label: '🛒 شراء ناجح', value: `اشتريت ${qty} × ${name}` });
    }
    if (BOOKS[name]) {
      const cost = BOOKS[name].price * qty;
      if (kd.gold < cost) return showShopCategory(sock, m, usedPrefix, kd, 'كتب', { type: 'warning', text: `تكلفة ${formatNumber(cost)}$` });
      kd.gold -= cost;
      kd.books[name] = (kd.books[name] || 0) + qty;
      return showShopCategory(sock, m, usedPrefix, kd, 'كتب', { type: 'info', label: '🛒 شراء ناجح', value: `اشتريت ${qty} × ${name}` });
    }
    if (PRODUCTION_ITEMS[name]) {
      const item = PRODUCTION_ITEMS[name];
      const cost = item.price * qty;
      if (kd.gold < cost) return showShopCategory(sock, m, usedPrefix, kd, 'انتاج', { type: 'warning', text: `تكلفة ${formatNumber(cost)}$` });
      kd.gold -= cost;
      kd.production[item.key] = (kd.production[item.key] || 0) + qty;
      return showShopCategory(sock, m, usedPrefix, kd, 'انتاج', { type: 'info', label: '🛒 شراء ناجح', value: `اشتريت ${qty} × ${name}` });
    }
    if (RESOURCE_ITEMS[name]) {
      const item = RESOURCE_ITEMS[name];
      const cost = item.price * qty;
      if (kd.gold < cost) return showResourcesShop(sock, m, usedPrefix, kd, { type: 'warning', text: `تكلفة ${formatNumber(cost)}$` });
      kd.gold -= cost;
      kd[item.key] = (kd[item.key] || 0) + (item.amount * qty);
      return showResourcesShop(sock, m, usedPrefix, kd, { type: 'info', label: '🛒 شراء ناجح', value: `اشتريت ${qty * item.amount} من ${name}` });
    }
    if (name === 'جندي') {
      const cost = SOLDIER_ITEM.price * qty;
      if (kd.gold < cost) return showResourcesShop(sock, m, usedPrefix, kd, { type: 'warning', text: `تكلفة ${formatNumber(cost)}$` });
      kd.gold -= cost;
      kd.soldiers = (kd.soldiers || 0) + qty;
      return showResourcesShop(sock, m, usedPrefix, kd, { type: 'info', label: '⚔️ تجنيد ناجح', value: `جنّدت ${qty} جندي` });
    }
    return showShop(sock, m, usedPrefix, kd, { type: 'warning', text: 'العنصر غير موجود في المتجر!' });
  }

  // ─── التحالفات ───
  if (action === 'تحالف') {
    const sub = (args[1] || '').trim();

    if (sub === 'انشاء') {
      const allianceName = args.slice(2).join(' ').trim();
      if (!allianceName) return showAlliance(sock, m, usedPrefix, kd, alliances, { type: 'warning', text: `اكتب الاسم: ${usedPrefix} تحالف انشاء [الاسم]` });
      if (kd.allianceId) return showAlliance(sock, m, usedPrefix, kd, alliances, { type: 'warning', text: 'اغادر تحالفك الحالي أولاً!' });
      if (kd.gold < ALLIANCE_CREATE_COST) return showAlliance(sock, m, usedPrefix, kd, alliances, { type: 'warning', text: `التأسيس يتطلب ${formatNumber(ALLIANCE_CREATE_COST)}$` });
      kd.gold -= ALLIANCE_CREATE_COST;
      const allianceId = `ally_${Date.now()}_${getSenderId(m).split('@')[0]}`;
      alliances[allianceId] = {
        id: allianceId, name: allianceName,
        leader: getSenderId(m), members: [getSenderId(m)],
        power: getAttackPower(kd)
      };
      kd.allianceId = allianceId;
      return showAlliance(sock, m, usedPrefix, kd, alliances, { type: 'info', label: '🎉 مبروك!', value: `تم تأسيس [${allianceName}]` });
    }

    if (sub === 'دعوة') {
      const targetJid = getMentionedJid(m) || getQuotedSender(m);
      if (!targetJid) return showAlliance(sock, m, usedPrefix, kd, alliances, { type: 'warning', text: 'اعمل منشن للاعب!' });
      if (!kd.allianceId) return showAlliance(sock, m, usedPrefix, kd, alliances, { type: 'warning', text: 'لست في تحالف!' });
      const ally = alliances[kd.allianceId];
      if (ally.leader !== getSenderId(m)) return showAlliance(sock, m, usedPrefix, kd, alliances, { type: 'warning', text: 'فقط القائد يدعو!' });
      const targetUser = getUser(targetJid);
      if (!targetUser || !targetUser.kingdom) return showAlliance(sock, m, usedPrefix, kd, alliances, { type: 'warning', text: 'اللاعب لا يملك مملكة!' });
      if (targetUser.kingdom.allianceId) return showAlliance(sock, m, usedPrefix, kd, alliances, { type: 'warning', text: 'اللاعب في تحالف آخر!' });
      targetUser.kingdom.pendingInvite = kd.allianceId;
      return showAlliance(sock, m, usedPrefix, kd, alliances, { type: 'info', label: '✉️ أُرسلت الدعوة', value: `إلى @${targetJid.split('@')[0]}` });
    }

    if (sub === 'قبول') {
      if (!kd.pendingInvite || !alliances[kd.pendingInvite]) return showAlliance(sock, m, usedPrefix, kd, alliances, { type: 'warning', text: 'لا تملك دعوات معلقة!' });
      const ally = alliances[kd.pendingInvite];
      ally.members.push(getSenderId(m));
      kd.allianceId = kd.pendingInvite;
      kd.pendingInvite = null;
      return showAlliance(sock, m, usedPrefix, kd, alliances, { type: 'info', label: '🤝 تم الانضمام', value: `إلى [${ally.name}]` });
    }

    if (sub === 'مغادرة') {
      if (!kd.allianceId || !alliances[kd.allianceId]) return showAlliance(sock, m, usedPrefix, kd, alliances, { type: 'warning', text: 'لست في أي تحالف!' });
      const ally = alliances[kd.allianceId];
      ally.members = ally.members.filter(j => j !== getSenderId(m));
      if (ally.members.length === 0) delete alliances[kd.allianceId];
      else if (ally.leader === getSenderId(m)) ally.leader = ally.members[0];
      kd.allianceId = null;
      return showAlliance(sock, m, usedPrefix, kd, alliances, { type: 'info', label: '🚪 مغادرة', value: `غادرت [${ally.name}]` });
    }

    return showAlliance(sock, m, usedPrefix, kd, alliances);
  }

  // ─── تغيير الاسم ───
  if (action === 'اسم' || action === 'تغيير_الاسم') {
    const newName = args.slice(1).join(' ').trim();
    if (!newName) return m.reply(`⚠️ أدخل الاسم: ${usedPrefix} اسم [الاسم الجديد]`);
    if (kd.gold < NAME_CHANGE_COST) return m.reply(`⚠️ التغيير يتطلب ${formatNumber(NAME_CHANGE_COST)}$`);
    kd.gold -= NAME_CHANGE_COST;
    kd.name = newName;
    return showMain(sock, m, usedPrefix, `🏰 تم تغيير الاسم`, [{ type: 'info', label: 'الاسم الجديد', value: newName }], kd);
  }

  // ─── أدواتك الخاصة ───
  if (action === 'أدوات') return showToolsMenu(sock, m, usedPrefix, kd);

  if (action === 'ترقية_أداة') {
    const toolName = (args[1] || '').trim();
    if (!kd.tools[toolName]) return m.reply('⚠️ أداة غير صالحة.');
    const tool = kd.tools[toolName];
    if (tool.level >= 15) return m.reply('⚠️ الأداة بالحد الأقصى (15)!');
    const cost = tool.level * 30000;
    if (kd.gold < cost) return m.reply(`⚠️ تحتاج ${formatNumber(cost)}$ لترقية ${toolName}`);
    kd.gold -= cost;
    tool.level += 1;
    return showToolsMenu(sock, m, usedPrefix, kd, { type: 'info', label: '🎉 تم التطوير!', value: `${toolName} أصبح Lvl ${tool.level}` });
  }

  // ─── افتراضي ───
  return showMain(sock, m, usedPrefix, `🏰 تقرير حالة ${kd.name}`, [], kd);
}

// ==================== تصدير الأمر ====================
export default {
  command: ['مملكة', 'kingdom', 'kd'],
  category: 'اقتصاد',
  description: 'نظام المملكة الشامل: الأبطال الـ50، العناصر، الزعماء، PvP، الصيد، القوافل، التحالفات، والأحداث العالمية',
  execute: async (sock, m, context = {}) => {
    const prefix = context.prefix || '.';
    const command = context.command || 'مملكة';
    const usedPrefix = `${prefix}${command}`;

    const fullText = (
      m.body ||
      m.text ||
      m.message?.conversation ||
      m.message?.extendedTextMessage?.text ||
      m.raw?.message?.buttonsResponseMessage?.selectedButtonId ||
      m.raw?.message?.templateButtonReplyMessage?.selectedId ||
      ''
    ).trim();

    let words = fullText ? fullText.split(/\s+/) : [];
    if (words[0] && words[0].toLowerCase().includes(command.toLowerCase())) words.shift();
    const args = words.length > 0 ? words : (context.args || []);
    const action = (args[0] || '').trim();

    const senderId = getSenderId(m);
    const user = getUser(senderId);
    const kd = ensureKingdom(user);

    // تحويل نقاط الألعاب الأخرى ×10 للبنك تلقائياً
    try {
      if (typeof user.points === 'number' && user.points > 0) {
        kd.vault += user.points * 10;
        user.points = 0;
      }
    } catch (e) {}

    // تسجيل اللاعب عالمياً
    trackGlobalPlayer(senderId);

    const isGroup = (m.chat || '').endsWith('@g.us');
    const chatData = isGroup ? getChatData(m.chat) : null;

    try {
      if (sock.sendMessage) {
        await sock.sendMessage(m.chat, { react: { text: '🏰', key: m.raw?.key || m.key } });
      }
    } catch (e) {}

    try {
      return await runAction({ sock, m, args, action, usedPrefix, user, kd, chatData, isGroup });
    } finally {
      if (typeof scheduleSave === 'function') scheduleSave();
    }
  }
};
